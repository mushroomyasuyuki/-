<?php if (!defined('ABSPATH')) { exit; } /* 特許ページのテンプレート：直接開かれても中身を出さない（読み込み時にこの1行目は外す） */ ?>
<style>
/* このHTMLブロックを貼り付けたページの見出し（Cocoonテーマの記事タイトル）を非表示にする。
   このstyleタグはこのページ内でしか読み込まれないため、他のページ・記事には影響しない。 */
.eye-catch-wrap,.page .eye-catch,.page .post-thumbnail,.entry-header,.page .entry-title,article .entry-title{display:none!important;}
.cocoon-carpet-tool{max-width:1200px;margin:20px auto;background:#09090b;color:#f4f4f5;padding:30px;border-radius:12px;border:1px solid #27272a;box-shadow:0 10px 30px rgba(0,0,0,.5);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;box-sizing:border-box}.cocoon-carpet-tool *{box-sizing:border-box}.cocoon-carpet-tool h1,.cocoon-carpet-tool h2,.cocoon-carpet-tool h3{color:#fff!important;background:transparent!important;text-shadow:none!important}
.toc, .toc-box, .toc-content, .toc-list, .toc-label{color:#fff!important}
.toc a{color:#93c5fd!important;text-decoration:underline}
.toc-box{background:#18181b!important;border-color:#27272a!important}
.hero-appeal-section{text-align:center;background:linear-gradient(135deg,#18181b 0%,#09090b 100%);padding:35px 20px;border-radius:10px;margin-bottom:35px;border:1px solid #27272a}.hero-badge{display:inline-block;background:#27272a;color:#f39c12;border:1px solid rgba(243,156,18,.4);font-size:13px;font-weight:700;padding:4px 14px;border-radius:20px;margin-bottom:14px}.sub-catch{font-size:16px;color:#e4e4e7;font-weight:400}.hero-title{font-size:26px!important;line-height:1.4!important;margin:0 0 14px!important;border:0!important}.hero-title .highlight{color:#f39c12;font-size:28px;background:linear-gradient(transparent 65%,rgba(243,156,18,.25) 65%)}.hero-subtext{font-size:15px;color:#d4d4d8;max-width:700px;margin:0 auto 20px;line-height:1.7}.hero-image-wrapper{margin:20px 0;overflow:hidden;border-radius:8px;border:1px solid #27272a;box-shadow:0 6px 16px rgba(0,0,0,.4)}.hero-main-img{width:100%;height:auto;max-height:380px;object-fit:cover;display:block}.hero-actions{margin:25px 0}.btn-link-estimate{display:inline-block;background:#6366f1;color:#fff!important;font-size:15px;font-weight:700;padding:12px 26px;border-radius:25px;text-decoration:none;box-shadow:0 4px 12px rgba(99,102,241,.3)}.feature-cards-grid,.explain-grid,.spec-grid,.pile-cards-wrapper{display:flex;gap:15px}.feature-card,.explain-card,.spec-card,.pile-card{flex:1;background:#18181b;border:1px solid #27272a;border-radius:8px;overflow:hidden}.feature-card-img{width:100%;height:130px;object-fit:cover;filter:brightness(.9)}.feature-card-body{padding:15px}.feature-card-title{font-size:15px;font-weight:700;color:#fff;margin-bottom:6px}.feature-card-text{font-size:13px;color:#d4d4d8;line-height:1.5}.reduction-explain-section,.flow-section,.spec-detail-section,.compare-box,.construction-section{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:22px;margin-bottom:30px}.section-title-dark{font-size:20px!important;font-weight:700!important;color:#fff!important;border-left:4px solid #f39c12!important;padding-left:10px!important;margin:0 0 20px!important}.section-lead-text{font-size:14px;color:#e4e4e7;line-height:1.7}.section-lead-text strong{color:#f39c12}.explain-card{background:#09090b;padding:16px}.explain-icon{font-size:24px}.explain-title{font-size:15px;font-weight:700;color:#f39c12;margin:8px 0}.explain-text{font-size:13px;color:#d4d4d8;line-height:1.6}.reduction-demo-box{background:#272013;border:1px solid #b45309;border-radius:6px;padding:14px 18px;margin-top:18px}.demo-badge{display:inline-block;background:#f39c12;color:#000;font-size:11px;font-weight:700;padding:2px 8px;border-radius:4px;margin-bottom:6px}.demo-text{font-size:13px;color:#fff;line-height:1.6}.step-flow-grid{display:flex;align-items:stretch;gap:10px}.step-box{flex:1;background:#09090b;border:1px solid #27272a;border-radius:6px;padding:15px 10px;text-align:center}.step-box.highlight-step{border-color:#b45309;background:#272013}.step-badge{display:inline-block;background:#f39c12;color:#000;font-size:10px;font-weight:700;padding:2px 8px;border-radius:10px;margin-bottom:6px}.step-icon{font-size:24px}.step-title{font-size:13px;font-weight:700;color:#fff;margin:6px 0}.step-desc{font-size:11px;color:#d4d4d8;line-height:1.5;text-align:left}.step-arrow{color:#f39c12;font-size:18px;font-weight:700;display:flex;align-items:center}.cancel-note{color:#f87171!important}.spec-card{background:#09090b;padding:15px}.spec-card-header{font-size:14px;font-weight:700;color:#f39c12;border-bottom:1px solid #27272a;padding-bottom:8px;margin-bottom:10px}.spec-list,.pile-features{list-style:none;padding:0;margin:0;font-size:13px;color:#d4d4d8;line-height:1.8}.spec-list strong,.pile-features strong{color:#fff}.compare-title{font-size:16px;font-weight:700;color:#fff;margin:0 0 12px}.pile-card{padding:16px}.pile-card.cut-pile{border-top:3px solid #f39c12}.pile-card.loop-pile{border-top:3px solid #3b82f6}.pile-badge{display:inline-block;background:#272013;color:#f39c12;border:1px solid #b45309;font-size:11px;font-weight:700;padding:2px 8px;border-radius:12px}.loop-badge{background:#1e293b;color:#60a5fa;border-color:#2563eb}.pile-card-title-text{font-size:15px;font-weight:700;color:#fff;margin:6px 0 12px}.diagram-box{background:#18181b;border:1px solid #27272a;border-radius:6px;padding:8px;margin-bottom:12px}.pile-svg{width:100%;height:auto;display:block}.pile-features li{margin-bottom:6px;border-bottom:1px dashed #27272a;padding-bottom:4px}.pile-features li:last-child{border-bottom:0}.table-scroll{overflow:auto}.compare-table{width:100%;border-collapse:collapse;font-size:13px;background:#09090b;min-width:620px}.compare-table th{background:#27272a;color:#fff;border:1px solid #3f3f46;padding:12px 8px}.compare-table td{background:#18181b;color:#e4e4e7;border:1px solid #27272a;padding:12px 8px;text-align:center}.compare-table .target-col{background:#271f13;color:#fff;border-color:#b45309}.psd-tool-title{font-size:20px!important;border-bottom:2px solid #27272a;padding-bottom:8px;margin:0 0 20px!important;text-align:center}
.quality-badge-section{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:22px;margin-bottom:30px}.badge-grid{display:flex;gap:15px;margin-top:16px}.quality-badge-card{flex:1;background:#09090b;border:1px solid #27272a;border-radius:8px;padding:18px;text-align:center}.quality-badge-icon{width:80px;height:80px;margin:0 auto 12px;background:#fff;border-radius:8px;display:flex;align-items:center;justify-content:center;overflow:hidden}.badge-img{width:100%;height:100%;object-fit:contain}.quality-badge-title{font-size:14px;font-weight:700;color:#fff;margin-bottom:8px}.quality-badge-text{font-size:12px;color:#d4d4d8;line-height:1.6;text-align:left}.spec-badge-row{display:flex;align-items:center;gap:10px;margin-top:14px;padding-top:12px;border-top:1px solid #27272a}.spec-badge-icon{width:48px;height:48px;flex-shrink:0;border-radius:6px;background:#fff;object-fit:contain;padding:2px}.spec-badge-caption{font-size:12px;color:#d4d4d8;line-height:1.5;text-align:left}.form-group{display:flex;flex-direction:column;margin-bottom:18px}.form-group label,.file-box label,.palette-box label{font-weight:700;font-size:14px;margin-bottom:6px;color:#fff}.form-group small,.file-note,.palette-box small{color:#a1a1aa;font-size:12px;line-height:1.5;margin-top:6px}.grid-2{display:flex;gap:15px}.grid-2 .form-group{flex:1}.cocoon-carpet-tool input[type=text],.cocoon-carpet-tool input[type=tel],.cocoon-carpet-tool input[type=number],.cocoon-carpet-tool select{padding:10px 14px;background:#18181b;color:#fff;border:1px solid #3f3f46;border-radius:6px;font-size:14px;width:100%;min-height:44px}.cocoon-carpet-tool input:focus,.cocoon-carpet-tool select:focus{outline:0;border-color:#f39c12}.file-box,.dither-box,.palette-box{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:16px;margin:15px 0}.file-box{text-align:center;border-color:#3f3f46}

.cocoon-carpet-tool input[type=file]{display:block!important;width:100%!important;padding:12px!important;background:#18181b!important;color:#fff!important;border:2px dashed #f39c12!important;border-radius:8px!important;cursor:pointer!important;font-size:14px!important;margin:10px 0!important;box-sizing:border-box!important;opacity:1!important;visibility:visible!important;pointer-events:auto!important}

.file-note{font-size:12px;margin-top:8px;color:#fbbf24}.slider-row{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:8px}.slider-row span{font-size:11px;color:#a1a1aa}.dither-box input[type=range]{width:100%}.palette-select-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}.palette-select-chip{width:36px;height:36px;border-radius:6px;border:2px solid #3f3f46;cursor:pointer;position:relative;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:#fff;text-shadow:0 0 2px #000}.palette-select-chip.active{border-color:#f39c12;box-shadow:0 0 8px rgba(243,156,18,.6);transform:scale(1.05)}.palette-select-chip.active::after{content:'✓';position:absolute;top:-4px;right:-4px;background:#f39c12;color:#000;font-size:9px;width:13px;height:13px;border-radius:50%;display:flex;align-items:center;justify-content:center}.palette-select-chip.op-chip{border-color:#3b82f6}.palette-select-chip.op-chip.active::after{background:#3b82f6;color:#fff}.palette-controls{display:flex;gap:10px;margin-bottom:10px}.btn-chip-action{background:#27272a;color:#fff;border:1px solid #3f3f46;padding:4px 10px;font-size:12px;border-radius:4px;cursor:pointer}.btn-chip-action:hover{background:#3f3f46}.btn-chip-action:disabled{opacity:.5;cursor:not-allowed}.cc-variants canvas,#cc-reduced{background:#ffffff!important}.cc-orig-zoom{position:relative;overflow:hidden;margin:10px auto;border:2px solid #3f3f46;background:#fff;touch-action:none}.cc-orig-zoom canvas{margin:0!important;border:0!important;transform-origin:0 0;will-change:transform}.cfp-palver{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:8px 0 4px;font-size:13px;color:#e4e4e7}.cfp-palver small{color:#a1a1aa;font-size:11px}.cfp-palver-btn{padding:5px 14px!important;font-size:12.5px!important}.cfp-palver-btn.is-active{background:#f39c12!important;border-color:#f39c12!important;color:#000!important;font-weight:700}.cc-pal-compact{position:relative;padding:6px 10px 8px;margin:6px 0}.cc-pal-compact label{display:block!important;font-size:12.5px!important;line-height:1.4!important;margin:0!important;padding-right:84px}.cc-pal-compact small{display:block!important;font-size:10.5px!important;line-height:1.35!important;margin:1px 0 0!important}.cc-pal-compact .palette-controls{position:absolute;top:5px;right:8px;margin:0}.cc-pal-compact .btn-chip-action{padding:1px 8px;font-size:11px;line-height:1.6}.cc-pal-compact .palette-select-grid{gap:4px;margin-top:5px}.cc-pal-compact .palette-select-chip{width:26px;height:24px;font-size:6.5px;letter-spacing:-.3px;white-space:nowrap;border-width:2px;line-height:1}.cc-pal-compact .palette-select-chip.active{transform:none}.cc-pal-compact .palette-select-chip.active::after{width:10px;height:10px;font-size:7px;top:-3px;right:-3px}.status-box{padding:12px 15px;border-radius:6px;margin:0 0 20px;font-weight:700;display:none}.status-box.ok{background:#064e3b;color:#34d399;border:1px solid #059669;display:block}.status-box.err{background:#450a0a;color:#f87171;border:1px solid #dc2626;display:block}.preview-grid{display:flex;gap:15px;margin-bottom:20px}.preview-card{flex:1;border:1px solid #27272a;border-radius:6px;padding:10px;text-align:center;background:#18181b;min-width:0}.preview-card h3{font-size:14px!important;color:#fff!important;margin:0 0 10px!important}
.preview-card canvas{display:block!important;width:100%!important;margin:10px auto!important;border:2px solid #3f3f46;background:#18181b;image-rendering:pixelated;image-rendering:crisp-edges}
#cc-original{height:auto!important}
#cc-reduced{height:auto!important;max-width:100%}
.used-colors{margin-top:15px;color:#d4d4d8}.used-colors-text{margin-top:8px;font-size:12px;color:#a1a1aa;line-height:1.6;text-align:left}.psd-palette-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;justify-content:center}.psd-color-chip{width:28px;height:28px;border-radius:4px;border:1px solid rgba(255,255,255,.2)}.btn-submit{display:block;width:100%;background:#f39c12;color:#000;border:0;padding:14px;font-size:18px;font-weight:700;border-radius:6px;cursor:pointer;margin-top:20px;text-align:center}.btn-submit:hover:not(:disabled){background:#d35400;color:#fff}.btn-psd{background:#10b981;color:#fff}.btn-psd:hover:not(:disabled){background:#059669}.btn-stretch{background:#3b82f6;color:#fff;margin-top:10px}.btn-stretch:hover:not(:disabled){background:#2563eb}.btn-submit:disabled{background:#3f3f46;color:#71717a;cursor:not-allowed}.estimate-summary,.customer-info-section{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:20px;margin-top:25px}.summary-title,.customer-info-title{font-size:18px;font-weight:700;color:#fff;border-bottom:1px solid #27272a;padding-bottom:10px;margin-bottom:15px}.customer-info-title{font-size:16px}.summary-row{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:12px}.summary-label{color:#d4d4d8;font-size:15px}.summary-value{font-size:16px;font-weight:700;color:#fff;text-align:right}.summary-row.total{border-top:2px dashed #3f3f46;padding-top:12px;margin-top:15px}.summary-row.total .summary-label{font-size:18px;font-weight:700}.summary-row.total .summary-value{font-size:22px;color:#ef4444}.delivery-notice-box{background:#272013;border:1px solid #b45309;border-left:5px solid #f39c12;border-radius:6px;padding:12px 16px;margin:15px 0;display:flex;align-items:center;gap:12px}.delivery-notice-icon{font-size:22px}.delivery-notice-title{font-weight:700;color:#f59e0b;font-size:13px}.delivery-notice-text{font-size:15px;font-weight:700;color:#fff}.required{color:#ef4444;margin-left:4px}.cocoon-debug{font-size:13px;color:#fbbf24;margin-top:15px;background:#18181b;padding:12px;border-radius:6px;border:1px solid #f59e0b;display:block;white-space:pre-wrap;word-break:break-all}.tool-anchor{scroll-margin-top:30px}
.perspective-section{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:22px;margin:30px 0;text-align:center}.persp-room{position:relative;width:100%;max-width:640px;height:360px;margin:18px auto;perspective:1600px;perspective-origin:50% 50%;background:#09090b;border-radius:8px;overflow:hidden;border:1px solid #27272a}.persp-box{position:absolute;left:50%;top:50%;width:0;height:0;transform-style:preserve-3d}.persp-geo{position:absolute;left:0;top:0;transform-style:preserve-3d}.persp-back-wall,.persp-floor,.persp-side-wall{position:absolute;background-repeat:no-repeat;background-size:100% 100%;background-position:center}.persp-back-wall{background-color:#3f3f46;box-shadow:inset 0 0 50px rgba(0,0,0,.55)}.persp-floor{background-color:#27272a;box-shadow:inset 0 0 50px rgba(0,0,0,.55)}.persp-side-wall{background-color:#27272a;box-shadow:inset 0 0 50px rgba(0,0,0,.65)}.persp-size-grid{display:flex;gap:10px;margin-top:10px;text-align:left}.persp-size-field{flex:1;min-width:0}.persp-size-field label{display:block;font-size:12px;font-weight:700;margin-bottom:4px;color:#d4d4d8}.persp-size-field input[type=number]{width:100%;padding:7px 8px;background:#09090b;color:#fff;border:1px solid #3f3f46;border-radius:6px;font-size:13px;box-sizing:border-box}.room-sim-panel{background:#09090b;border:1px solid #27272a;border-radius:8px;padding:16px}.room-sim-panel-title{font-size:15px;font-weight:700;color:#f39c12;margin-bottom:10px}.room-sim-controls{margin-top:10px}.room-sim-controls input[type=range]{width:100%;margin-bottom:6px}
@media(max-width:768px){.cocoon-carpet-tool{padding:18px}.feature-cards-grid,.explain-grid,.step-flow-grid,.spec-grid,.pile-cards-wrapper,.preview-grid,.grid-2,.room-sim-grid{flex-direction:column}.step-arrow{transform:rotate(90deg);justify-content:center;margin:5px 0}.slider-row{flex-direction:column;align-items:flex-start}.summary-row{align-items:flex-start}.summary-value{text-align:right}.hero-title{font-size:22px!important}.hero-title .highlight{font-size:24px}}
.cfp-resume-box{background:#1e1b4b;border:1px solid #6d28d9;border-radius:8px;padding:14px 16px;margin:0 0 20px}.cfp-resume-title{font-size:15px;font-weight:700;color:#c4b5fd;margin-bottom:6px}.cfp-resume-text{font-size:13px;color:#e4e4e7;line-height:1.7}.cfp-resume-row{display:flex;flex-wrap:wrap;gap:10px;margin-top:10px;align-items:center}.cocoon-carpet-tool .cfp-resume-row input[type=email]{flex:1;min-width:220px;width:auto}.cfp-resume-row .btn-chip-action{padding:10px 16px;font-size:13px;background:#6d28d9;border-color:#8b5cf6}.cfp-resume-status{font-size:13px;margin-top:8px;color:#fde68a;white-space:pre-line;line-height:1.7}.cfp-resume-status.is-ok{color:#86efac}.cfp-resume-status.is-err{color:#fca5a5}.cfp-resume-local{margin-top:12px;padding:10px 12px;background:#312e81;border:1px solid #a78bfa;border-radius:6px}.cfp-resume-local-text{font-size:13px;color:#fff;font-weight:700}.cfp-resume-row .btn-chip-action.cfp-resume-discard{background:#27272a;border-color:#3f3f46}.cfp-resume-note{font-size:12px;color:#c4b5fd;margin-top:8px}.pile-photo{margin:0 0 12px;border-radius:6px;overflow:hidden;border:1px solid #27272a}.pile-photo img{display:block;width:100%;height:190px;object-fit:cover}@media(max-width:768px){.pile-photo img{height:auto;aspect-ratio:16/10}}.cfp-agree-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:18px 0 0;align-items:start}.cfp-agree-box.is-open{grid-column:1/-1}.cfp-agree-box{padding:12px 14px;background:#272013;border:1px solid #b45309;border-radius:6px;min-width:0}.cfp-qs{margin-top:10px;max-height:320px;overflow-y:auto;padding:14px 16px;background:#09090b;border:1px solid #3f3f46;border-radius:6px;font-size:13px;line-height:1.8;color:#e4e4e7;text-align:left}.cfp-qs:focus{outline:2px solid #f39c12}.cfp-qs .qs-title{font-size:15px;font-weight:700;color:#fff;text-align:center}.cfp-qs .qs-meta{text-align:center;color:#a1a1aa;font-size:12px;margin-bottom:6px}.cfp-qs h4{font-size:14px!important;color:#f39c12;margin:16px 0 4px!important;border-bottom:1px solid #27272a;padding-bottom:3px}.cfp-qs h5{font-size:13px!important;color:#fff;margin:10px 0 2px!important}.cfp-qs p{margin:4px 0!important;color:#d4d4d8}.cfp-qs ul{margin:4px 0 6px 18px!important;padding:0}.cfp-qs li{margin:2px 0}.cfp-qs .qs-note{color:#fbbf24!important;font-size:12px}.cfp-qs .qs-sub{font-weight:700;color:#fff!important;text-align:center;margin-top:12px!important}.cfp-qs .qs-box{margin:10px 0;padding:10px 12px;border:1px solid #52525b;border-radius:6px;background:#18181b}.cfp-qs .qs-box-title{font-weight:700;color:#fff;text-align:center;margin-bottom:4px}.cfp-qs .qs-end{text-align:center;color:#a1a1aa;margin:14px 0 4px}.cfp-qs-status{font-size:12px;margin-top:6px;color:#fbbf24}.cfp-qs-status.is-ok{color:#86efac}@media(max-width:768px){.cfp-agree-grid{grid-template-columns:1fr}}.pile-card.cut-pile,.pile-card.loop-pile{display:flex;flex-direction:column}.pile-sample{margin-top:auto;padding-top:14px;text-align:center}.pile-sample-btn{padding:10px 16px!important;font-size:13px!important;background:#272013!important;border:1px solid #b45309!important;color:#fbbf24!important;font-weight:700;border-radius:6px;cursor:pointer}.pile-sample-btn:hover{background:#3a2c14!important}.cc-variants{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}.cc-var-card h3{margin-bottom:4px!important}.cc-var-sub{font-size:11px;color:#a1a1aa;margin-bottom:2px;line-height:1.5;min-height:3em}.cc-var-card .psd-palette-grid{margin-top:6px;min-height:36px}.cc-var-btn{margin-top:8px;width:100%;padding:9px 10px!important;font-size:13px!important;font-weight:700;background:#1e3a8a!important;border-color:#3b82f6!important;color:#fff!important}.cc-var-card.is-selected{border-color:#22c55e!important;box-shadow:0 0 0 2px rgba(34,197,94,.45)}.cc-var-card.is-selected .cc-var-btn{background:#166534!important;border-color:#22c55e!important}.cc-manual-card{display:block}.cfp-fold{margin:0}.ref-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-top:16px}.ref-col{background:#09090b;border:1px solid #27272a;border-radius:8px;padding:12px}.ref-col-title{font-size:14px;font-weight:700;color:#f39c12;text-align:center;margin-bottom:10px}.ref-fig{margin:0 0 12px}.ref-fig:last-child{margin-bottom:0}.ref-fig img{width:100%;height:auto;display:block;border-radius:6px;border:1px solid #27272a}.ref-fig figcaption{font-size:12px;color:#d4d4d8;text-align:center;margin-top:5px}.ref-fig figcaption b{color:#fff}@media(max-width:768px){.ref-grid{grid-template-columns:1fr}}
.cfp-fold-summary{display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:pointer;list-style:none;-webkit-user-select:none;user-select:none}
.cfp-fold-summary::-webkit-details-marker{display:none}
.cfp-fold-summary::marker{content:""}
.cfp-fold-summary .section-title-dark{margin:0!important;flex:1}
.cfp-fold-summary::after{content:"▼ 開く";flex:none;font-size:12px;font-weight:700;color:#f39c12;border:1px solid #b45309;border-radius:14px;padding:3px 12px;background:#272013;white-space:nowrap}
.cfp-fold[open]>.cfp-fold-summary::after{content:"▲ 閉じる"}
.cfp-fold-summary:hover::after{background:#3a2c14}
.cfp-fold-summary:focus-visible{outline:2px solid #f39c12;outline-offset:4px;border-radius:4px}
.cfp-fold-body{margin-top:20px}
</style>

<div class="cocoon-carpet-tool" id="cocoonCarpetTool">
  <div class="hero-appeal-section">
    <span class="hero-badge">完全オーダーメイド × 1m²から制作OK</span>
    <h1 class="hero-title">
      <span class="sub-catch">写真・イラスト・ロゴで、お部屋を丸ごとデザイン！</span><br>
      <span class="highlight">「あなただけのオリジナル空間」</span>をつくろう
    </h1>
    <p class="hero-subtext">
      世界にひとつだけのデザインを、最高品質のプリントカーペットに。床だけでなく、壁紙とのコーディネートイメージもシミュレーションできます。<br>
      店舗のブランディングPOP、オフィスのエントランス、ご自宅のインテリアまで、アイデア次第で自由自在に表現できます。
    </p>
    <div class="hero-image-wrapper">
      <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&amp;fit=crop&amp;w=1200&amp;q=80" alt="オリジナルプリントカーペット施工例" class="hero-main-img" loading="lazy">
    </div>
    <div class="hero-actions">
      <a href="#tool-section" class="btn-link-estimate">📊 簡単お見積もり・自動シミュレーターへ移動 ➔</a>
    </div>
    <div class="feature-cards-grid">
      <div class="feature-card">
        <img src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&amp;fit=crop&amp;w=500&amp;q=80" alt="店舗POP・エントランス" class="feature-card-img" loading="lazy">
        <div class="feature-card-body">
          <div class="feature-card-title">🏬 店舗・ショップエントランス</div>
          <div class="feature-card-text">ブランドロゴやオリジナルデザインでお客様をお出迎え。置くだけで印象的な空間演出が可能です。</div>
        </div>
      </div>
      <div class="feature-card">
        <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&amp;fit=crop&amp;w=500&amp;q=80" alt="オフィス・イベントスペース" class="feature-card-img" loading="lazy">
        <div class="feature-card-body">
          <div class="feature-card-title">🏢 オフィス・展示会イベント</div>
          <div class="feature-card-text">導線サインやイベントPOPとしても大活躍。高い耐摩耗性能で人が多く行き交う場所でも安心。</div>
        </div>
      </div>
      <div class="feature-card">
        <img src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&amp;fit=crop&amp;w=500&amp;q=80" alt="ご自宅インテリア・ペット用" class="feature-card-img" loading="lazy">
        <div class="feature-card-body">
          <div class="feature-card-title">🏠 インテリア・愛犬ペットマット</div>
          <div class="feature-card-text">ペットの写真や自作イラストも美しくプリント。1枚ずつ取り外して水洗いできるから清潔です。</div>
        </div>
      </div>
    </div>
  </div>

  <section class="reduction-explain-section">
    <h2 class="section-title-dark">カラー表現と減色処理について</h2>
    <p class="section-lead-text">カーペットのプリントは、紙や写真用紙への印刷とは異なり、<strong>「糸（パイル）を直接染色する」</strong>特殊な工業プロセスで行われます。美しい仕上がりと耐久性を維持するために、専用のカラーパレットに最適化を行います。</p>
    <div class="explain-grid">
      <div class="explain-card"><div class="explain-icon">🎨</div><div class="explain-title">1. 糸の深部まで鮮やかに発色させるため</div><div class="explain-text">無限のグラデーションや微細な混色データのまま染色すると、パイルの奥までインクが浸透せず、毛足が割れた際に白い素地が見えてしまいます。色数を最適化することで、一色一色のインクをしっかり毛根まで浸透させ、鮮やかで力強い発色を実現します。</div></div>
      <div class="explain-card"><div class="explain-icon">🛡️</div><div class="explain-title">2. にじみを防ぎ、輪郭をくっきり美しく仕上げるため</div><div class="explain-text">カーペット繊維の特性上、色数が多すぎるとインク同士がにじみ合い、デザインの境界線がボヤけてしまいます。厳選されたカラーパレットに置き換えることで、ロゴやイラストの輪郭がハッキリと際立つ美しい仕上がりに導きます。</div></div>
    </div>
    <div class="reduction-demo-box">
      <div class="demo-badge">⚠️ 制作上の重要なご注意事項</div>
      <div class="demo-text">
        • <strong>実際の仕上がりの風合いはイメージと異なることがあります。</strong><br>
        • <strong>濃い色は太くなり、薄い色は濃い色に侵食され細くなりやすいです。</strong>（文字印刷の場合一文字１０ｃｍ角位までがきれいに印刷されます）
      </div>
    </div>
  </section>

  <section class="flow-section">
    <h2 class="section-title-dark">ご注文の流れ</h2>
    <div class="step-flow-grid">
      <div class="step-box"><div class="step-badge">STEP 01</div><div class="step-icon">📐</div><div class="step-title">仕様・サイズの入力</div><div class="step-desc">パイル形状（カット／ループ）とお届け先地域を選択し、制作ご希望のミリ単位サイズを入力します。</div></div><div class="step-arrow">➔</div>
      <div class="step-box"><div class="step-badge">STEP 02</div><div class="step-icon">🎨</div><div class="step-title">データ入稿 ＆ 減色確認</div><div class="step-desc">デザイン画像をアップロード。自動で25.4 DPI換算とカラーパレットによる減色処理を行います。</div></div><div class="step-arrow">➔</div>
      <div class="step-box"><div class="step-badge">STEP 03</div><div class="step-icon">📩</div><div class="step-title">お見積もり確認・メール送信</div><div class="step-desc">自動計算された金額と納期目安を確認し、ご注文者様情報を入力して送信ボタンを押します（ここで決済確定となります）。</div></div><div class="step-arrow">➔</div>
      <div class="step-box highlight-step"><div class="step-badge">STEP 04</div><div class="step-icon">🏭</div><div class="step-title">印刷・出荷</div><div class="step-desc">印刷・出荷いたします。標準納期：デザイン確定から2週間〜（デザイン・サイズにより変わります。お急ぎの場合は必ず事前に納期をお問い合わせください）。</div></div>
    </div>
  </section>

  <section class="spec-detail-section">
    <details class="cfp-fold">
      <summary class="cfp-fold-summary"><h2 class="section-title-dark">カーペットの製品構造・詳細仕様</h2></summary>
      <div class="cfp-fold-body">
    <div class="spec-grid">
      <div class="spec-card">
        <div class="spec-card-header">製品スペック・構造</div>
        <ul class="spec-list">
          <li><strong>タイルサイズ:</strong> 500mm × 500mm（1枚あたり）</li>
          <li><strong>表地パイル:</strong> 原着ナイロン 100%（耐摩耗性・発色性に優れた高品質素材）</li>
          <li><strong>バッキング（裏地）:</strong> ガラス繊維 ＋ 塩ビ樹脂（高い寸法安定性・滑り止め効果）</li>
          <li><strong>パイル形状:</strong> カットパイル（全厚 約9.0mm）／ループパイル（全厚 約7.0mm）</li>
          <li><strong>加工規格:</strong> 防炎物品認定／防汚加工／制電仕様</li>
        </ul>
        <div class="spec-badge-row">
          <img src="{{CFP_BADGE_SEIDEN}}" alt="制電マーク" class="spec-badge-icon">
          <img src="{{CFP_BADGE_BOUEN}}" alt="防炎マーク" class="spec-badge-icon">
          <div class="spec-badge-caption">制電・防炎、両方の認定基準を満たした素材を使用しています。</div>
        </div>
      </div>
      <div class="spec-card"><div class="spec-card-header">メンテナンス・使用環境</div><ul class="spec-list"><li><strong>日常のお手入れ:</strong> 掃除機によるホコリ・吸塵清掃</li><li><strong>部分洗い対応:</strong> 汚れたタイルだけを外し、中性洗剤で水洗い・日陰干しが可能</li><li><strong>推奨用途:</strong> 店舗エントランス、展示会POP、オフィスフロア、商業施設の誘導サイン</li><li><strong>耐久性能:</strong> 土足歩行・重歩行エリアに対応する高い耐摩耗構造</li></ul></div>
    </div>
    <div class="pile-compare-container">
      <div class="compare-title">カットパイル ＆ ループパイルの構造比較</div>
      <div class="pile-cards-wrapper">
        <div class="pile-card cut-pile"><div class="pile-badge">発色・質感重視</div><div class="pile-card-title-text">カットパイル（Cut Pile）</div><figure class="pile-photo"><img src="{{CFP_PHOTO_CUT}}" alt="カットパイルのカーペット（実物の写真）" loading="lazy"></figure><div class="diagram-box"><svg viewBox="0 0 300 120" class="pile-svg"><rect x="10" y="90" width="280" height="20" fill="#3f3f46" rx="3"></rect><text x="150" y="104" fill="#fff" font-size="11" text-anchor="middle" font-weight="bold">バッキング（基布・裏地）</text><path d="M40 90V30M55 90V30M95 90V30M110 90V30M150 90V30M165 90V30M205 90V30M220 90V30M260 90V30" stroke="#f39c12" stroke-width="8"></path><line x1="20" y1="30" x2="280" y2="30" stroke="#ef4444" stroke-dasharray="4" stroke-width="2"></line><text x="150" y="20" fill="#ef4444" font-size="11" text-anchor="middle" font-weight="bold">✂️ 先端をカット（フラット表面）</text></svg></div><ul class="pile-features"><li><strong>先端形状:</strong> 糸の先端をカットしたフラット面</li><li><strong>発色性:</strong> インクが毛足の奥まで浸透し鮮やか</li><li><strong>特徴:</strong> 柔らかく高級感ある踏み心地。ペットの爪も引っかかりにくい構造です。</li></ul><div class="pile-sample"><button type="button" id="cc-sample-cut" class="btn-chip-action pile-sample-btn">📦 無料サンプル請求（カットパイル）</button></div></div>
        <div class="pile-card loop-pile"><div class="pile-badge loop-badge">高耐久・標準仕様</div><div class="pile-card-title-text">ループパイル（Loop Pile）</div><figure class="pile-photo"><img src="{{CFP_PHOTO_LOOP}}" alt="ループパイルのカーペット（実物の写真）" loading="lazy"></figure><div class="diagram-box"><svg viewBox="0 0 300 120" class="pile-svg"><rect x="10" y="90" width="280" height="20" fill="#3f3f46" rx="3"></rect><text x="150" y="104" fill="#fff" font-size="11" text-anchor="middle" font-weight="bold">バッキング（基布・裏地）</text><path d="M30 90C30 25 65 25 65 90M85 90C85 25 120 25 120 90M140 90C140 25 175 25 175 90M195 90C195 25 230 25 230 90M250 90C250 25 275 25 275 90" stroke="#3b82f6" stroke-width="8" fill="none" stroke-linecap="round"></path><text x="150" y="20" fill="#60a5fa" font-size="11" text-anchor="middle" font-weight="bold">🔄 連続したループ構造</text></svg></div><ul class="pile-features"><li><strong>先端形状:</strong> 糸が輪っか状に連なった構造</li><li><strong>耐久性:</strong> 復元力が高くヘたりにくい</li><li><strong>特徴:</strong> 擦り切れに強く、店舗・オフィスなど人が多く行き交う重歩行エリアに最適。</li></ul><div class="pile-sample"><button type="button" id="cc-sample-loop" class="btn-chip-action pile-sample-btn">📦 無料サンプル請求（ループパイル）</button></div></div>
      </div>
    </div>
    <div class="compare-box" style="margin-top:20px; margin-bottom:0;"><div class="compare-title">カットパイルとループパイルの価格表（ボリュームディスカウント適用・すべて税別価格）</div><div class="table-scroll"><table class="compare-table"><thead><tr><th>適用ロット（面積）</th><th>カットパイル ㎡単価</th><th>ループパイル ㎡単価</th></tr></thead><tbody><tr><td>0.25〜0.75m²</td><td>¥18,400 / m²（税込¥20,240）</td><td>¥17,500 / m²（税込¥19,250）</td></tr><tr><td>1〜9.75m²</td><td>¥16,300 / m²（税込¥17,930）</td><td>¥15,500 / m²（税込¥17,050）</td></tr><tr><td>10〜49.75m²</td><td>¥14,000 / m²（税込¥15,400）</td><td>¥13,300 / m²（税込¥14,630）</td></tr></tbody></table></div><div style="font-size:12px;color:#a1a1aa;margin-top:8px;">※上記は税別価格です。消費税10%を加算した金額（税込）を併記しています。</div></div>
      </div>
    </details>
  </section>

  <section class="quality-badge-section">
    <h2 class="section-title-dark">品質基準</h2>
    <p class="section-lead-text">「ONE m² FLOOR ME」のカーペットは、以下の品質基準に対応した仕様で製造しています。<strong>※認定番号・試験方法の詳細は、実際の認定書・試験成績書に基づく正式な表記に差し替えてご使用ください（下記は仕様の概要説明です）。</strong></p>

    <div class="spec-grid" style="margin-top:20px;">
      <div class="spec-card">
        <div class="spec-card-header">品質基準（概要）</div>
        <ul class="spec-list">
          <li><strong>防炎性能:</strong> 防炎物品としての基準に対応（認定番号は納品書・認定書に記載）</li>
          <li><strong>制電性能:</strong> 帯電防止仕様（静電気の発生を抑制する加工）</li>
          <li><strong>防汚加工:</strong> 汚れが染み込みにくいコーティング仕上げ</li>
          <li><strong>耐摩耗性能:</strong> 商業施設の重歩行エリアにも対応する高耐久構造</li>
        </ul>
      </div>
      <div class="spec-card">
        <div class="spec-card-header">ご利用にあたって</div>
        <ul class="spec-list">
          <li>消防法上の防炎物品の設置義務がある施設様は、事前に必要な認定区分をお問い合わせください。</li>
          <li>認定書・試験成績書の写しが必要な場合は、ご注文時にお申し付けください。</li>
        </ul>
      </div>
    </div>
  </section>

  <section class="construction-section">
    <details class="cfp-fold">
      <summary class="cfp-fold-summary"><h2 class="section-title-dark">タイルカーペットの簡単・丁寧な施工方法（真割とウラ面ナンバー）</h2></summary>
      <div class="cfp-fold-body">
    <p class="section-lead-text">「ONE m² FLOOR ME」のカーペットは裏面に特殊な重い塩ビ樹脂バッキングを採用しているため、<strong>置くだけでもずれにくい設計</strong>になっています。さらに、<strong>ウラ面ナンバー（矢印・番号）</strong>が記載されており、パイルの向きや敷く順番に迷わず、初心者でも非常に<strong>施工しやすい</strong>仕様です。ここでは、美しく仕上がるプロの割り付け方<strong>「真割（しんわり）」</strong>の手順をご紹介します。</p>
    
    <div class="diagram-box" style="margin:20px 0; background:#09090b; padding:15px; border-radius:6px; border:1px solid #27272a;">
      <div style="font-size:14px; font-weight:700; color:#f39c12; margin-bottom:10px; text-align:center;">💡 プロのきれいに仕上がる貼り方：中心から始める「真割（しんわり）」の図解</div>
      <svg viewBox="0 0 500 210" style="width:100%; height:auto; display:block;">
        <rect x="50" y="20" width="400" height="170" fill="#18181b" stroke="#3f3f46" stroke-width="2" rx="4"></rect>
        <text x="250" y="15" fill="#a1a1aa" font-size="11" text-anchor="middle">部屋の全体図（俯瞰）</text>
        <line x1="250" y1="20" x2="250" y2="190" stroke="#f39c12" stroke-dasharray="4" stroke-width="2"></line>
        <line x1="50" y1="105" x2="450" y2="105" stroke="#f39c12" stroke-dasharray="4" stroke-width="2"></line>
        <circle cx="250" cy="105" r="5" fill="#ef4444"></circle>
        <text x="260" y="100" fill="#ef4444" font-size="11" font-weight="bold">部屋の中心（基準点）</text>
        <rect x="210" y="70" width="40" height="35" fill="#272013" stroke="#f39c12" stroke-width="1.5"></rect>
        <rect x="250" y="70" width="40" height="35" fill="#272013" stroke="#f39c12" stroke-width="1.5"></rect>
        <rect x="210" y="105" width="40" height="35" fill="#272013" stroke="#f39c12" stroke-width="1.5"></rect>
        <rect x="250" y="105" width="40" height="35" fill="#272013" stroke="#f39c12" stroke-width="1.5"></rect>
        <text x="250" y="92" fill="#fff" font-size="9" text-anchor="middle">①中心から敷く</text>
        <path d="M 195 105 L 140 105" stroke="#60a5fa" stroke-width="2" fill="none"></path>
        <polygon points="135,105 145,101 145,109" fill="#60a5fa"></polygon>
        <path d="M 305 105 L 360 105" stroke="#60a5fa" stroke-width="2" fill="none"></path>
        <polygon points="365,105 355,101 355,109" fill="#60a5fa"></polygon>
        <text x="360" y="95" fill="#60a5fa" font-size="10">②外側へ順に広げる</text>
      </svg>
      <div style="font-size:12px; color:#d4d4d8; margin-top:10px; line-height:1.6; text-align:center;">
        ※<strong>真割（しんわり）</strong>とは、部屋の縦横の中心線をクロスさせて割り出し、その中心から外側に向けてタイルを並べていくプロの手法です。端のカット幅が左右対称になり、全体のバランスが最も美しく仕上がります。
      </div>
    </div>

    <div class="explain-grid" style="margin-top:15px;">
      <div class="explain-card">
        <div class="explain-icon">🧹</div>
        <div class="explain-title">1. 下地の清掃・中心出し</div>
        <div class="explain-text">施工面のホコリやゴミを綺麗に拭き取ります。お部屋の縦・横それぞれの中心位置を測定し、チョークやテープ等で十字の基準線（墨出し）を引きます（これが真割の基準となります）。</div>
      </div>
      <div class="explain-card">
        <div class="explain-icon">🔢</div>
        <div class="explain-title">2. ウラ面ナンバーの確認</div>
        <div class="explain-text">カーペットの<strong>裏面に記載されたナンバーや矢印の向き</strong>を確認しながら、先ほどの中心から十字ラインに沿って順番通りに並べていきます。方向が揃うことで継ぎ目も自然に馴染みます。</div>
      </div>
      <div class="explain-card">
        <div class="explain-icon">📌</div>
        <div class="explain-title">3. 端のカットと固定</div>
        <div class="explain-text">壁際の端のスペースに合わせて、カッターで裏面（塩ビ層）から簡単にカット・調整が可能です。専用の滑り止めテープやピールアップ糊の併用でしっかり固定でき、初心者でも非常に<strong>施工しやすい</strong>仕様です。</div>
      </div>
    </div>
      </div>
    </details>
  </section>

  <div id="tool-section" class="tool-anchor"></div>
  <h2 class="psd-tool-title">簡単お見積もり ＆ 入稿データ自動確認ツール</h2>

  <!-- ▼▼▼ 作業の途中保存・再開 ▼▼▼ -->
  <div class="cfp-resume-box" id="cfp-resume-box">
    <div class="cfp-resume-title">💾 作業の途中保存（<span class="cfp-resume-days">30</span>日間）</div>
    <div class="cfp-resume-text">画像・図面・入力内容をサーバーに保存し、再開用のリンクをメールでお送りします。後日、そのリンクを開くと続きから作業できます（パソコン・スマートフォンのどちらでも可）。保存した内容は<span class="cfp-resume-days">30</span>日後に自動で削除されます。</div>
    <div class="cfp-resume-row">
      <input type="email" id="cfp-resume-email" placeholder="再開用リンクを受け取るメールアドレス" autocomplete="email">
      <button type="button" id="cfp-resume-save" class="btn-chip-action">途中保存してリンクを受け取る</button>
    </div>
    <div class="cfp-resume-status" id="cfp-resume-status" aria-live="polite"></div>
    <div class="cfp-resume-local" id="cfp-resume-local" hidden>
      <div class="cfp-resume-local-text" id="cfp-resume-local-text"></div>
      <div class="cfp-resume-row">
        <button type="button" id="cfp-resume-local-load" class="btn-chip-action">続きから再開する</button>
        <button type="button" id="cfp-resume-local-discard" class="btn-chip-action cfp-resume-discard">破棄して最初から</button>
      </div>
    </div>
    <div class="cfp-resume-note">※この端末のブラウザにも、作業内容を自動で保存しています（同じ端末・同じブラウザなら、次に開いたとき続きから再開できます。<span class="cfp-resume-days">30</span>日で削除）。</div>
  </div>
  <!-- 仕様・サイズ・お届け先地域（畳んでおく。パイル形状はお見積もり明細でも選べ、地域はご住所から自動で選ぶ） -->
  <section class="spec-detail-section cc-spec-section">
    <details class="cfp-fold" id="cc-spec-fold">
      <summary class="cfp-fold-summary"><h2 class="section-title-dark">仕様・サイズ・お届け先地域 <span id="cc-spec-sum" style="font-size:12px;font-weight:400;color:#a1a1aa;"></span></h2></summary>
  <div class="form-section">
    <div class="form-group"><label for="cc-material">仕様・パイル形状の選択 (サイズ規格: 500mm×500mm)</label><select id="cc-material"><option value="cut">カットパイル（発色・質感重視）※面積に応じて単価変動</option><option value="loop">ループパイル（標準・高耐久・重歩行向け）※面積に応じて単価変動</option></select><small>※1枚あたり500mm×500mmのタイルカーペットです。<br>※ループパイル・カットパイルともに、ご注文面積（ロット）に応じて㎡単価が自動でディスカウントされます。</small></div>
    <div class="grid-2"><div class="form-group"><label for="cc-width">横幅 (W) [mm]</label><input type="number" id="cc-width" value="1000" min="500" step="500"></div><div class="form-group"><label for="cc-height">縦幅 (H) [mm]</label><input type="number" id="cc-height" value="1000" min="500" step="500"></div></div>
    <div class="file-note" id="cc-tile-count" style="text-align:center;margin:-8px 0 18px;">合計カーペット枚数：4枚（横2枚 × 縦2枚）</div>
    <div class="form-group"><label for="cc-region">お届け先地域（送料/箱）</label><select id="cc-region"><option value="honshu" data-shipping="2000">本州 (送料: ¥2,000 / 箱)</option><option value="hokkaido_shikoku_kyushu" data-shipping="2500">北海道・四国・九州 (送料: ¥2,500 / 箱)</option><option value="okinawa" data-shipping="5500">沖縄 (送料: ¥5,500 / 箱)</option></select><small>※ループパイル：1箱＝20枚（5㎡）換算／カットパイル：1箱＝16枚（4㎡）換算で送料を計算します。<br>※配送はヤマト運輸（クロネコヤマト便）にて発送いたします。<br>※下の「お届け先ご住所」を入力すると、都道府県から自動で選びます。</small></div>
  </div>
    </details>
    <div class="file-note" id="cc-cad-size-note" style="margin:8px 0 0;color:#93c5fd;" hidden></div>
  </section>

  <!-- ▼▼▼ 仕上がり参考例（元画像／オプションカラー少なめ・多め） ▼▼▼ -->
  <section class="spec-detail-section ref-section">
    <details class="cfp-fold">
      <summary class="cfp-fold-summary"><h2 class="section-title-dark">仕上がり参考例（元画像・オプションカラー少なめ／多め）</h2></summary>
      <div class="cfp-fold-body">
        <p class="section-lead-text">同じ元画像でも、使うオプションカラーの数で仕上がりが変わります。<strong>オプションカラーを多く使うほど、元画像に近い色・グラデーションを再現</strong>できます（実際のタフテッドカーペットを撮影した参考画像です）。</p>
        <div class="ref-grid">
        <div class="ref-col">
          <div class="ref-col-title">ハート型（カールちゃん）</div>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-heart-original.jpg" alt="ハート型 元画像" loading="lazy"><figcaption><b>元画像</b>（ご入稿データ）</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-heart-less.jpg" alt="ハート型 オプションカラー少なめの仕上がり" loading="lazy"><figcaption><b>オプションカラー 少なめ</b>の仕上がり例</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-heart-more.jpg" alt="ハート型 オプションカラー多めの仕上がり" loading="lazy"><figcaption><b>オプションカラー 多め</b>の仕上がり例</figcaption></figure>
        </div>
        <div class="ref-col">
          <div class="ref-col-title">ひし形（チロルちゃん）</div>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-diamond-original.jpg" alt="ひし形 元画像" loading="lazy"><figcaption><b>元画像</b>（ご入稿データ）</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-diamond-less.jpg" alt="ひし形 オプションカラー少なめの仕上がり" loading="lazy"><figcaption><b>オプションカラー 少なめ</b>の仕上がり例</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-diamond-more.jpg" alt="ひし形 オプションカラー多めの仕上がり" loading="lazy"><figcaption><b>オプションカラー 多め</b>の仕上がり例</figcaption></figure>
        </div>
        <div class="ref-col">
          <div class="ref-col-title">フラワー型（ココちゃん）</div>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-flower-original.jpg" alt="フラワー型 元画像" loading="lazy"><figcaption><b>元画像</b>（ご入稿データ）</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-flower-less.jpg" alt="フラワー型 オプションカラー少なめの仕上がり" loading="lazy"><figcaption><b>オプションカラー 少なめ</b>の仕上がり例</figcaption></figure>
          <figure class="ref-fig"><img src="{{CFP_ASSET_URL}}img/ref-flower-more.jpg" alt="フラワー型 オプションカラー多めの仕上がり" loading="lazy"><figcaption><b>オプションカラー 多め</b>の仕上がり例</figcaption></figure>
        </div>
        </div>
        <div class="file-note" style="text-align:center;">※写真はイメージです。実際の色味は、モニターや撮影条件により異なります。お客様のデザインの仕上がりを保証するものではありません。</div>
      </div>
    </details>
  </section>

  <!-- ▼▼▼ ① カーペット用デザイン（お見積り・PSD保存・ご注文の対象） ▼▼▼ -->
  <div class="room-sim-panel" style="margin:25px 0; border-color:#22c55e;">
    <div class="room-sim-panel-title" style="color:#4ade80;">🟩 ① カーペット用デザイン画像（お見積り・PSD保存・ご注文はこちらのデザインが対象になります）</div>

    <div class="file-box">
      <label for="cc-file" style="color:#4ade80;">① カーペット用デザイン画像の選択（JPEG / PNG / GIF / WebP）</label>
      <input type="file" id="cc-file" accept="image/*">
      <div class="file-note">※上の枠内をクリックして画像ファイルを選択してください。お見積り・PSD保存・ご注文はこちらのデザインが対象になります。<br>※元データの解像度が粗い（画素が少ない）場合、文字やラインが潰れてしまう場合がございます。<br>※目安として、10cm角のサイズで画数の多い漢字が表現できる程度の解像度をご用意いただくと安心です。</div>
    </div>

    <!-- 階調表現の値の入れ物（画面には出さない。3つの変換の上のスライダー cc-dither2 で操作する） -->
    <div class="dither-box" hidden style="display:none;">
      <div class="slider-row"><label for="cc-dither">ドットによる階調表現（誤差拡散）量：<span id="cc-dither-val">0</span>%</label><span>0% = メリハリ表現 / 100% = 滑らか表現</span></div>
      <input type="range" id="cc-dither" min="0" max="100" value="0">
    </div>
    
  <div id="cc-status" class="status-box"></div>
  <div class="dither-box cc-img-scale-box">
    <div class="slider-row"><label for="cc-img-scale">画像の大きさ（拡大・縮小）：<span id="cc-img-scale-val">100</span>%</label><span>100% = 指定サイズ＋上下左右5mmいっぱい。小さくして余白が出るところは色を付けません（白く表示・パレットの色は使わない）</span></div>
    <input type="range" id="cc-img-scale" min="30" max="300" step="1" value="100">
  </div>
  <div class="preview-grid cc-variants">
    <div class="preview-card"><h3>元画像（オリジナル）</h3><div class="cc-orig-zoom" id="cc-orig-zoom"><canvas id="cc-original" style="cursor:crosshair;" title="クリックで守る色・ホイールで拡大縮小・ドラッグで移動・ダブルクリックで元の大きさ"></canvas></div><div class="used-colors-text" style="text-align:center;font-size:11px;">🔍 ホイールで拡大・縮小／ドラッグで移動／ダブルクリックで元に戻す</div><div class="used-colors-text" style="text-align:center;">25.4 DPI換算・元データのまま</div><div class="cc-protect"><div class="used-colors-text" style="text-align:left;">🎯 <b>守る色</b>：上の元画像で、残したい色（標識の赤など）をクリックすると、その色を3通りの変換で必ず残します（最大4色）。</div><div id="cc-protect-list" class="psd-palette-grid" style="justify-content:flex-start;"></div></div></div>
    <div class="preview-card cc-var-card" data-var="std"><h3>① 標準色のみ</h3><div class="cc-var-sub">無償の標準色（基本16色＋OP-03・05）から選んだ16色</div><canvas id="cc-var-std"></canvas><div class="psd-palette-grid" id="cc-var-std-chips"></div><div class="used-colors-text" id="cc-var-std-text"></div><button type="button" class="btn-chip-action cc-var-btn" data-var-btn="std">この変換で進める</button></div>
    <div class="preview-card cc-var-card" data-var="op3"><h3>② 標準色＋オプション3色</h3><div class="cc-var-sub">標準色13色＋有償オプション3色＝計16色</div><canvas id="cc-var-op3"></canvas><div class="psd-palette-grid" id="cc-var-op3-chips"></div><div class="used-colors-text" id="cc-var-op3-text"></div><button type="button" class="btn-chip-action cc-var-btn" data-var-btn="op3">この変換で進める</button></div>
    <div class="preview-card cc-var-card" data-var="max"><h3>③ 最大表現（計16色）</h3><div class="cc-var-sub">標準色＋オプションカラーの全色から、元画像に最も近い16色を自動選択（有償色が増えると、お見積もりが上がります）</div><canvas id="cc-var-max"></canvas><div class="psd-palette-grid" id="cc-var-max-chips"></div><div class="used-colors-text" id="cc-var-max-text"></div><button type="button" class="btn-chip-action cc-var-btn" data-var-btn="max">この変換で進める</button></div>
  </div>
  <div class="file-note cc-var-note" id="cc-var-note" style="text-align:center;margin:-6px 0 14px;">画像を選ぶと、3通りの自動変換を表示します。「この変換で進める」を押した変換が、お見積もり・PSD保存・ご注文の対象になります（色は下のパレットで手動でも変えられます）。</div>
  <div class="preview-grid cc-manual-card" id="cc-manual-card" hidden>
    <div class="preview-card"><h3>手動で色を選んだ結果（最小1px表現）</h3><canvas id="cc-reduced"></canvas><div class="used-colors"><label>使用されたカラー（抽出結果）：</label><div id="cc-used-colors" class="psd-palette-grid"></div><div id="cc-used-colors-text" class="used-colors-text"></div></div></div>
  </div>

    <!-- ▼ カラーパレットの版（新・旧） ▼ -->
    <input type="hidden" id="cc-palette-version" value="old">
      <div class="cfp-palver"><span>カラーパレット：</span><button type="button" class="btn-chip-action cfp-palver-btn" data-palver="new" aria-pressed="false">新パレット</button><button type="button" class="btn-chip-action cfp-palver-btn" data-palver="old" aria-pressed="true">旧パレット</button><small>（カーペット・壁紙の両方に反映）</small></div>
    <!-- ▼ 標準カラーパレット用セクション ▼ -->
    <div class="palette-box cc-pal-compact">
      <label>1. 標準カラーパレット（基本色 ＋ 無料オプションカラー OP-03・OP-05）</label>
      <small>※減色時に使用する標準（無料）カラーです。この中やオプションカラーを含めて合計最大16色まで選択して使用できます。</small>
      <div class="palette-controls">
        <button type="button" id="cc-btn-base-clear" class="btn-chip-action">すべて解除</button>
      </div>
      <div id="cc-base-palette-selector" class="palette-select-grid"></div>
    </div>

    <!-- ▼ オプションカラーパレット用セクション ▼ -->
    <div class="palette-box cc-pal-compact" style="border-color:#22c55e;">
      <label style="color:#4ade80;">2. オプションカラーパレット（特注カラー・オリジナル配色／OP-01 〜 OP-30 ※OP-03・05を除く）</label>
      <small>※<strong>オプションカラー（特注カラー・オリジナル配色）は有償</strong>です。1回のご注文につき1色 <strong>¥35,000</strong>（面積に関係なく定額）で加算されます（<strong>10㎡以上はオプションカラー3色まで無料！</strong>）。</small>
      <div class="palette-controls">
        <button type="button" id="cc-btn-op-clear" class="btn-chip-action">すべて解除</button>
      </div>
      <div id="cc-op-palette-selector" class="palette-select-grid"></div>
    </div>

  <div class="dither-box cc-var-dither">
    <div class="slider-row"><label for="cc-dither2">ドットによる階調表現（誤差拡散）量：<span id="cc-dither2-val">0</span>%</label><span>3つの変換すべてと、お見積もり・PSDの画像に反映。0% = メリハリ表現 / 100% = 滑らか表現</span></div>
    <input type="range" id="cc-dither2" min="0" max="100" value="0">
    <div class="slider-row" style="margin-top:10px;"><label for="cc-look">仕上がりの印象（配色の選び方）：</label>
      <select id="cc-look" style="width:auto;min-height:0;padding:6px 10px;">
        <option value="natural" selected>自然（元の印象に近く）</option>
        <option value="crisp">くっきり（柄・文字を見やすく）</option>
        <option value="vivid">鮮やか（華やかに）</option>
        <option value="calm">落ち着き（やわらかく）</option>
      </select></div>
    <small style="display:block;color:#a1a1aa;font-size:11px;line-height:1.5;">元の色との近さだけでなく、明るさ・鮮やかさ・色合いの見え方、色同士の関係（違う色が同じ色につぶれない・明るさの順番を保つ）、柄・文字の輪郭、全体の調和（ほとんど使わない色を増やさない）をまとめて評価して、3通りの変換の16色を選び、色を割り当てます。</small>
  </div>
  <div class="palette-controls" style="justify-content:center;margin:4px 0 6px;">
    <button type="button" id="cc-show-original" class="btn-chip-action" style="padding:8px 16px;font-size:13px;">🖼 元画像を表示（別ウィンドウ）</button>
  </div>
{{CFP_GEMINI_PANEL}}
  <div class="file-note" style="text-align:center;">※上記プレビュー（印刷イメージ）と実際の仕上がりは、モニターの発色や制作工程の都合上、多少異なる場合がございます。</div>
  </div>
  <!-- ▲▲▲ ① カーペット用デザイン ここまで ▲▲▲ -->

  <!-- ▼▼▼ ② 壁紙用デザイン（独立ツール・お見積りには含まれません） ▼▼▼ -->
  <div class="room-sim-panel" style="margin:25px 0; border-color:#3b82f6;">
    <div class="room-sim-panel-title" style="color:#60a5fa;">🟦 ② 壁紙用デザイン画像（下の「お部屋パース」の壁面に使用されます／お見積りには含まれません）</div>

    <div class="file-box">
      <label for="cw-file" style="color:#60a5fa;">壁紙用デザイン画像の選択（JPEG / PNG / GIF / WebP）</label>
      <input type="file" id="cw-file" accept="image/*">
      <div class="file-note">※カーペットとは別の柄を壁紙シミュレーションに使いたい場合はこちらにアップロードしてください。<br>※元データの解像度が粗い（画素が少ない）場合、文字やラインが潰れてしまう場合がございます。<br>※目安として、10cm角のサイズで画数の多い漢字が表現できる程度の解像度をご用意いただくと安心です。</div>
    </div>

    <div class="dither-box cw-reduce-box">
      <label style="display:flex;align-items:center;gap:8px;cursor:pointer;margin:0;"><input type="checkbox" id="cw-reduce-on" style="width:auto;min-height:auto;"> 壁紙を減色する（壁紙はCMYK印刷のため、通常は不要です）</label>
      <div class="file-note" style="margin-top:4px;">チェックしない場合は、元画像の色のまま（減色なし）でパース表示・保存・注文に使います。</div>
    </div>

    <div class="dither-box">
      <div class="slider-row"><label for="cw-dither">ドットによる階調表現（誤差拡散）量：<span id="cw-dither-val">0</span>%</label><span>0% = メリハリ表現 / 100% = 滑らか表現</span></div>
      <input type="range" id="cw-dither" min="0" max="100" value="0">
    </div>

    <div class="dither-box cw-repeat-box">
      <div class="slider-row"><label for="cw-repeat-mm">柄の大きさ（1リピートの横幅）：<input type="number" id="cw-repeat-mm" value="910" min="50" max="20000" step="10" style="width:110px;min-height:0;padding:6px 8px;display:inline-block;"> mm</label><span>縦は画像の縦横比のまま（変形しません）</span></div>
      <div class="slider-row" style="margin-top:10px;"><label for="cw-wall-mode">貼り方：
        <select id="cw-wall-mode" style="width:auto;min-height:0;padding:6px 8px;display:inline-block;">
          <option value="repeat" selected>柄を繰り返して貼る（柄の大きさで指定）</option>
          <option value="center">1枚を壁ごとに中央に貼る</option>
          <option value="wrap">1枚を部屋を一周して続けて貼る（隣の壁へ途切れずに続く）</option>
        </select></label></div>
      <div class="file-note" id="cw-repeat-note" style="margin-top:6px;"></div>
    </div>

      <div class="cfp-palver"><span>カラーパレット：</span><button type="button" class="btn-chip-action cfp-palver-btn" data-palver="new" aria-pressed="false">新パレット</button><button type="button" class="btn-chip-action cfp-palver-btn" data-palver="old" aria-pressed="true">旧パレット</button><small>（カーペット・壁紙の両方に反映）</small></div>
    <div class="palette-box">
      <label>1. 標準カラーパレット（基本色 ＋ 無料オプションカラー OP-03・OP-05）</label>
      <small>※壁紙シミュレーション用の減色に使用するカラーです（カーペット側とは独立して選択できます）。</small>
      <div class="palette-controls">
        <button type="button" id="cw-btn-base-clear" class="btn-chip-action">すべて解除</button>
      </div>
      <div id="cw-base-palette-selector" class="palette-select-grid"></div>
    </div>

    <div class="palette-box" style="margin-top:20px; border-color:#3b82f6;">
      <label style="color:#60a5fa;">2. オプションカラーパレット（特注カラー・オリジナル配色／OP-01 〜 OP-30 ※OP-03・05を除く）</label>
      <small>※<strong>オプションカラー（特注カラー・オリジナル配色）は有償</strong>です。1回のご注文につき1色¥35,000。こちらは壁紙シミュレーション用の色見本です（実際の壁紙製品としての注文機能は含みません）。</small>
      <div class="palette-controls">
        <button type="button" id="cw-btn-op-clear" class="btn-chip-action">すべて解除</button>
      </div>
      <div id="cw-op-palette-selector" class="palette-select-grid"></div>
    </div>

    <div class="preview-grid" style="margin-top:15px;">
      <div class="preview-card"><h3>オリジナル（壁紙用元データ）</h3><canvas id="cw-original"></canvas></div>
      <div class="preview-card"><h3>カラーパレット減色イメージ</h3><canvas id="cw-reduced"></canvas><div class="used-colors"><label>使用されたカラー（抽出結果）：</label><div id="cw-used-colors" class="psd-palette-grid"></div><div id="cw-used-colors-text" class="used-colors-text"></div></div></div>
    </div>
    <div class="file-note" id="cw-status" style="text-align:center;">壁紙用デザイン画像をアップロードしてください。</div>
  </div>
  <!-- ▲▲▲ ② 壁紙用デザイン ここまで ▲▲▲ -->

  <!-- CADお部屋シミュレーション（プラグインが [cad_floor_plan] をここに差し込む） -->
  [cad_floor_plan]

  <section class="perspective-section" id="perspective-section">
    <details class="cfp-fold" id="persp-fold">
      <summary class="cfp-fold-summary"><h2 class="section-title-dark" style="margin-top:0;">🏠 お部屋パース（簡易パースプレビュー）・壁紙のサイズと保存</h2></summary>
      <div class="cfp-fold-body">
    <p class="section-lead-text" style="text-align:center;">上で処理した<strong>① カーペット用</strong>・<strong>② 壁紙用</strong>の減色デザインを、簡易的な部屋のパース（透視図）に自動反映します。<br><strong>※あくまで簡易イメージです。実際の仕上がり・見え方とは異なります。</strong></p>

    <div class="persp-room" id="persp-room">
      <div class="persp-box" id="persp-box">
        <div class="persp-geo" id="persp-geo">
          <div class="persp-back-wall" id="persp-back-wall"></div>
          <div class="persp-floor" id="persp-floor"></div>
          <div class="persp-side-wall" id="persp-side-wall"></div>
        </div>
      </div>
    </div>

    <div class="file-note" style="text-align:center;margin-top:-8px;">パースをドラッグで回転、ホイール（スマホは2本指）で拡大縮小、ダブルクリックで元の向きに戻ります。</div>
    <div class="room-sim-controls" style="max-width:460px;margin:16px auto 0;">

      <div class="persp-size-grid">
        <div class="persp-size-field">
          <label for="persp-width">お部屋の幅（共通・mm）</label>
          <input type="number" id="persp-width" min="300" max="10000" step="50" value="3000">
        </div>
        <div class="persp-size-field">
          <label for="persp-wall-height">壁の高さ（mm）</label>
          <input type="number" id="persp-wall-height" min="300" max="6000" step="50" value="2400">
        </div>
      </div>
      <div class="persp-size-grid">
        <div class="persp-size-field">
          <label for="persp-floor-depth">床の奥行き（mm）</label>
          <input type="number" id="persp-floor-depth" min="300" max="10000" step="50" value="2500">
        </div>
      </div>
      <div class="file-note" style="margin-top:8px;">※「お部屋の幅」は壁の横幅・床の横幅で共通して使われます。</div>
    </div>
    <div class="file-note" id="persp-status" style="text-align:center;">①・②でデザイン画像を処理すると、ここに自動反映されます。</div>

    <div class="palette-controls" style="justify-content:center;margin-top:16px;flex-wrap:wrap;">
      <!-- カーペットのPSD（簡易パースの畳んだ中に入れる） -->
      <button type="button" id="cc-download-psd" class="btn-chip-action" style="padding:10px 18px;font-size:13px;" disabled="">🟩 カーペットのPSDを保存（CAD画像・部屋・変換画像・割付の4レイヤー / RGB / 25.4 DPI / 実寸）</button>
      <button type="button" id="cc-download-svg" class="btn-chip-action" style="padding:10px 18px;font-size:13px;" disabled="">🟪 カーペットのSVGを保存（CAD画像・部屋・変換画像（色ごとのベクター）・割付の4レイヤー / 実寸 mm）</button>
      <button type="button" id="btn-save-floor-image" class="btn-chip-action" style="padding:10px 18px;font-size:13px;">🟧 床デザイン画像を保存（PNG）</button>
      <button type="button" id="btn-save-wall-image" class="btn-chip-action" style="padding:10px 18px;font-size:13px;">🟦 壁紙デザイン画像を保存（CMYK PSD・裁断ガイド付き）</button>
      <button type="button" id="btn-save-wall-print" class="btn-chip-action" style="padding:10px 18px;font-size:13px;">🖨 壁紙へ印刷用に保存（元データ・全体・910mm幅の連続データ・ZIP）</button>
    </div>
    <div class="file-note" style="text-align:center;">※「壁紙へ印刷用に保存」は、壁のデザインを巾ごとに分割し、巾ごとのCMYK PSD（幅＝巾＋合わせ代×2（初期 900＋10＋10＝920mm。910mm巾なら 925mm） × 高さ＝図面の壁の高さ＋上下の余白（初期100mm・壁紙の巾の枠で30〜100mmに変更可）、1px=1mm）をZIPにまとめて保存します。隣の巾とは合わせ代2つ分重なり（1巾が受け持つ壁は巾と同じ初期900mm。重なりの真ん中がカット線）、壁の範囲を赤枠（別レイヤー）で示します。ZIPには、元データ・変換後全体データ・巾の幅で切った長いデータ（巾を縦につなげ、1巾おきに180°回転して天井側どうし・床側どうしがつながる連続データ）も入ります。</div>
    <div class="file-note" style="text-align:center;">※壁紙画像はCMYKのPSD形式（①デザイン層＋②裁断ガイド層の2層）で保存されます（RGBからの単純変換のため、印刷色は校正してください）。高さは「壁の高さ＋上下の余白（裁断代。初期100mm、30〜100mm）」です。ガイドは、壁の範囲の赤枠と、巾の境目（910mm幅で左右10mmずつ重ねるため890mmごと）の縦線です。</div>
      </div>
    </details>
  </section>


  <div class="estimate-summary">
    <div class="summary-title">お見積もり明細（概算）</div>
    <div class="summary-row"><div class="summary-label">パイル形状</div><div class="summary-value"><select id="cc-material2" style="width:auto;min-height:0;padding:6px 10px;"><option value="cut">カットパイル（発色・質感重視）</option><option value="loop">ループパイル（標準・高耐久・重歩行向け）</option></select></div></div>
    <div class="summary-row"><div class="summary-label">選択仕様</div><div class="summary-value" id="cc-material-name">ループパイル (500×500mm)</div></div>
    <div class="summary-row"><div class="summary-label">オプションカラー追加料金 (税別)</div><div class="summary-value" id="cc-op-cost">¥0 (有料オプション色0色)</div></div>
    <div class="summary-row"><div class="summary-label">施工面積（目安）</div><div class="summary-value" id="cc-area">1.00 m²</div></div>
    <div class="summary-row"><div class="summary-label">商品小計 (税別)</div><div class="summary-value" id="cc-subtotal">¥15,500</div></div>
    <div class="summary-row"><div class="summary-label">送料 (税別・箱数計算)</div><div class="summary-value" id="cc-shipping">¥2,000</div></div>
    <div class="summary-row"><div class="summary-label">消費税 (10%)</div><div class="summary-value" id="cc-tax">¥1,750</div></div>
    <div class="delivery-notice-box"><div class="delivery-notice-icon">🚚</div><div><div class="delivery-notice-title">お届け目安</div><div class="delivery-notice-text">標準納期：デザイン確定から2週間〜</div><div style="font-size:12px;color:#d4d4d8;margin-top:4px;">※デザイン・サイズにより変わります。お急ぎの場合は必ず事前に納期をお問い合わせください。<br>※配送はヤマト運輸（クロネコヤマト便）にて発送いたします。</div></div></div>
    <div class="summary-row total"><div class="summary-label">合計金額 (税込)</div><div class="summary-value" id="cc-total">¥19,250</div></div>
    <div class="file-note" style="text-align:center;margin-top:12px;">※画面上でご確認いただいているプレビュー・パース表示はあくまでイメージです。実際の製品の色味・質感・見え方とは異なる場合がございます。</div>
    <div class="file-note cancel-note" style="text-align:center;margin-top:6px;">※キャンセルについて：ご注文（発注）後3日以内は無償でキャンセル承ります。それ以降のキャンセルはお受けできませんので、あらかじめご了承ください。</div>
  </div>

  <button type="button" id="cc-delivery-inquiry" class="btn-submit" style="background:#6366f1;color:#fff;margin-top:15px;">📅 納期についてお問い合わせする（正式ご注文前に必ずご確認ください）（その他仕上がり、大口、カット等ご相談はこちら）</button>

  <div class="customer-info-section">
    <div class="customer-info-title">ご注文者様情報</div>
    <div class="form-group"><label for="cc-name">お名前<span class="required">*</span></label><input type="text" id="cc-name" placeholder="山田 太郎"></div>
    <div class="form-group"><label for="cc-company">法人名・屋号（法人・店舗様のみ）</label><input type="text" id="cc-company" placeholder="株式会社〇〇"></div>
    <div class="form-group"><label for="cc-tel">電話番号<span class="required">*</span></label><input type="tel" id="cc-tel" placeholder="090-1234-5678"></div>
    <div class="form-group"><label for="cc-email">メールアドレス<span class="required">*</span></label><input type="text" id="cc-email" placeholder="example@yasu-room.com"></div>
    <div class="form-group"><label for="cc-address">お届け先ご住所<span class="required">*</span></label><input type="text" id="cc-address" placeholder="東京都千代田区1-1-1"><small id="cc-address-region">※都道府県から入力すると、送料の地域を自動で選びます。</small></div>
    <div class="form-group" style="flex-direction:row;align-items:center;gap:8px;">
      <input type="checkbox" id="cc-receipt" style="width:auto;min-height:auto;">
      <label for="cc-receipt" style="margin:0;">領収書が必要</label>
    </div>
  </div>
  <div class="cfp-agree-grid">
    <div class="cfp-agree-box">
      <div style="display:flex;align-items:flex-start;gap:10px;">
        <input type="checkbox" id="cc-copyright-ok" style="width:auto;min-height:auto;margin-top:4px;">
        <label for="cc-copyright-ok" style="margin:0;cursor:pointer;">ご入稿のデザインは、第三者の著作権・商標権・肖像権などを侵害しないことを確認しました。<span class="required">*</span></label>
      </div>
    </div>
    <div class="cfp-agree-box">
      <div style="display:flex;align-items:flex-start;gap:10px;">
        <input type="checkbox" id="cc-quality-ok" disabled style="width:auto;min-height:auto;margin-top:4px;">
        <label for="cc-quality-ok" style="margin:0;cursor:pointer;">捺染印刷タイルカーペット製品「品質基準について」（マッシュオフィス・2026年01月20日制定）の内容を、最後まで読み、理解し、同意しました。<span class="required">*</span></label>
      </div>
      <button type="button" id="cc-quality-open" class="btn-chip-action" style="margin-top:8px;">📄 品質基準を読む（最後までスクロールするとチェックできます）</button>
      <div class="cfp-qs" id="cc-quality-doc" hidden tabindex="0" aria-label="品質基準について（全文）">
<div class="qs-title">捺染印刷タイルカーペット製品　品質基準について</div>
<div class="qs-meta">マッシュオフィス　制定日：2026年01月20日</div>

<h4>1. 本書について</h4>
<p>本書は、当社が製造する捺染方式による意匠タイルカーペット製品について、製品の特性、品質の考え方、納品時の確認基準および対応範囲について、あらかじめご理解を共有させていただくことを目的として作成したものです。御取引先様と当社が、共通の認識のもとで円滑にお取引を進めさせていただくための資料としてご活用ください。</p>

<h4>2. 対象製品について</h4>
<p>本書は、以下の製品を対象とします。</p>
<ul>
<li>インクジェット方式（捺染方式）による意匠印刷タイルカーペット</li>
<li>カットパイル、ループパイルの2種類</li>
<li>16色特色印刷機による、文字、画像やグラデーション表現を含む製品</li>
<li>使用色については、最大16色の組合せの範囲にて、以下より選択となります
<ul>
<li>無償カラー16色</li>
<li>有償オプションカラー30色（別途見積）※OP-03・OP-5は無償適用</li>
<li>有償特注色（別途見積）</li>
</ul></li>
<li>納入仕様は、カット・ループともに500mm角仕上げを標準とします（変則サイズへのカット加工も可：別途見積）</li>
</ul>

<h4>3. 製品および印刷方式の特性について</h4>
<p>本製品は、ナイロン繊維素材に染料インクをインクジェット方式にて浸透・定着させる「捺染方式」による印刷製品です。そのため、以下のような特性があります。</p>
<ul>
<li>繊維構造、毛流れ、パイル密度、下地色の影響により、色味・濃度・階調に個体差が生じます</li>
<li>同一データであっても、印刷ロットや基材ロットの違いにより、色調に差が生じる場合があります</li>
<li>染料調合・捺染印刷の特性上、厳密な色合わせができないことがあります</li>
<li>照明条件、見る角度、施工方向により、見え方が変化することがあります</li>
</ul>
<p>これらは捺染方式および繊維製品の構造上、避けることのできない特性となりますため、あらかじめご理解いただけますようお願いいたします。</p>

<h4>4. 白地タイルカーペット基材のロット差について</h4>
<p>本製品は、別注製造の白地タイルカーペット基材に印刷加工を行っています。そのため、基材の製造ロットにより、以下のような差異が生じる場合があります。</p>
<ul>
<li>白さ（白味・黄味・青味）のわずかな違い</li>
<li>パイル密度、パイル高さ、繊維配向の微差</li>
<li>表面質感、光の反射の見え方の違い</li>
</ul>
<p>これらの違いは、印刷後の発色や見え方に影響する場合がありますが、基材メーカーの規格範囲内のものにつきましては、製品の特性としてご理解をお願いいたします。</p>

<h4>5. 印刷再現性について</h4>
<h5>5-1. 色調再現、文字や線の再現性について</h5>
<p>本製品は、別注製造の白地タイルカーペット基材に印刷加工を行っています。そのため、基材の製造ロットにより、以下のような差異が生じる場合があります。</p>
<ul>
<li>オフセット印刷のような数値指定（管理）による厳密な色合わせは、捺染印刷の特性上、技術的に困難であり行っておりません</li>
<li>事前にご確認・ご承認いただいた色校正またはカラーチャートサンプルとの見た目の印象を基準とします</li>
<li>印刷機の解像度により文字や線の再現には最小サイズの制限があります。</li>
<li>通常の使用環境において、意匠として大きな違和感のない状態を目安とします</li>
</ul>
<p class="qs-note">※完全に同一の色になることを保証するものではありません。<br>※色校正（サンプル作成）は有償にて承ります。</p>
<h5>5-2. 写真調画像およびグラデーション表現について</h5>
<p>写真調画像やグラデーションにつきましては、16色特色印刷の使用範囲内にて、以下の点を目安に、見た目での確認を基準とします。</p>
<ul>
<li>縞状のムラ（バンディング）が目立たないこと</li>
<li>不自然な色飛びや色溜まりがないこと</li>
<li>階調がなだらかに見えること（階調表現に使用する色数に準ずる）</li>
<li>16色特色印刷の使用範囲内で、元画像（写真調）の印象が再現されていること</li>
</ul>

<h4>6. ロット差（基材ロット・印刷ロット）について</h4>
<ul>
<li>印刷ロットおよび基材ロットの違いにより、色味・濃度・質感に差が生じる場合があります</li>
<li>同一物件内でご使用の場合は、同一基材ロット・同一印刷ロットでの納品をおすすめします</li>
<li>追加生産時における、過去製作分との色味の完全な一致は、あらかじめご容赦ください</li>
</ul>

<h4>7. 支給データについて</h4>
<ul>
<li>ご支給いただくデータの内容（解像度、色空間、画像品質等）に起因する仕上がりにつきましては、あらかじめご了承ください。</li>
</ul>

<h4>8. 色校正・意匠確認について</h4>
<ul>
<li>色校正（サンプル作成）は有償にて承ります。実施の要否につきましては、御取引先様のご判断にお任せいたします。</li>
<li>色味・意匠は、事前の色校正サンプルのご承認、または事前配布のカラーチャートサンプルでのご理解をもって最終決定とさせていただきます。</li>
<li>ご承認後の色味・意匠に関するご要望につきましては、原則として再製作の対象外となります。</li>
</ul>

<h4>9. 納品時の出荷前検品および確認基準</h4>
<h5>9-1. 納品可能な状態</h5>
<p>以下のような状態で、通常のご使用において意匠上大きな違和感がないものを、納品可能な状態とします。</p>
<ul>
<li>軽微な色味差、濃淡差、階調差</li>
<li>パイル方向や基材差による見え方の違い</li>
<li>ロット差に起因する軽微な差異</li>
</ul>
<div class="qs-box">
<div class="qs-box-title">【注記事項：パイルの一時的な傾倒について】</div>
<p>納品形態の都合上、出荷前の保管時や輸送時において、梱包状態での積み重ねによる荷重（外圧）の影響を受け、納品直後の製品においてパイルが一時的に、また1枚単位でランダムな方向へ傾倒（寝ている状態）している場合があります。</p>
<p>このようなパイルの一時的な傾倒状態により、施工直後において、雲状または色差のような「色ムラ」として認識される現象が発生する場合があります。</p>
<p>しかしながら、本製品は弾性回復力（復元性）を有しており、通常の歩行使用が継続されることで、パイルの傾倒状態は徐々に回復し、ジョイント部分を含めパイルの向きも自然に馴染んでくるため、これに伴い色ムラと見える状態も次第に解消されていきます。</p>
<p>なお、これらの現象は出荷前の保管状態および輸送時の荷重環境に起因するものであり、出荷前検品の段階では確認ができない内容となります。また、施工後一定期間における一時的な色ムラの発生を完全に回避することは難しいと考えております。</p>
<p>ただし、当社といたしましても、保管時および輸送時において過度なパイルの乱れが発生しないよう、梱包方法や取り扱いには細心の注意を払い、品質保持に努めてまいります。</p>
</div>
<p class="qs-sub">【検品方法】</p>
<ul>
<li>検品エリアへ製品を敷き詰め、目視にて確認を行います（㎡数の多い物件は、複数回に分けて確認）</li>
<li>品質・検品チェックリストに基づき、印刷の仕上がり、柄のつながり、色差、基材サイズ、状態、ナンバリング、梱包状態、梱包箱ラベル等の内容を確認します</li>
</ul>
<div class="qs-box">
<div class="qs-box-title">【目視確認の方法について】</div>
<p>目視による色差および仕上がりの確認は、検品エリアにおいて品質チェックリストの定める手順に基づき一定の照明条件のもと、最低2名以上により、複数方向かつ複数の観察距離から、承認色見本または基準サンプル等と比較確認を行い、特定の個人の判断に依存しない形で、総合的かつ客観的に製品評価を行うものとします。</p>
</div>
<h5>9-2. 納品前に確認・協議が必要な状態</h5>
<p>以下のような場合は、当社にて内容を確認の上、御取引先様と対応を協議させていただきます。</p>
<ul>
<li>承認見本と比べて明らかに印象が異なる場合</li>
<li>明確な色違い、柄ズレ、印刷欠損、著しい汚れやキズがある場合</li>
<li>グラデーションに不自然なムラや段差が見られる場合（段差の許容範囲は使用色数に準ずる）</li>
<li>連結（隣接）するタイル間において、通常使用環境下で視覚的に明確な色差が認められる場合（当社確認の上）</li>
</ul>

<h4>10. 再製作について</h4>
<h5>10-1. 当社にて対応させていただくケース</h5>
<p>以下のような場合は、当社の製造上の不具合として、再製作にて対応いたします。</p>
<ul>
<li>入稿データと異なる内容で出力されている場合</li>
<li>明らかな印刷欠損、著しい汚れやキズ、柄ズレがある場合</li>
<li>上記「9-2」に該当し、当社に起因すると判断される場合</li>
</ul>
<h5>10-2. 対応が難しいケース</h5>
<p>以下のような場合は、製品の特性や使用条件によるものとして、再製作の対象外とさせていただく場合があります。</p>
<ul>
<li>捺染方式や繊維素材の特性による色味差、濃淡差、階調差</li>
<li>基材ロット差、印刷ロット差による見え方の違い</li>
<li>追加生産時の過去製作分との色味・質感の違い</li>
<li>照明条件、施工方向、使用環境による見え方の違い</li>
<li>経年変化や摩耗による外観変化</li>
</ul>

<h4>11. 検収および施工前のご確認のお願い</h4>
<ul>
<li>施工前に、必ず内容および仕上がりのご確認をお願いいたします。</li>
<li>外観・印刷品質に関するご連絡は、納品後10営業日以内にお願いいたします。</li>
<li>施工後の貼り替え等に関わる費用につきましては、原則として当社ではご負担いたしかねます。</li>
</ul>

<h4>12. 損害賠償責任の範囲について</h4>
<p>万一、当社の責に帰すべき事由により製品に不具合が生じた場合の対応につきましては、当該製品の再製作費相当額を上限として対応させていただくものとします。なお、施工費、貼り替え工事費、工期遅延等に伴う付帯費用、逸失利益を含む間接損害および二次的損害につきましては、恐縮ですがご負担いたしかねます。</p>

<h4>13. その他</h4>
<ul>
<li>物性データ（性能・仕様値）につきましては、別紙「製品仕様書」に記載します。</li>
<li>本書に記載のない事項や、判断が難しい場合につきましては、都度、御取引先様と協議の上、対応を決定させていただきます。</li>
</ul>
<div class="qs-end">― 以上 ―</div>
      </div>
      <div class="cfp-qs-status" id="cc-quality-status">※品質基準を最後まで読むと、チェックできるようになります。</div>
    </div>
  </div>
  <button type="button" id="cc-send-mail" class="btn-submit">この内容で注文メールを作成する</button>
  <div class="file-note">※クリックすると、ご注文内容とデザインデータへのダウンロードリンクを記載したメールが送信されます（デザインファイルはサーバーに保存され、60日間ダウンロード可能です）。</div>
  <div class="cocoon-debug" id="cc-debug" aria-live="polite">システム待機中... 画像を選択してください。</div>
</div>

<script>
(function () {
  'use strict';

  const FREE_PALETTE = [
    { rgb: [239,239,239], name: '基本-01', isOp: false, price: 0 },
    { rgb: [232,171,130], name: '基本-02', isOp: false, price: 0 },
    { rgb: [219,149,20],  name: '基本-03', isOp: false, price: 0 },
    { rgb: [137,137,137], name: '基本-04', isOp: false, price: 0 },
    { rgb: [149,183,225], name: '基本-05', isOp: false, price: 0 },
    { rgb: [200,22,30],   name: '基本-06', isOp: false, price: 0 },
    { rgb: [220,83,16],   name: '基本-07', isOp: false, price: 0 },
    { rgb: [250,190,0],   name: '基本-08', isOp: false, price: 0 },
    { rgb: [33,143,73],   name: '基本-09', isOp: false, price: 0 },
    { rgb: [0,94,173],    name: '基本-10', isOp: false, price: 0 },
    { rgb: [91,17,49],    name: '基本-11', isOp: false, price: 0 },
    { rgb: [93,43,23],    name: '基本-12', isOp: false, price: 0 },
    { rgb: [50,43,41],    name: '基本-13', isOp: false, price: 0 },
    { rgb: [38,63,34],    name: '基本-14', isOp: false, price: 0 },
    { rgb: [8,42,73],     name: '基本-15', isOp: false, price: 0 },
    { rgb: [0,0,0],       name: '基本-16', isOp: false, price: 0 },
    { rgb: [221, 74, 150], name: 'OP-03',  isOp: false, price: 0 },
    { rgb: [182, 0, 105],  name: 'OP-05',  isOp: false, price: 0 }
  ];

  const OP_PALETTE_RAW = [
    { rgb: [252, 195, 222], name: 'OP-01', price: 35000 },
    { rgb: [245, 161, 199], name: 'OP-02', price: 35000 },
    { rgb: [207, 40, 132],  name: 'OP-04', price: 35000 },
    { rgb: [243, 167, 49], name: 'OP-06', price: 35000 },
    { rgb: [240, 129, 14], name: 'OP-07', price: 35000 },
    { rgb: [118, 47, 21],  name: 'OP-08', price: 35000 },
    { rgb: [171, 29, 34],   name: 'OP-09', price: 35000 },
    { rgb: [98, 0, 2],      name: 'OP-10', price: 35000 },
    { rgb: [255, 250, 194], name: 'OP-11', price: 35000 },
    { rgb: [255, 233, 140], name: 'OP-12', price: 35000 },
    { rgb: [170, 195, 81],  name: 'OP-13', price: 35000 },
    { rgb: [118, 157, 65],  name: 'OP-14', price: 35000 },
    { rgb: [87, 139, 51],   name: 'OP-15', price: 35000 },
    { rgb: [190, 233, 239], name: 'OP-16', price: 35000 },
    { rgb: [0, 176, 206],   name: 'OP-17', price: 35000 },
    { rgb: [0, 113, 140],   name: 'OP-18', price: 35000 },
    { rgb: [11, 49, 143],   name: 'OP-19', price: 35000 },
    { rgb: [36, 55, 78],    name: 'OP-20', price: 35000 },
    { rgb: [139, 92, 163],  name: 'OP-21', price: 35000 },
    { rgb: [99, 50, 125],   name: 'OP-22', price: 35000 },
    { rgb: [69, 37, 102],   name: 'OP-23', price: 35000 },
    { rgb: [50, 65, 37],    name: 'OP-24', price: 35000 },
    { rgb: [0, 54, 45],     name: 'OP-25', price: 35000 },
    { rgb: [192, 135, 65],  name: 'OP-26', price: 35000 },
    { rgb: [153, 83, 37],   name: 'OP-27', price: 35000 },
    { rgb: [85, 46, 33],    name: 'OP-28', price: 35000 },
    { rgb: [43, 10, 5],     name: 'OP-29', price: 35000 },
    { rgb: [247, 247, 247], name: 'OP-30', price: 35000 }
  ];

  const ALL_COLORS = [
    ...FREE_PALETTE,
    ...OP_PALETTE_RAW.map(op => ({ rgb: op.rgb, name: op.name, isOp: true, price: op.price }))
  ];


  // カラーパレットの版：新パレットと旧パレット（初期）。色の名前・番号・価格は同じで、色（RGB）だけが違う。
  // 旧パレットは上の FREE_PALETTE・OP_PALETTE_RAW の色
  const PALETTE_VERSIONS = {
    new: { label: '新パレット', rgb: {
      '基本-01': [239, 239, 239], '基本-02': [232, 171, 130], '基本-03': [219, 149, 20], '基本-04': [120, 120, 120],
      '基本-05': [149, 183, 225], '基本-06': [150, 0, 14], '基本-07': [190, 55, 0], '基本-08': [250, 190, 0],
      '基本-09': [0, 100, 27], '基本-10': [0, 44, 148], '基本-11': [70, 0, 32], '基本-12': [72, 29, 23],
      '基本-13': [38, 30, 30], '基本-14': [10, 35, 8], '基本-15': [8, 25, 48], '基本-16': [0, 0, 0],
      'OP-01': [252, 195, 222], 'OP-02': [245, 161, 199], 'OP-03': [221, 74, 150], 'OP-04': [190, 40, 132],
      'OP-05': [157, 5, 80], 'OP-06': [238, 150, 47], 'OP-07': [215, 110, 7], 'OP-08': [83, 30, 4],
      'OP-09': [119, 0, 14], 'OP-10': [61, 0, 15], 'OP-11': [245, 243, 189], 'OP-12': [245, 230, 140],
      'OP-13': [163, 195, 81], 'OP-14': [103, 150, 47], 'OP-15': [75, 113, 21], 'OP-16': [190, 233, 239],
      'OP-17': [0, 155, 188], 'OP-18': [0, 82, 100], 'OP-19': [6, 12, 110], 'OP-20': [18, 28, 42],
      'OP-21': [120, 82, 155], 'OP-22': [70, 13, 100], 'OP-23': [40, 7, 70], 'OP-24': [27, 35, 10],
      'OP-25': [0, 28, 25], 'OP-26': [141, 90, 29], 'OP-27': [128, 65, 17], 'OP-28': [64, 31, 27],
      'OP-29': [40, 14, 9], 'OP-30': [247, 247, 247]
    } },
    old: { label: '旧パレット', rgb: {} }
  };
  ALL_COLORS.forEach((c) => { PALETTE_VERSIONS.old.rgb[c.name] = c.rgb.slice(); });
  let paletteVersion = 'old';
  // パレットの版を切り替える：色を入れ替え、パレットのチップ・3通りの変換・手動の変換・見積もり・壁紙の変換を作り直す
  function applyPaletteVersion(v, quiet) {
    if (!PALETTE_VERSIONS[v]) v = 'old';
    const map = PALETTE_VERSIONS[v].rgb;
    ALL_COLORS.forEach((c) => { if (map[c.name]) c.rgb = map[c.name].slice(); });
    OP_PALETTE_RAW.forEach((c) => { if (map[c.name]) c.rgb = map[c.name].slice(); });
    paletteVersion = v;
    ['cc', 'cw'].forEach((p) => {
      const base = $(p + '-base-palette-selector'), op = $(p + '-op-palette-selector');
      if (base) Array.from(base.children).forEach((el, i) => { const c = ALL_COLORS[i]; if (c) el.style.backgroundColor = 'rgb(' + c.rgb.join(',') + ')'; });
      if (op) Array.from(op.children).forEach((el, j) => { const c = ALL_COLORS[FREE_COUNT + j]; if (c) el.style.backgroundColor = 'rgb(' + c.rgb.join(',') + ')'; });
    });
    document.querySelectorAll('.cfp-palver-btn').forEach((b) => {
      const on = b.getAttribute('data-palver') === v;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    const hid = $('cc-palette-version');
    if (hid) hid.value = v;
    if (quiet) return;
    // 3通りの変換の色は新しい色で選び直す（renderVariants の key にパレットの版を入れてある）。
    // 選んでいた変換（①②③）はそのまま。手動で選んだ色の組合せなら、その色（名前）のまま新しい色で変換する
    if (state.variantSets ? !Object.keys(VARIANTS).some((k) => sameSet(state.variantSets[k], state.activePaletteIndices)) : false) state.skipAutoVariant = true;
    if ($('cc-original') ? $('cc-original').width : false) reprocessReduction();
    calculateEstimate();
    if (typeof reprocessWallReduction === 'function') reprocessWallReduction();
  }
  window.cfpPaletteVersion = () => paletteVersion;

  const state = {
    loadedImg: null,
    activePaletteIndices: new Set(),
    lastUsedColorEntries: []
  };

  const $ = (id) => document.getElementById(id);

  function debug(msg, isError = false) {
    const el = $('cc-debug');
    if (!el) return;
    el.textContent = msg;
    if (isError) console.error('[Cocoon Carpet Error]', msg);
  }

  function setStatus(type, message) {
    const el = $('cc-status');
    if (!el) return;
    el.className = 'status-box ' + (type || '');
    el.innerHTML = message || '';
    el.style.display = message ? 'block' : 'none';
  }

  function getUnitPrice(materialType, area) {
    if (materialType === 'cut') {
      if (area < 1.0) return 18400;
      if (area < 10.0) return 16300;
      return 14000;
    } else {
      if (area < 1.0) return 17500;
      if (area < 10.0) return 15500;
      return 13300;
    }
  }

  function getOptionCost(area) {
    let paidCols = [];
    state.activePaletteIndices.forEach(idx => {
      const col = ALL_COLORS[idx];
      if (col && col.isOp && col.price > 0) paidCols.push(idx);
    });
    let paidCount = paidCols.length;
    let freeLimit = (area >= 10.0) ? 3 : 0;
    let chargeableCount = Math.max(0, paidCount - freeLimit);
    // オプションカラーは「1回のご注文で1色につき¥35,000」の定額（面積には比例しない）
    const PRICE_PER_COLOR = 35000;
    let totalOpAdd = chargeableCount * PRICE_PER_COLOR;
    return {
      cost: Math.round(totalOpAdd),
      paidCount: paidCount,
      freeApplied: Math.min(freeLimit, paidCount)
    };
  }

  const TAX_RATE = 0.10;

  function getTilesPerBox(materialType) {
    // ループパイル：1箱20枚（5㎡）／カットパイル：1箱16枚（4㎡）
    return materialType === 'loop' ? 20 : 16;
  }

  function updateTileCount() {
    const widthMm = parseFloat($('cc-width')?.value) || 0;
    const heightMm = parseFloat($('cc-height')?.value) || 0;
    const tilesX = Math.max(1, Math.ceil(widthMm / 500));
    const tilesY = Math.max(1, Math.ceil(heightMm / 500));
    const totalTiles = tilesX * tilesY;
    const materialType = $('cc-material')?.value || 'loop';
    const tilesPerBox = getTilesPerBox(materialType);
    if ($('cc-tile-count')) {
      $('cc-tile-count').textContent = '合計カーペット枚数：' + totalTiles + '枚（横' + tilesX + '枚 × 縦' + tilesY + '枚）※1箱' + tilesPerBox + '枚入り換算で送料計算';
    }
    return { tilesX, tilesY, totalTiles };
  }

  function calculateEstimate() {
    const widthMm = parseFloat($('cc-width')?.value) || 0;
    const heightMm = parseFloat($('cc-height')?.value) || 0;
    const area = (widthMm / 1000) * (heightMm / 1000);
    if ($('cc-area')) $('cc-area').textContent = area.toFixed(2) + ' m²';

    const { totalTiles } = updateTileCount();

    const material = $('cc-material');
    const materialType = material?.value || 'loop';
    const unitPrice = getUnitPrice(materialType, area);
    const unitPriceTax = Math.round(unitPrice * (1 + TAX_RATE));
    const materialName = materialType === 'cut' ? 'カットパイル' : 'ループパイル';

    if ($('cc-material-name')) $('cc-material-name').textContent = materialName + ' (500x500mm / ¥' + unitPrice.toLocaleString() + '/m² 税別・税込¥' + unitPriceTax.toLocaleString() + '/m²)';

    const opInfo = getOptionCost(area);
    let opText = '¥' + opInfo.cost.toLocaleString() + ' (有料特注色 ' + opInfo.paidCount + '色';
    if (opInfo.freeApplied > 0) opText += ' / 10㎡以上適用・特注3色無料特典適用中';
    opText += ')';
    if ($('cc-op-cost')) $('cc-op-cost').textContent = opText;

    const subtotal = Math.round(area * unitPrice) + opInfo.cost;
    const tilesPerBox = getTilesPerBox(materialType);
    const boxes = Math.max(1, Math.ceil(totalTiles / tilesPerBox));
    const region = $('cc-region');
    const selectedRegion = region?.options[region.selectedIndex];
    const shippingPerBox = parseFloat(selectedRegion?.dataset.shipping) || 2000;
    const shipping = shippingPerBox * boxes;
    const tax = Math.round((subtotal + shipping) * TAX_RATE);
    const total = subtotal + shipping + tax;

    if ($('cc-subtotal')) $('cc-subtotal').textContent = '¥' + subtotal.toLocaleString();
    const regionName = selectedRegion ? selectedRegion.textContent.split(' (')[0] : '';
    if ($('cc-shipping')) $('cc-shipping').textContent = '¥' + shipping.toLocaleString() + ' (' + boxes + '箱' + (regionName ? '・' + regionName : '') + ')';
    // パイル形状の選択（お見積もり明細）と、畳んだ欄の見出しの要約をそろえる
    if ($('cc-material2')) $('cc-material2').value = materialType;
    if ($('cc-spec-sum')) $('cc-spec-sum').textContent = '（' + materialName + '・' + Math.round(widthMm) + '×' + Math.round(heightMm) + 'mm・' + regionName + '）';
    if ($('cc-tax')) $('cc-tax').textContent = '¥' + tax.toLocaleString();
    if ($('cc-total')) $('cc-total').textContent = '¥' + total.toLocaleString();
  }

  function initPalette() {
    const baseContainer = $('cc-base-palette-selector');
    const opContainer = $('cc-op-palette-selector');
    if (!baseContainer || !opContainer) return;
    
    if (baseContainer.children.length === 0) {
      for (let i = 0; i < FREE_PALETTE.length; i++) {
        const col = FREE_PALETTE[i];
        const chip = document.createElement('div');
        chip.className = 'palette-select-chip';
        if (i < 16) {
          chip.classList.add('active');
          state.activePaletteIndices.add(i);
        }
        chip.style.backgroundColor = `rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
        chip.title = col.name;
        chip.textContent = col.name.includes('基本-') ? col.name.replace('基本-', '') : col.name;

        chip.addEventListener('click', () => {
          if (state.activePaletteIndices.has(i)) {
            state.activePaletteIndices.delete(i);
            chip.classList.remove('active');
          } else {
            if (state.activePaletteIndices.size >= 16) {
              alert('選択できるカラーは合計最大16色までです。');
              return;
            }
            state.activePaletteIndices.add(i);
            chip.classList.add('active');
          }
          reprocessReduction();
          calculateEstimate();
        });
        baseContainer.appendChild(chip);
      }
    }

    if (opContainer.children.length === 0) {
      for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
        const op = OP_PALETTE_RAW[j];
        const globalIndex = FREE_PALETTE.length + j;
        const chip = document.createElement('div');
        chip.className = 'palette-select-chip op-chip';
        chip.style.backgroundColor = `rgb(${op.rgb[0]},${op.rgb[1]},${op.rgb[2]})`;
        chip.title = op.name + ' (特注: 1回の注文につき¥35,000)';
        chip.textContent = op.name;

        chip.addEventListener('click', () => {
          if (state.activePaletteIndices.has(globalIndex)) {
            state.activePaletteIndices.delete(globalIndex);
            chip.classList.remove('active');
          } else {
            if (state.activePaletteIndices.size >= 16) {
              alert('選択できるカラーは合計最大16色までです。');
              return;
            }
            state.activePaletteIndices.add(globalIndex);
            chip.classList.add('active');
          }
          reprocessReduction();
          calculateEstimate();
        });
        opContainer.appendChild(chip);
      }
    }

    const btnBaseAll = $('cc-btn-base-all');
    const btnBaseClear = $('cc-btn-base-clear');
    if (btnBaseAll) {
      btnBaseAll.onclick = () => {
        for (let i = 0; i < FREE_PALETTE.length; i++) {
          if (state.activePaletteIndices.size < 16) state.activePaletteIndices.add(i);
        }
        baseContainer.querySelectorAll('.palette-select-chip').forEach((el, idx) => {
          if (state.activePaletteIndices.has(idx)) el.classList.add('active');
        });
        reprocessReduction();
        calculateEstimate();
      };
    }
    if (btnBaseClear) {
      btnBaseClear.onclick = () => {
        for (let i = 0; i < FREE_PALETTE.length; i++) state.activePaletteIndices.delete(i);
        baseContainer.querySelectorAll('.palette-select-chip').forEach(el => el.classList.remove('active'));
        reprocessReduction();
        calculateEstimate();
      };
    }

    const btnOpAll = $('cc-btn-op-all');
    const btnOpClear = $('cc-btn-op-clear');
    if (btnOpAll) {
      btnOpAll.onclick = () => {
        for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
          const globalIndex = FREE_PALETTE.length + j;
          if (state.activePaletteIndices.size < 16) state.activePaletteIndices.add(globalIndex);
        }
        opContainer.querySelectorAll('.palette-select-chip').forEach((el, j) => {
          if (state.activePaletteIndices.has(FREE_PALETTE.length + j)) el.classList.add('active');
        });
        reprocessReduction();
        calculateEstimate();
      };
    }
    if (btnOpClear) {
      btnOpClear.onclick = () => {
        for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
          state.activePaletteIndices.delete(FREE_PALETTE.length + j);
        }
        opContainer.querySelectorAll('.palette-select-chip').forEach(el => el.classList.remove('active'));
        reprocessReduction();
        calculateEstimate();
      };
    }
  }

  function getActivePaletteEntries() {
    if (state.activePaletteIndices.size === 0) return [FREE_PALETTE[0]];
    return Array.from(state.activePaletteIndices).sort((a,b) => a-b).map(i => ALL_COLORS[i]);
  }

  function getActivePalette() {
    return getActivePaletteEntries().map(e => e.rgb);
  }

  // =====================================================================
  // ② 壁紙用デザイン（独立ツール／お見積りには含まれない・お部屋シミュレーションの壁面用）
  // カーペット側と同じ減色ロジック（findClosestPaletteIndex / getReducedImageData）を再利用しつつ、
  // 状態(cwState)とUI(id="cw-*")はカーペット側(state / id="cc-*")と完全に分離する。
  // 同じidを複製すると document.getElementById が常に最初の要素のみを参照してしまい、
  // 2つ目のアップロードが反映されない不具合が起きるため、id体系を明確に分けている。
  // =====================================================================
  const cwState = {
    loadedImg: null,
    activePaletteIndices: new Set(),
    lastUsedColorEntries: []
  };

  function setWallStatus(msg) {
    const el = $('cw-status');
    if (el) el.textContent = msg;
  }

  function getWallActivePaletteEntries() {
    if (cwState.activePaletteIndices.size === 0) return [FREE_PALETTE[0]];
    return Array.from(cwState.activePaletteIndices).sort((a,b) => a-b).map(i => ALL_COLORS[i]);
  }

  function initWallPalette() {
    const baseContainer = $('cw-base-palette-selector');
    const opContainer = $('cw-op-palette-selector');
    if (!baseContainer || !opContainer) return;

    if (baseContainer.children.length === 0) {
      for (let i = 0; i < FREE_PALETTE.length; i++) {
        const col = FREE_PALETTE[i];
        const chip = document.createElement('div');
        chip.className = 'palette-select-chip';
        if (i < 16) {
          chip.classList.add('active');
          cwState.activePaletteIndices.add(i);
        }
        chip.style.backgroundColor = `rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
        chip.title = col.name;
        chip.textContent = col.name.includes('基本-') ? col.name.replace('基本-', '') : col.name;

        chip.addEventListener('click', () => {
          if (cwState.activePaletteIndices.has(i)) {
            cwState.activePaletteIndices.delete(i);
            chip.classList.remove('active');
          } else {
            if (cwState.activePaletteIndices.size >= 16) {
              alert('選択できるカラーは合計最大16色までです。');
              return;
            }
            cwState.activePaletteIndices.add(i);
            chip.classList.add('active');
          }
          reprocessWallReduction();
        });
        baseContainer.appendChild(chip);
      }
    }

    if (opContainer.children.length === 0) {
      for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
        const op = OP_PALETTE_RAW[j];
        const globalIndex = FREE_PALETTE.length + j;
        const chip = document.createElement('div');
        chip.className = 'palette-select-chip op-chip';
        chip.style.backgroundColor = `rgb(${op.rgb[0]},${op.rgb[1]},${op.rgb[2]})`;
        chip.title = op.name;
        chip.textContent = op.name;

        chip.addEventListener('click', () => {
          if (cwState.activePaletteIndices.has(globalIndex)) {
            cwState.activePaletteIndices.delete(globalIndex);
            chip.classList.remove('active');
          } else {
            if (cwState.activePaletteIndices.size >= 16) {
              alert('選択できるカラーは合計最大16色までです。');
              return;
            }
            cwState.activePaletteIndices.add(globalIndex);
            chip.classList.add('active');
          }
          reprocessWallReduction();
        });
        opContainer.appendChild(chip);
      }
    }

    const btnBaseAll = $('cw-btn-base-all');
    const btnBaseClear = $('cw-btn-base-clear');
    if (btnBaseAll) {
      btnBaseAll.onclick = () => {
        for (let i = 0; i < FREE_PALETTE.length; i++) {
          if (cwState.activePaletteIndices.size < 16) cwState.activePaletteIndices.add(i);
        }
        baseContainer.querySelectorAll('.palette-select-chip').forEach((el, idx) => {
          if (cwState.activePaletteIndices.has(idx)) el.classList.add('active');
        });
        reprocessWallReduction();
      };
    }
    if (btnBaseClear) {
      btnBaseClear.onclick = () => {
        for (let i = 0; i < FREE_PALETTE.length; i++) cwState.activePaletteIndices.delete(i);
        baseContainer.querySelectorAll('.palette-select-chip').forEach(el => el.classList.remove('active'));
        reprocessWallReduction();
      };
    }

    const btnOpAll = $('cw-btn-op-all');
    const btnOpClear = $('cw-btn-op-clear');
    if (btnOpAll) {
      btnOpAll.onclick = () => {
        for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
          const globalIndex = FREE_PALETTE.length + j;
          if (cwState.activePaletteIndices.size < 16) cwState.activePaletteIndices.add(globalIndex);
        }
        opContainer.querySelectorAll('.palette-select-chip').forEach((el, j) => {
          if (cwState.activePaletteIndices.has(FREE_PALETTE.length + j)) el.classList.add('active');
        });
        reprocessWallReduction();
      };
    }
    if (btnOpClear) {
      btnOpClear.onclick = () => {
        for (let j = 0; j < OP_PALETTE_RAW.length; j++) {
          cwState.activePaletteIndices.delete(FREE_PALETTE.length + j);
        }
        opContainer.querySelectorAll('.palette-select-chip').forEach(el => el.classList.remove('active'));
        reprocessWallReduction();
      };
    }
  }

  // 壁紙の減色は任意（既定はしない：CMYK印刷のため）。減色しないときは元画像の色のまま使う
  function isWallReduceOn() {
    return $('cw-reduce-on') ? $('cw-reduce-on').checked : false;
  }
  // 保存・印刷に使う壁紙の絵：減色しないときは元画像（フル解像度）、するときは減色イメージ
  function getWallSource() {
    if (isWallReduceOn()) return $('cw-reduced');
    return cwState.loadedImg || $('cw-reduced');
  }
  function syncWallReduceUi() {
    const on = isWallReduceOn();
    const boxes = [$('cw-dither'), $('cw-base-palette-selector'), $('cw-op-palette-selector')].map((el) => el ? el.closest('.dither-box, .palette-box') : null);
    boxes.forEach((b) => { if (b) b.style.display = on ? '' : 'none'; });
    // 減色しないときは「変換後イメージ」の欄を出さない（キャンバスはパース・3Dの元として裏で使う）
    const card = $('cw-reduced') ? $('cw-reduced').closest('.preview-card') : null;
    if (card) card.style.display = on ? '' : 'none';
  }

  function reprocessWallReduction() {
    try {
      const original = $('cw-original');
      const reduced = $('cw-reduced');
      if (!original || !reduced || !original.width) return;
      if (!isWallReduceOn()) {
        // 減色しない：元画像をそのまま（表示用の大きさで）変換後イメージにする
        reduced.width = original.width;
        reduced.height = original.height;
        reduced.getContext('2d').drawImage(original, 0, 0);
        cwState.lastUsedColorEntries = [];
        if ($('cw-used-colors')) $('cw-used-colors').innerHTML = '';
        if ($('cw-used-colors-text')) $('cw-used-colors-text').textContent = '減色なし（元画像の色のまま・CMYK印刷）';
        setWallStatus('✅ 壁紙用デザインを読み込みました（減色なし）。');
        if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated();
        return;
      }

      const w = original.width;
      const h = original.height;
      const active = getWallActivePaletteEntries();

      const ditherEl = $('cw-dither');
      const ditherAmount = ditherEl ? (parseFloat(ditherEl.value) || 0) : 0;
      const ditherFactor = Math.min(1, Math.max(0, ditherAmount / 100));

      const { imageData, usedEntries } = getReducedImageData(original, w, h, ditherFactor, active);

      reduced.width = w;
      reduced.height = h;
      reduced.getContext('2d').putImageData(imageData, 0, 0);

      cwState.lastUsedColorEntries = usedEntries;

      const usedColors = $('cw-used-colors');
      if (usedColors) {
        usedColors.innerHTML = '';
        usedEntries.forEach(col => {
          const chip = document.createElement('div');
          chip.className = 'psd-color-chip';
          chip.style.backgroundColor = `rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
          chip.title = `${col.name} rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
          usedColors.appendChild(chip);
        });
      }
      const usedColorsText = $('cw-used-colors-text');
      if (usedColorsText) {
        usedColorsText.textContent = usedEntries.length
          ? usedEntries.map(c => c.name).join('、') + `（計${usedEntries.length}色）`
          : '';
      }
      setWallStatus('✅ 壁紙用デザインの減色プレビューを更新しました。');
      if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated();
    } catch (err) {
      setWallStatus('❌ 壁紙用デザインの処理中にエラーが発生しました：' + err.message);
      console.error('[Wall Design Error]', err);
    }
  }

  function updateWallCanvas() {
    const img = cwState.loadedImg;
    const canvas = $('cw-original');
    if (!img || !canvas) return;

    const maxLimit = 700;
    let displayW = img.naturalWidth || img.width;
    let displayH = img.naturalHeight || img.height;
    if (displayW > maxLimit || displayH > maxLimit) {
      const aspect = displayW / displayH;
      if (displayW >= displayH) {
        displayW = maxLimit;
        displayH = Math.max(1, Math.round(maxLimit / aspect));
      } else {
        displayH = maxLimit;
        displayW = Math.max(1, Math.round(maxLimit * aspect));
      }
    }

    canvas.width = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(img, 0, 0, displayW, displayH);

    reprocessWallReduction();
  }

  function handleWallFile(file, done) {
    if (!file) return;
    setWallStatus('画像を読み込んでいます... ' + file.name);

    const objectUrl = URL.createObjectURL(file);
    const img = new Image();

    img.onload = function () {
      cwState.loadedImg = img;
      cwState.file = file; // 印刷用ZIPに「元データ」として入れる
      updateWallCanvas();
      if (typeof done === 'function') done();
      URL.revokeObjectURL(objectUrl);
    };
    img.onerror = function () {
      setWallStatus('❌ 画像ファイルとして読み込めませんでした。');
      URL.revokeObjectURL(objectUrl);
    };
    img.src = objectUrl;
  }
  // =====================================================================
  // ② 壁紙用デザイン ここまで
  // =====================================================================


  // カーペットの画像は、指定サイズ（横幅 × 縦幅。CADの部屋から算出したサイズも同じ）の上下左右に 5mm ずつ足した大きさで作る
  const CARPET_BLEED = 5;
  window.cfpCarpetBleed = CARPET_BLEED;
  // 元画像を、縦横比を変えずに指定サイズ（W × H から上下左右の余白 5mm を除いた範囲）いっぱいまで引き伸ばし（はみ出したところは切る）、
  // 外側の余白 5mm は、端の色をそのまま外へのばして埋める（近似色）。W × H は「指定サイズ＋上下左右5mm」を表す（画面は縮小表示）。
  // 「画像の大きさ」（100% = いっぱい）で拡大・縮小する。縮小して余白が出るところは色を付けない（透明。画面では白に見える）
  function carpetImageScale() {
    const v = parseFloat(($('cc-img-scale') || {}).value);
    return Math.min(3, Math.max(0.3, (isNaN(v) ? 100 : v) / 100));
  }
  function drawImageCover(ctx, img, W, H) {
    const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
    ctx.clearRect(0, 0, W, H);
    if (!iw || !ih) return;
    // 余白（5mm）の大きさ（この絵の px）：指定サイズに対する割合から
    const sw = parseFloat(($('cc-width') || {}).value) || 1000, sh = parseFloat(($('cc-height') || {}).value) || 1000;
    const bx = Math.round(W * CARPET_BLEED / (sw + CARPET_BLEED * 2)), by = Math.round(H * CARPET_BLEED / (sh + CARPET_BLEED * 2));
    const IW = W - bx * 2, IH = H - by * 2;
    if (IW < 1 ? true : IH < 1) return;
    const sc = Math.max(IW / iw, IH / ih) * carpetImageScale();
    const w = iw * sc, h = ih * sc;
    ctx.save();
    ctx.beginPath();
    ctx.rect(bx, by, IW, IH);
    ctx.clip();
    ctx.drawImage(img, bx + (IW - w) / 2, by + (IH - h) / 2, w, h);
    ctx.restore();
    if (bx < 1 ? by < 1 : false) return;
    // 端の1列・1行を、余白の幅だけ外へのばす（上下 → 左右の順で、角も埋まる）
    const smooth = ctx.imageSmoothingEnabled;
    ctx.imageSmoothingEnabled = false;
    const cv = ctx.canvas;
    if (by >= 1) {
      ctx.drawImage(cv, bx, by, IW, 1, bx, 0, IW, by);
      ctx.drawImage(cv, bx, by + IH - 1, IW, 1, bx, by + IH, IW, H - by - IH);
    }
    if (bx >= 1) {
      ctx.drawImage(cv, bx, 0, 1, H, 0, 0, bx, H);
      ctx.drawImage(cv, bx + IW - 1, 0, 1, H, bx + IW, 0, W - bx - IW, H);
    }
    ctx.imageSmoothingEnabled = smooth;
  }

  function updateCarpetCanvas() {
    const img = state.loadedImg;
    const canvas = $('cc-original');
    const widthMm = parseFloat($('cc-width')?.value) || 1000;
    const heightMm = parseFloat($('cc-height')?.value) || 1000;
    if (!img || !canvas) return;

    let displayW = Math.max(100, Math.round(widthMm + CARPET_BLEED * 2));
    let displayH = Math.max(100, Math.round(heightMm + CARPET_BLEED * 2));
    const maxLimit = 1000;
    if (displayW > maxLimit || displayH > maxLimit) {
      const aspect = displayW / displayH;
      if (displayW >= displayH) {
        displayW = maxLimit;
        displayH = Math.max(1, Math.round(maxLimit / aspect));
      } else {
        displayH = maxLimit;
        displayW = Math.max(1, Math.round(maxLimit * aspect));
      }
    }

    canvas.width = displayW;
    canvas.height = displayH;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.imageSmoothingQuality = 'high';
    drawImageCover(ctx, img, displayW, displayH);
    if ($('cc-download-psd')) $('cc-download-psd').disabled = false;
    if ($('cc-download-svg')) $('cc-download-svg').disabled = false;
    
    reprocessReduction();
  }

  function handleFile(file, done) {
    if (!file) return;
    debug('【ファイル読込中】 ' + file.name);
    setStatus('', '');

    const objectUrl = URL.createObjectURL(file);
    const img = new Image();
    
    img.onload = function() {
      debug('【画像デコード成功】 ' + img.width + 'x' + img.height + 'px');
      setStatus('ok', '✅ 画像の読み込み・プレビュー描画が完了しました');
      state.loadedImg = img;
      state.file = file; // 途中保存で保存する元画像
      state.protect = []; // 守る色は画像ごと
      if (state.resetOrigZoom) state.resetOrigZoom();
      if ($('cc-protect-list')) $('cc-protect-list').innerHTML = '';
      updateCarpetCanvas();
      if (typeof done === 'function') done();
      URL.revokeObjectURL(objectUrl);
    };
    
    img.onerror = function() {
      debug('【エラー】画像として読み込めませんでした', true);
      setStatus('err', '❌ 画像ファイルとして読み込めませんでした。');
      URL.revokeObjectURL(objectUrl);
    };
    
    img.src = objectUrl;
  }

  function findClosestPaletteIndex(r, g, b, active) {
    let minDist = Infinity;
    let closest = 0;
    for (let p = 0; p < active.length; p++) {
      const pal = active[p];
      const dist = (r - pal[0]) ** 2 + (g - pal[1]) ** 2 + (b - pal[2]) ** 2;
      if (dist < minDist) {
        minDist = dist;
        closest = p;
      }
    }
    return closest;
  }

  // 減色＋誤差拡散のコアロジック（1ピクセル単位で処理）。
  // data: Uint8ClampedArray（RGBA）, w/h: 対象の幅・高さ, activeRgb: 使用中パレットのRGB配列
  // lut: 色の対応表（buildLookLut。印象・色の見え方を考えた割り当て）。無いときは RGB の近さ
  function quantizeImageDataToPalette(data, w, h, activeRgb, ditherFactor, lut) {
    const outData = new Uint8ClampedArray(data.length);
    const usedIndices = new Set();
    const pick = lut ? (r, g, b) => lut[((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3)] : (r, g, b) => findClosestPaletteIndex(r, g, b, activeRgb);

    if (ditherFactor <= 0) {
      for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] < 128) continue; // 余白（透明）：色を付けない（パレットの色を使わない）
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        const closest = pick(r, g, b);
        const color = activeRgb[closest];
        usedIndices.add(closest);
        outData[i] = color[0];
        outData[i + 1] = color[1];
        outData[i + 2] = color[2];
        outData[i + 3] = 255;
      }
    } else {
      // Floyd–Steinberg 誤差拡散（ditherFactor で強度を可変）
      const buf = new Float32Array(w * h * 3);
      for (let i = 0, j = 0; i < data.length; i += 4, j += 3) {
        buf[j] = data[i];
        buf[j + 1] = data[i + 1];
        buf[j + 2] = data[i + 2];
      }

      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const j = (y * w + x) * 3;
          if (data[(y * w + x) * 4 + 3] < 128) continue; // 余白（透明）：色を付けず、誤差も広げない
          const r = Math.min(255, Math.max(0, buf[j]));
          const g = Math.min(255, Math.max(0, buf[j + 1]));
          const b = Math.min(255, Math.max(0, buf[j + 2]));

          const closest = pick(r | 0, g | 0, b | 0);
          const color = activeRgb[closest];
          usedIndices.add(closest);

          const i = (y * w + x) * 4;
          outData[i] = color[0];
          outData[i + 1] = color[1];
          outData[i + 2] = color[2];
          outData[i + 3] = 255;

          const errR = (r - color[0]) * ditherFactor;
          const errG = (g - color[1]) * ditherFactor;
          const errB = (b - color[2]) * ditherFactor;

          const distribute = (dx, dy, factor) => {
            const nx = x + dx;
            const ny = y + dy;
            if (nx < 0 || nx >= w || ny < 0 || ny >= h) return;
            const nj = (ny * w + nx) * 3;
            buf[nj] += errR * factor;
            buf[nj + 1] += errG * factor;
            buf[nj + 2] += errB * factor;
          };

          distribute(1, 0, 7 / 16);
          distribute(-1, 1, 3 / 16);
          distribute(0, 1, 5 / 16);
          distribute(1, 1, 1 / 16);
        }
      }
    }

    return { outData, usedIndices };
  }

  // sourceCanvasLike（Image / Canvas）を targetW×targetH に描画してから減色。
  // 1色1ピクセル単位の結果が欲しい場合は targetW/targetH に実寸ピクセル数（1px=1mm）を渡す。
  // ---- 壁紙の柄の繰り返し（縦横比を保ったまま、1リピートの横幅[mm]で敷き詰める） ----
  function getWallRepeat() {
    const mode = $('cw-wall-mode') ? $('cw-wall-mode').value : 'repeat';
    const on = mode === 'repeat';
    const mm = Math.max(50, parseFloat($('cw-repeat-mm')?.value) || 910);
    // 画像の大きさは、CAD表示の「壁紙の巾の枠」の「画像の大きさ」スライダーで決める（1 = 100%）
    const sh = window.cfpWallShift;
    const sc = sh ? (sh.s || 1) : 1;
    return { on: on, mode: mode, mm: mm, scale: sc };
  }
  window.cfpGetWallRepeat = getWallRepeat;

  // source を、幅 w × 高さ h（1px=1mm）の壁に、横 repeatMm・縦は縦横比なりの大きさで敷き詰めたキャンバス
  function tileWallCanvas(source, w, h, repeatMm) {
    const sw = source.naturalWidth || source.width, sh = source.naturalHeight || source.height;
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const ctx = out.getContext('2d');
    const tw = Math.max(1, Math.round(repeatMm));
    const th = Math.max(1, Math.round(repeatMm * sh / sw));
    const tile = document.createElement('canvas');
    tile.width = tw;
    tile.height = th;
    const tctx = tile.getContext('2d');
    tctx.imageSmoothingQuality = 'high';
    tctx.drawImage(source, 0, 0, tw, th);
    // 天井（上端）・左端から貼り始める
    for (let y = 0; y < h; y += th) {
      for (let x = 0; x < w; x += tw) ctx.drawImage(tile, x, y);
    }
    return out;
  }

  // 壁いっぱいに1枚のときの画像の横幅[mm]：どの壁でも同じ大きさにするため、部屋の壁（幅・奥行）の
  // 長い方と壁の高さの両方を覆える大きさにする（縦横比は変えない）
  function singleImageWidthMm(aspect) {
    const W = parseFloat($('persp-width')?.value) || 3000;
    const D = parseFloat($('persp-floor-depth')?.value) || 2500;
    const H = parseFloat($('persp-wall-height')?.value) || 2400;
    // 100% のとき、印刷の裁断代（上下100mm）と巾の重なり（左右に合わせ代と同じ幅ずつ）まで画像が入る大きさにする
    const WP = window.cfpWallPrint || { OVERLAP: 10, TRIM_TOP: 100, TRIM_BOTTOM: 100 };
    return Math.max(W + (WP.SIDE || WP.OVERLAP) * 2, D + (WP.SIDE || WP.OVERLAP) * 2, (H + WP.TRIM_TOP + WP.TRIM_BOTTOM) * aspect) * getWallRepeat().scale;
  }
  window.cfpSingleImageWidthMm = singleImageWidthMm;

  // 壁いっぱいに1枚：縦横比を保ったまま、どの壁でも同じ大きさ（singleImageWidthMm）で中央に配置し、はみ出した分は切り取る
  // wallH: 壁の高さ（px）。h がそれより大きい（下に裁断代がある）ときも、壁の部分の中央に合わせる
  function coverWallCanvas(source, w, h, wallH) {
    wallH = wallH || h;
    const sw = source.naturalWidth || source.width, sh = source.naturalHeight || source.height;
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const ctx = out.getContext('2d');
    ctx.imageSmoothingQuality = 'high';
    // 余白（画像を小さくしたとき）は白
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    const k = singleImageWidthMm(sw / sh) / sw;
    const dw = sw * k, dh = sh * k;
    ctx.drawImage(source, (w - dw) / 2, (wallH - dh) / 2, dw, dh);
    return out;
  }

  // 部屋を一周して続ける：お部屋パースの「横の壁（奥行）→ 奥の壁（幅）」を1本の帯として画像を貼り、
  // そのうち奥の壁（幅 w）にあたる部分を返す（縦横比は変えない・中央合わせ・余白は白）
  function wrapBand(aspect) {
    const W = parseFloat($('persp-width')?.value) || 3000;
    const D = parseFloat($('persp-floor-depth')?.value) || 2500;
    const H = parseFloat($('persp-wall-height')?.value) || 2400;
    const P = W + D;
    const WP = window.cfpWallPrint || { OVERLAP: 10, TRIM_TOP: 100, TRIM_BOTTOM: 100 };
    // 100% のとき、裁断代（上下100mm）と両端の重なり（10mm）まで画像が入る大きさ
    const iw = Math.max(P + (WP.SIDE || WP.OVERLAP) * 2, (H + WP.TRIM_TOP + WP.TRIM_BOTTOM) * aspect) * getWallRepeat().scale;
    return { W: W, D: D, H: H, P: P, iw: iw, ih: iw / aspect, s0: (P - iw) / 2 };
  }
  window.cfpWrapBand = wrapBand;

  function wrapWallCanvas(source, w, h, wallH) {
    wallH = wallH || h;
    const sw = source.naturalWidth || source.width, sh = source.naturalHeight || source.height;
    const b = wrapBand(sw / sh);
    const out = document.createElement('canvas');
    out.width = w;
    out.height = h;
    const ctx = out.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, w, h);
    ctx.imageSmoothingQuality = 'high';
    const k = w / b.W; // 帯[mm] → この壁のピクセル
    ctx.drawImage(source, (b.s0 - b.D) * k, (wallH - b.ih * k) / 2, b.iw * k, b.ih * k);
    return out;
  }

  function updateWallRepeatNote() {
    const note = $('cw-repeat-note');
    const src = $('cw-reduced');
    if (!note) return;
    const r = getWallRepeat();
    if (r.mode === 'wrap') {
      if (!src || !src.width) { note.textContent = '1枚を部屋を一周して続けて貼ります。'; return; }
      const b = wrapBand(src.width / src.height);
      note.textContent = '1枚を部屋を一周して続けて貼ります（' + Math.round(r.scale * 100) + '%）。画像の大きさ 横 ' + Math.round(b.iw).toLocaleString() + ' × 縦 ' + Math.round(b.ih).toLocaleString() + ' mm。壁の角で途切れず隣の壁へ続きます（縦横比は変えず、余白は白）。壁紙PSD・注文の画像は、奥の壁（幅）の部分です。';
      return;
    }
    if (!r.on) {
      if (!src || !src.width) { note.textContent = '壁いっぱいに1枚で表示します。'; return; }
      const iw = singleImageWidthMm(src.width / src.height);
      note.textContent = '1枚で表示します（' + Math.round(getWallRepeat().scale * 100) + '%）。縦横比は変えず、どの壁でも同じ大きさ（横 ' + Math.round(iw).toLocaleString() + ' × 縦 ' + Math.round(iw * src.height / src.width).toLocaleString() + ' mm）で、壁ごとに中央に合わせます（はみ出した部分は切り取り、足りない部分は白）。';
      return;
    }
    if (!src || !src.width) { note.textContent = ''; return; }
    const th = Math.round(r.mm * src.height / src.width);
    const wallW = parseFloat($('persp-width')?.value) || 3000;
    const wallH = parseFloat($('persp-wall-height')?.value) || 2400;
    note.textContent = '1リピート：横 ' + Math.round(r.mm).toLocaleString() + ' × 縦 ' + th.toLocaleString() + ' mm。壁（' + wallW.toLocaleString() + ' × ' + wallH.toLocaleString() + ' mm）に、横 約' + (wallW / r.mm).toFixed(1) + '回・縦 約' + (wallH / th).toFixed(1) + '回 繰り返します。';
  }

  window.cfpUpdateWallRepeatNote = updateWallRepeatNote;

  // opts.lut: 色の対応表（カーペット：印象・色の見え方を考えた割り当て）
  function getReducedImageData(sourceCanvasLike, targetW, targetH, ditherFactor, activeEntries, opts) {
    const off = document.createElement('canvas');
    off.width = targetW;
    off.height = targetH;
    const octx = off.getContext('2d', { willReadFrequently: true });
    octx.imageSmoothingEnabled = true;
    octx.imageSmoothingQuality = 'high';
    octx.drawImage(sourceCanvasLike, 0, 0, targetW, targetH);
    const imgData = octx.getImageData(0, 0, targetW, targetH);

    const activeRgb = activeEntries.map(e => e.rgb);
    const { outData, usedIndices } = quantizeImageDataToPalette(imgData.data, targetW, targetH, activeRgb, ditherFactor, opts ? opts.lut : null);
    const usedEntries = Array.from(usedIndices).sort((a, b) => a - b).map(i => activeEntries[i]);

    return { imageData: new ImageData(outData, targetW, targetH), usedEntries };
  }

  function getUsedColorsSummaryText(entries) {
    if (!entries || entries.length === 0) return '未検出（画像未選択、または未処理）';
    return entries.map(c => c.name).join('、') + ` ／ 計${entries.length}色`;
  }

  function renderUsedColorsUI(entries) {
    const usedColors = $('cc-used-colors');
    if (usedColors) {
      usedColors.innerHTML = '';
      entries.forEach(col => {
        const chip = document.createElement('div');
        chip.className = 'psd-color-chip';
        chip.style.backgroundColor = `rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
        chip.title = `${col.name} rgb(${col.rgb[0]},${col.rgb[1]},${col.rgb[2]})`;
        usedColors.appendChild(chip);
      });
    }
    const usedColorsText = $('cc-used-colors-text');
    if (usedColorsText) {
      usedColorsText.textContent = entries && entries.length
        ? entries.map(c => c.name).join('、') + `（計${entries.length}色）`
        : '';
    }
  }

  // ---------------------------------------------------------------------------
  // ① カーペット用：3通りの自動変換（① 標準色のみ／② 標準色＋オプション3色／③ 最大表現）
  // 元画像の色の分布から、色の近さ（Lab）の合計が最も小さくなる16色を、貪欲法＋入れ替えで選ぶ。
  // ---------------------------------------------------------------------------
  const FREE_COUNT = FREE_PALETTE.length; // 無償色（基本16色＋OP-03・05）
  const VARIANTS = {
    std: { label: '標準色のみ' },
    op3: { label: '標準色＋オプション3色' },
    max: { label: '最大表現' }
  };

  function rgbToLab(r, g, b) {
    const f = (c) => { c /= 255; return c > 0.04045 ? Math.pow((c + 0.055) / 1.055, 2.4) : c / 12.92; };
    const R = f(r), G = f(g), B = f(b);
    const X = (R * 0.4124 + G * 0.3576 + B * 0.1805) / 0.95047;
    const Y = (R * 0.2126 + G * 0.7152 + B * 0.0722);
    const Z = (R * 0.0193 + G * 0.1192 + B * 0.9505) / 1.08883;
    const g3 = (v) => (v > 0.008856 ? Math.cbrt(v) : 7.787 * v + 16 / 116);
    const fx = g3(X), fy = g3(Y), fz = g3(Z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
  }

  // ---- 仕上がりの印象（配色の評価のしかた）----
  // 元の色との数値的な近さだけでなく、明るさ・あざやかさ・色合いの見え方の違い、色同士の関係（違う色が同じ色に
  // つぶれない・明るさの順番が入れ替わらない）、柄・文字の輪郭（境目の色を重く見る）、全体の調和（ほとんど使わない
  // 色を増やさない）、求める印象（くっきり・鮮やか・落ち着き）をまとめて評価して、16色を選び、色を割り当てる。
  const LOOKS = {
    natural: { label: '自然（元の印象に近く）', wL: 1.0, wC: 1.0, wH: 1.2, chroma: 1.0, light: 0, edge: 1.5, sep: 1.0, order: 1.0 },
    crisp: { label: 'くっきり（柄・文字を見やすく）', wL: 1.7, wC: 0.8, wH: 1.0, chroma: 1.0, light: 0, edge: 3.0, sep: 2.5, order: 2.5 },
    vivid: { label: '鮮やか（華やかに）', wL: 0.8, wC: 1.5, wH: 1.4, chroma: 1.25, light: 0, edge: 1.5, sep: 1.2, order: 1.0 },
    calm: { label: '落ち着き（やわらかく）', wL: 1.0, wC: 1.3, wH: 1.0, chroma: 0.8, light: 3, edge: 1.0, sep: 0.8, order: 1.0 }
  };
  function carpetLook() {
    const v = ($('cc-look') || {}).value;
    return LOOKS[v] ? v : 'natural';
  }
  // 見え方の違い：明るさ・あざやかさ・色合いを分けて重みを付ける（元の色は印象に合わせて少し動かしてから比べる）
  function lookTarget(lab, L) { return [Math.min(100, lab[0] + L.light), lab[1] * L.chroma, lab[2] * L.chroma]; }
  // 色みのはっきりした色（標識の赤など）は、明るさより「色の種類（色合い）と鮮やかさ」で見分けられるので、
  // 鮮やかさが落ちる・色合いがずれるのを重く、明るさの差を軽く見る（暗めの赤が茶色に寄らないように）
  function lookDist(t, p, L) {
    const dL = t[0] - p[0];
    const c1 = Math.hypot(t[1], t[2]), c2 = Math.hypot(p[1], p[2]);
    const dC = c1 - c2;
    const da = t[1] - p[1], db = t[2] - p[2];
    const dH2 = Math.max(0, da * da + db * db - dC * dC);
    const k = Math.min(1, Math.max(0, (c1 - 20) / 40));
    return L.wL * (1 - 0.5 * k) * dL * dL + L.wC * (dC > 0 ? 1 + 2 * k : 1) * dC * dC + L.wH * (1 + 2 * k) * dH2;
  }
  // 守る色に合わせるパレットの色：色の種類（色合い）と鮮やかさをいちばん大事にし、明るさは軽く見る
  //（暗めの赤を守るなら、明るさが近い茶色ではなく赤にする）
  function protectDist(t, p) {
    const dL = t[0] - p[0];
    const c1 = Math.hypot(t[1], t[2]), c2 = Math.hypot(p[1], p[2]);
    const dC = c1 - c2;
    const da = t[1] - p[1], db = t[2] - p[2];
    const dH2 = Math.max(0, da * da + db * db - dC * dC);
    return 0.3 * dL * dL + (dC > 0 ? 3 : 0.5) * dC * dC + 4 * dH2;
  }
  // 色の対応表（5bit/チャンネル＝32768色ぶん）。画面・PSD（Worker）で同じ表を使うので、仕上がりがそろう
  const lutCache = new Map();
  // 守る色（元画像でクリックした色）：その色に近い色（見え方の差 15 以内）は、守る色にいちばん合うパレットの色にする
  function buildLookLut(activeRgb, look) {
    const prot = (state.protect || []);
    const key = look + '|' + activeRgb.map((c) => c.join(',')).join(';') + '|' + prot.map((c) => c.join(',')).join(';');
    if (lutCache.has(key)) return lutCache.get(key);
    const L = LOOKS[look] || LOOKS.natural;
    const pl = activeRgb.map((c) => rgbToLab(c[0], c[1], c[2]));
    const lut = new Uint8Array(32768);
    for (let i = 0; i !== 32768; i++) {
      const t = lookTarget(rgbToLab((i >> 10) * 8 + 4, ((i >> 5) % 32) * 8 + 4, (i % 32) * 8 + 4), L);
      let best = 0, bd = Infinity;
      for (let p = 0; p !== pl.length; p++) { const d = lookDist(t, pl[p], L); if (d < bd) { bd = d; best = p; } }
      lut[i] = best;
    }
    if (prot.length) {
      const P = prot.map((c) => {
        const lab = rgbToLab(c[0], c[1], c[2]), t = lookTarget(lab, L);
        let best = 0, bd = Infinity;
        for (let p = 0; p !== pl.length; p++) { const d = protectDist(t, pl[p]); if (d < bd) { bd = d; best = p; } }
        return { lab, best };
      });
      for (let i = 0; i !== 32768; i++) {
        const lab = rgbToLab((i >> 10) * 8 + 4, ((i >> 5) % 32) * 8 + 4, (i % 32) * 8 + 4);
        let near = -1, nd = 15 * 15;
        P.forEach((q, k) => { const d = (lab[0] - q.lab[0]) ** 2 + (lab[1] - q.lab[1]) ** 2 + (lab[2] - q.lab[2]) ** 2; if (d < nd) { nd = d; near = k; } });
        if (near >= 0) lut[i] = P[near].best;
      }
    }
    if (lutCache.size > 12) lutCache.clear();
    lutCache.set(key, lut);
    return lut;
  }
  function carpetLut(entries) { return buildLookLut(entries.map((e) => e.rgb), carpetLook()); }

  // 元画像の色の分布（5bit/チャンネルの箱ごとの平均色と重み。多い順に最大2500）。
  // 重み：画素数＋柄・文字の輪郭（明るさが急に変わるところ）の画素を重く数える（edge）
  function colorHistogram(canvas, edge) {
    const cw = canvas.width, ch = canvas.height;
    const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, cw, ch).data;
    const bins = new Map();
    const lum = (i) => d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114;
    for (let y = 0; y < ch; y++) {
      for (let x = 0; x < cw; x++) {
        const i = (y * cw + x) * 4;
        if (d[i + 3] < 128) continue;
        let g = 0;
        if (x + 1 < cw) g = Math.max(g, Math.abs(lum(i) - lum(i + 4)));
        if (y + 1 < ch) g = Math.max(g, Math.abs(lum(i) - lum(i + cw * 4)));
        const wt = 1 + (edge || 0) * Math.min(1, g / 48);
        const key = ((d[i] >> 3) << 10) | ((d[i + 1] >> 3) << 5) | (d[i + 2] >> 3);
        let b = bins.get(key);
        if (!b) { b = [0, 0, 0, 0, 0]; bins.set(key, b); }
        b[0] += d[i]; b[1] += d[i + 1]; b[2] += d[i + 2]; b[3]++; b[4] += wt;
      }
    }
    // 目立つ色（鮮やかな色：標識の赤など）は面積が小さくても重く数える（全体の印象を決めるため）
    const arr = Array.from(bins.values()).map((b) => {
      const lab = rgbToLab(b[0] / b[3], b[1] / b[3], b[2] / b[3]);
      const c = Math.hypot(lab[1], lab[2]);
      return { lab, w: b[4] * (1 + 1.5 * Math.min(1, Math.max(0, (c - 25) / 45))) };
    }).sort((a, b) => b.w - a.w).slice(0, 2500);
    return arr;
  }

  // 色同士の関係：はっきり違う代表の色（最大24色）と、画像の中で隣り合っている長さ（柄・文字の境目）を数える。
  // 隣り合う2色が同じ色につぶれると柄が見えなくなるので、境目が長い組ほど重く見る
  function colorRelations(hist, canvas) {
    const reps = [];
    for (let b = 0; b < hist.length; b++) {
      if (reps.length >= 24) break;
      const h = hist[b].lab;
      if (reps.every((r) => { const q = hist[r].lab; return Math.hypot(h[0] - q[0], h[1] - q[1], h[2] - q[2]) > 7; })) reps.push(b);
    }
    const n = reps.length;
    const adj = new Float64Array(n * n);
    const cw = canvas.width, ch = canvas.height;
    const d = canvas.getContext('2d', { willReadFrequently: true }).getImageData(0, 0, cw, ch).data;
    const cache = new Map();
    const near = (i) => {
      const key = ((d[i] >> 3) << 10) | ((d[i + 1] >> 3) << 5) | (d[i + 2] >> 3);
      let r = cache.get(key);
      if (r === undefined) {
        const lab = rgbToLab(d[i], d[i + 1], d[i + 2]);
        let bd = Infinity; r = 0;
        reps.forEach((b, k) => { const q = hist[b].lab; const dd = (lab[0] - q[0]) ** 2 + (lab[1] - q[1]) ** 2 + (lab[2] - q[2]) ** 2; if (dd < bd) { bd = dd; r = k; } });
        cache.set(key, r);
      }
      return r;
    };
    const step = Math.max(1, Math.round(Math.max(cw, ch) / 500));
    for (let y = 0; y + step < ch; y += step) {
      for (let x = 0; x + step < cw; x += step) {
        const i = (y * cw + x) * 4;
        if (d[i + 3] < 128) continue;
        const a = near(i);
        const j1 = i + step * 4, j2 = i + step * cw * 4;
        if (d[j1 + 3] >= 128) { const c = near(j1); if (c !== a) { adj[a * n + c]++; adj[c * n + a]++; } }
        if (d[j2 + 3] >= 128) { const c = near(j2); if (c !== a) { adj[a * n + c]++; adj[c * n + a]++; } }
      }
    }
    const scale = step * step; // the boundary counted on a coarser grid: back to pixels
    const pairs = [];
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
      const a = hist[reps[i]], c = hist[reps[j]];
      const de = Math.hypot(a.lab[0] - c.lab[0], a.lab[1] - c.lab[1], a.lab[2] - c.lab[2]);
      pairs.push({ i: reps[i], j: reps[j], de, dl: a.lab[0] - c.lab[0], w: Math.min(a.w, c.w), edge: adj[i * n + j] * scale });
    }
    return { reps, pairs };
  }

  // pool: パレット番号（ALL_COLORS）の配列。quota: { free: n, opt: m }（省略可）。最大 k 色を選ぶ。
  // 評価 = Σ 重み × 見え方の違い ＋ 色同士の関係の崩れ（違う色がつぶれる・明るさの順番が逆になる）の罰点。
  // 調和：色を1つ増やしても良くなる量がごくわずかなら、それ以上増やさない（ほとんど使わない色を入れない）
  function selectPalette(hist, pool, k, quota, look, rel) {
    const L = LOOKS[look] || LOOKS.natural;
    const nb = hist.length;
    if (!nb) return pool.slice(0, k);
    const labs = {};
    pool.forEach((idx) => { labs[idx] = rgbToLab.apply(null, ALL_COLORS[idx].rgb); });
    const tg = hist.map((h) => lookTarget(h.lab, L));
    const dist = {};
    pool.forEach((idx) => {
      const row = new Float64Array(nb);
      for (let b = 0; b < nb; b++) row[b] = lookDist(tg[b], labs[idx], L);
      dist[idx] = row;
    });
    const totalW = hist.reduce((t, h) => t + h.w, 0);
    const reps = rel ? rel.reps : [], pairs = rel ? rel.pairs : [];
    const penalty = (sel) => {
      if (!pairs.length || !sel.length) return 0;
      const asg = {};
      reps.forEach((b) => { let best = sel[0], bd = Infinity; sel.forEach((idx) => { if (dist[idx][b] < bd) { bd = dist[idx][b]; best = idx; } }); asg[b] = best; });
      let pen = 0;
      pairs.forEach((p) => {
        const pi = asg[p.i], pj = asg[p.j];
        // 隣り合う違う色が同じ色につぶれる：柄・文字の境目が消える（境目の長さで重み付け）。離れた色どうしは面積で
        if (pi === pj) { if (p.de > 8) pen += L.sep * (p.edge * 2 + (p.de > 20 ? p.w * 0.5 : 0)) * p.de * p.de; return; }
        if (Math.abs(p.dl) > 10) {
          const ld = labs[pi][0] - labs[pj][0];
          if (ld * p.dl < 0) pen += L.order * p.w * p.dl * p.dl; // 明るさの順番が逆
        }
      });
      return pen;
    };
    const grp = (idx) => (idx < FREE_COUNT ? 'free' : 'opt');
    const left = quota ? { free: quota.free, opt: quota.opt } : null;
    const sel = [];
    let minD = new Float64Array(nb).fill(Infinity);
    const dataCost = (md, row) => { let s = 0; for (let b = 0; b < nb; b++) s += hist[b].w * Math.min(md[b], row[b]); return s; };
    let cur = Infinity;
    // 守る色：いちばん合うパレットの色を、最初に必ず入れる
    (state.protect || []).forEach((c) => {
      const t = lookTarget(rgbToLab(c[0], c[1], c[2]), L);
      let best = -1, bd = Infinity;
      pool.forEach((idx) => { if (left ? left[grp(idx)] <= 0 : false) return; const d = protectDist(t, labs[idx]); if (d < bd) { bd = d; best = idx; } });
      if (best < 0 || sel.indexOf(best) >= 0 || sel.length >= k) return;
      sel.push(best);
      if (left) left[grp(best)]--;
      for (let b = 0; b < nb; b++) minD[b] = Math.min(minD[b], dist[best][b]);
    });
    while (sel.length < k) {
      let best = -1, bestCost = Infinity;
      pool.forEach((idx) => {
        if (sel.indexOf(idx) >= 0) return;
        if (left ? left[grp(idx)] <= 0 : false) return;
        const c = dataCost(minD, dist[idx]) + penalty(sel.concat([idx]));
        if (c < bestCost) { bestCost = c; best = idx; }
      });
      if (best < 0) break;
      // 調和：8色をこえてからは、良くなる量が全体のごくわずか（平均で見え方の差 0.5 ほど）なら増やさない
      if ((quota ? false : sel.length >= 8) ? cur - bestCost < totalW * 0.1 : false) break;
      sel.push(best);
      cur = bestCost;
      if (left) left[grp(best)]--;
      for (let b = 0; b < nb; b++) minD[b] = Math.min(minD[b], dist[best][b]);
    }
    // 入れ替えで改善（同じ種類の中で）。守る色で入れた色は入れ替えない
    const fixed = sel.slice(0, Math.min(sel.length, (state.protect || []).length));
    for (let pass = 0; pass < 3; pass++) {
      let changed = false;
      for (let p = 0; p < sel.length; p++) {
        if (fixed.indexOf(sel[p]) >= 0) continue;
        const md = new Float64Array(nb).fill(Infinity);
        sel.forEach((idx, q) => { if (q !== p) for (let b = 0; b < nb; b++) md[b] = Math.min(md[b], dist[idx][b]); });
        const others = sel.filter((x, q) => q !== p);
        let c0 = dataCost(md, dist[sel[p]]) + penalty(sel), bestIdx = sel[p];
        pool.forEach((idx) => {
          if (sel.indexOf(idx) >= 0) return;
          if (quota ? grp(idx) !== grp(sel[p]) : false) return;
          const c = dataCost(md, dist[idx]) + penalty(others.concat([idx]));
          if (c < c0 - 1e-6) { c0 = c; bestIdx = idx; }
        });
        if (bestIdx !== sel[p]) { sel[p] = bestIdx; changed = true; }
      }
      if (!changed) break;
    }
    return sel.sort((a, b) => a - b);
  }

  function computeVariantSets(original) {
    const look = carpetLook();
    const hist = colorHistogram(original, LOOKS[look].edge);
    const rel = colorRelations(hist, original);
    const free = [], opt = [];
    for (let i = 0; i < ALL_COLORS.length; i++) (i < FREE_COUNT ? free : opt).push(i);
    return {
      std: selectPalette(hist, free, 16, null, look, rel),
      op3: selectPalette(hist, free.concat(opt), 16, { free: 13, opt: 3 }, look, rel),
      max: selectPalette(hist, free.concat(opt), 16, null, look, rel)
    };
  }

  const sameSet = (a, b) => a.length === b.size && a.every((i) => b.has(i));

  // 3通りの変換を描き、選ばれているものを強調する（色の選択はキャッシュ、誤差拡散は現在の設定）
  function renderVariants() {
    const original = $('cc-original');
    if (!original || !original.width || !$('cc-var-std')) return;
    try {
      // 画像・印象・守る色・パレットの版・プレビューのサイズが変わったら選び直す（選んでいた変換①②③は保つ）
      // 元画像のプレビュー（サイズ・画像の大きさ）が変わったときも選び直す（選んでいた変換①②③はそのまま）。
      // こうしないと、サイズを変えたあとにパレットを切り替えたときだけ選び直され、同じパレットでも色が変わって見える
      const key = (state.loadedImg ? state.loadedImg.src : '') + '|' + carpetLook() + '|' + (state.protect || []).map((c) => c.join(',')).join(';') + '|' + paletteVersion + '|' + original.width + 'x' + original.height + '|' + carpetImageScale();
      if (state.variantKey !== key) {
        // 同じ画像で「仕上がりの印象」だけ変えたときは、選んでいた変換（①②③）のまま選び直す
        const sameImg = state.variantKey ? state.variantKey.split('|')[0] === key.split('|')[0] : false;
        let keep = null;
        if (sameImg ? state.variantSets : false) Object.keys(VARIANTS).forEach((v) => { if (sameSet(state.variantSets[v], state.activePaletteIndices)) keep = keep || v; });
        state.variantKey = key;
        state.variantSets = computeVariantSets(original);
        if (keep) state.variantKeep = keep;
        else if (sameImg ? false : !state.skipAutoVariant) state.variantAutoApply = true; // 同じ画像で手動の色なら、手動のまま
        state.skipAutoVariant = false;
      }
      const ditherEl = $('cc-dither');
      const factor = Math.min(1, Math.max(0, (ditherEl ? (parseFloat(ditherEl.value) || 0) : 0) / 100));
      // 3つの変換の上のスライダーも、同じ値にそろえる（途中保存からの再開などで値が変わったときも）
      const pct = Math.round(factor * 100);
      if ($('cc-dither2')) $('cc-dither2').value = pct;
      if ($('cc-dither2-val')) $('cc-dither2-val').textContent = pct;
      Object.keys(VARIANTS).forEach((v) => {
        const entries = state.variantSets[v].map((i) => ALL_COLORS[i]);
        const { imageData, usedEntries } = getReducedImageData(original, original.width, original.height, factor, entries, { lut: carpetLut(entries) });
        const cv = $('cc-var-' + v);
        cv.width = original.width;
        cv.height = original.height;
        cv.getContext('2d').putImageData(imageData, 0, 0);
        const chips = $('cc-var-' + v + '-chips');
        chips.innerHTML = '';
        usedEntries.forEach((col) => {
          const c = document.createElement('div');
          c.className = 'psd-color-chip';
          c.style.backgroundColor = 'rgb(' + col.rgb.join(',') + ')';
          c.title = col.name + ' rgb(' + col.rgb.join(',') + ')';
          chips.appendChild(c);
        });
        const paid = usedEntries.filter((c) => c.isOp && c.price > 0).length;
        $('cc-var-' + v + '-text').textContent = '使用 ' + usedEntries.length + '色'
          + (paid ? '（うち有償オプション ' + paid + '色：' + usedEntries.filter((c) => c.isOp && c.price > 0).map((c) => c.name).join('・') + '）' : '（すべて無償色）')
          + '・階調表現 ' + pct + '%';
      });
      if (state.variantKeep) {
        const v = state.variantKeep;
        state.variantKeep = null;
        applyVariant(v);
        return;
      }
      if (state.variantAutoApply) {
        // 新しい画像：まず「① 標準色のみ」を選んだ状態にする
        state.variantAutoApply = false;
        applyVariant('std');
        return;
      }
      refreshVariantSelection();
    } catch (err) {
      debug('変換の比較表示エラー: ' + err.message, true);
    }
  }

  // いま選ばれている色の組合せと同じ変換を強調。どれとも違えば（手動）、手動の結果を表示する
  function refreshVariantSelection() {
    if (!state.variantSets) return;
    let hit = null;
    Object.keys(VARIANTS).forEach((v) => { if (sameSet(state.variantSets[v], state.activePaletteIndices)) hit = hit || v; });
    document.querySelectorAll('.cc-var-card').forEach((c) => {
      const on = c.getAttribute('data-var') === hit;
      c.classList.toggle('is-selected', on);
      const b = c.querySelector('.cc-var-btn');
      if (b) b.textContent = on ? '✅ 選択中（見積もり・保存・注文の対象）' : 'この変換で進める';
    });
    const manual = $('cc-manual-card');
    if (manual) manual.hidden = !!hit;
    const note = $('cc-var-note');
    if (note) {
      note.textContent = hit
        ? '「' + VARIANTS[hit].label + '」を選んでいます。この変換が、お見積もり・PSD保存・ご注文の対象になります。色は下のパレットで手動でも変えられます。'
        : '色を手動で選んでいます（下に結果を表示）。3通りの自動変換に戻すには、上の「この変換で進める」を押してください。';
    }
  }

  function applyVariant(v) {
    if (!state.variantSets || !state.variantSets[v]) return;
    state.activePaletteIndices.clear();
    state.variantSets[v].forEach((i) => state.activePaletteIndices.add(i));
    const base = $('cc-base-palette-selector'), op = $('cc-op-palette-selector');
    if (base) Array.from(base.children).forEach((el, i) => el.classList.toggle('active', state.activePaletteIndices.has(i)));
    if (op) Array.from(op.children).forEach((el, j) => el.classList.toggle('active', state.activePaletteIndices.has(FREE_COUNT + j)));
    reprocessReduction();
    calculateEstimate();
    refreshVariantSelection();
  }

  let variantTimer = null;
  function scheduleVariants() {
    clearTimeout(variantTimer);
    variantTimer = setTimeout(renderVariants, 120);
  }

  function reprocessReduction() {
    try {
      const original = $('cc-original');
      const reduced = $('cc-reduced');
      if (!original || !reduced || !original.width) return;

      const w = original.width;
      const h = original.height;
      const active = getActivePaletteEntries();

      const ditherEl = $('cc-dither');
      const ditherAmount = ditherEl ? (parseFloat(ditherEl.value) || 0) : 0;
      const ditherFactor = Math.min(1, Math.max(0, ditherAmount / 100));

      const { imageData, usedEntries } = getReducedImageData(original, w, h, ditherFactor, active, { lut: carpetLut(active) });
      state.reduceGen = (state.reduceGen || 0) + 1; // 実寸の変換画像（保存用）を作り直す

      reduced.width = w;
      reduced.height = h;
      reduced.getContext('2d').putImageData(imageData, 0, 0);

      state.lastUsedColorEntries = usedEntries;
      renderUsedColorsUI(usedEntries);
      if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated();
      scheduleVariants();
      refreshVariantSelection();
    } catch (err) {
      debug('reprocessReduction エラー: ' + err.message, true);
    }
  }

  function loadAgPsd() {
    if (window.agPsd) return Promise.resolve(window.agPsd);
    if (window.__cocoonAgPsdPromise) return window.__cocoonAgPsdPromise;
    window.__cocoonAgPsdPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/ag-psd/dist/bundle.js';
      script.async = true;
      script.onload = () => {
        if (window.agPsd) resolve(window.agPsd);
        else reject(new Error('ag-psd の読み込みエラー'));
      };
      script.onerror = () => reject(new Error('PSDライブラリの読み込み失敗'));
      document.head.appendChild(script);
    });
    return window.__cocoonAgPsdPromise;
  }

  // ---------------------------------------------------------------------------
  // CMYK PSD 書き出し（壁紙用）。ag-psd は CMYK の書き出しに未対応のため、PSD を直接組み立てる。
  // 8bit / CMYK / レイヤー付き / RLE圧縮。RGB→CMYK は ICC を使わない単純変換（K=1-max(R,G,B)）。
  // layers: [{ name, canvas }]（下のレイヤーから順に）。composite: 統合イメージ用キャンバス
  // ---------------------------------------------------------------------------
  function writeCmykPsd(width, height, composite, layers, dpi) {
    const n = width * height;
    function toPlanes(canvas) {
      const d = canvas.getContext('2d').getImageData(0, 0, width, height).data;
      const p = [new Uint8Array(n), new Uint8Array(n), new Uint8Array(n), new Uint8Array(n), new Uint8Array(n)]; // C,M,Y,K,A
      const pc = p[0], pm = p[1], py = p[2], pk = p[3], pa = p[4];
      let last = -1, lc = 255, lm = 255, ly = 255, lk = 255;
      for (let i = 0, j = 0; i < n; i++, j += 4) {
        const a = d[j + 3];
        pa[i] = a;
        if (a === 0) { pc[i] = pm[i] = py[i] = pk[i] = 255; continue; }
        const r = d[j], g = d[j + 1], b = d[j + 2];
        const key = (r << 16) | (g << 8) | b;
        if (key === last) { pc[i] = lc; pm[i] = lm; py[i] = ly; pk[i] = lk; continue; } // 同じ色が続くときは再計算しない
        const mx = Math.max(r, g, b);
        const kInk = 255 - mx;                       // K のインク量 0..255
        let c = 0, m = 0, y = 0;
        if (mx > 0) { c = Math.round((mx - r) * 255 / mx); m = Math.round((mx - g) * 255 / mx); y = Math.round((mx - b) * 255 / mx); }
        // PSD の CMYK は 255=インクなし の反転値で保存する
        last = key; lc = 255 - c; lm = 255 - m; ly = 255 - y; lk = 255 - kInk;
        pc[i] = lc; pm[i] = lm; py[i] = ly; pk[i] = lk;
      }
      return p;
    }
    function packBits(plane) { // 行ごとにRLE。{counts:Uint16Array(height), data:Uint8Array}
      const counts = new Uint16Array(height);
      let out = new Uint8Array(Math.max(1024, n >> 3)); let o = 0;
      const rowBuf = new Uint8Array(width * 2 + 4);
      for (let y = 0; y < height; y++) {
        const base = y * width; let i = 0, r = 0;
        while (i < width) {
          const v = plane[base + i];
          let run = 1;
          // ※ WordPress の整形（wptexturize）で論理積の記号が壊れないよう、ここでは比較と論理積を同じ行に書かない
          while (i + run !== width) { if (run === 128) break; if (plane[base + i + run] !== v) break; run++; }
          if (run >= 2) { rowBuf[r++] = 257 - run; rowBuf[r++] = v; i += run; continue; }
          const start = i; i++;
          while (i !== width) {
            if (i - start === 128) break;
            if (i + 1 !== width) { if (plane[base + i] === plane[base + i + 1]) break; }
            i++;
          }
          rowBuf[r++] = i - start - 1;
          for (let k = start; k < i; k++) rowBuf[r++] = plane[base + k];
        }
        if (o + r > out.length) { const bigger = new Uint8Array(Math.max(out.length * 2, o + r)); bigger.set(out); out = bigger; }
        out.set(rowBuf.subarray(0, r), o); o += r; counts[y] = r;
      }
      return { counts, data: out.subarray(0, o) };
    }
    const parts = []; let size = 0;
    const push = (u8) => { parts.push(u8); size += u8.length; };
    const be = (bytes, v) => { const u = new Uint8Array(bytes); for (let i = bytes - 1; i >= 0; i--) { u[i] = v & 255; v = Math.floor(v / 256); } return u; };
    const i16 = (v) => be(2, v < 0 ? v + 65536 : v);
    const i32 = (v) => be(4, v < 0 ? v + 4294967296 : v);
    const ascii = (t) => Uint8Array.from(t.split('').map((c) => c.charCodeAt(0)));
    const concat = (arr) => { const t = arr.reduce((a, b) => a + b.length, 0); const u = new Uint8Array(t); let o = 0; arr.forEach((b) => { u.set(b, o); o += b.length; }); return u; };
    // チャンネル（RLE）= 圧縮方式(2) + 行バイト数 + データ
    const encodeChannel = (plane) => {
      const r = packBits(plane);
      const cnt = new Uint8Array(height * 2);
      r.counts.forEach((c, i) => { cnt[i * 2] = c >> 8; cnt[i * 2 + 1] = c & 255; });
      return concat([i16(1), cnt, r.data]);
    };

    // ---- ヘッダー ----
    push(ascii('8BPS')); push(i16(1)); push(new Uint8Array(6)); push(i16(4));
    push(i32(height)); push(i32(width)); push(i16(8)); push(i16(4)); // 4 = CMYK
    push(i32(0)); // カラーモードデータなし
    // 画像リソース：解像度
    const fx = Math.round(dpi * 65536);
    const resBody = concat([ascii('8BIM'), i16(1005), i16(0), i32(16), i32(fx), i16(1), i16(1), i32(fx), i16(1), i16(1)]);
    push(i32(resBody.length)); push(resBody);

    // ---- レイヤー ----
    const recs = []; const dataParts = [];
    layers.forEach((L) => {
      const pl = toPlanes(L.canvas);
      const order = [[-1, pl[4]], [0, pl[0]], [1, pl[1]], [2, pl[2]], [3, pl[3]]];
      const enc = order.map((o) => encodeChannel(o[1]));
      const nameBytes = Uint8Array.from(L.name.split('').map((c) => (c.charCodeAt(0) > 126 ? 63 : c.charCodeAt(0)))).subarray(0, 255); // ASCII（日本語は luni）
      // Pascal文字列（4バイト境界に詰める）
      let pad = (4 - ((1 + nameBytes.length) % 4)) % 4;
      const pascal = concat([Uint8Array.of(nameBytes.length), nameBytes, new Uint8Array(pad)]);
      // Unicodeレイヤー名（luni）で日本語名を保持
      const uni = [i32(L.name.length)]; const ub = new Uint8Array(L.name.length * 2);
      for (let i = 0; i < L.name.length; i++) { const c = L.name.charCodeAt(i); ub[i * 2] = c >> 8; ub[i * 2 + 1] = c & 255; }
      let luniData = concat([i32(L.name.length), ub]);
      if (luniData.length % 4) luniData = concat([luniData, new Uint8Array(4 - (luniData.length % 4))]);
      const luni = concat([ascii('8BIM'), ascii('luni'), i32(luniData.length), luniData]);
      const extra = concat([i32(0), i32(0), pascal, luni]);
      const head = [i32(0), i32(0), i32(height), i32(width), i16(5)];
      order.forEach((o, i) => { head.push(i16(o[0])); head.push(i32(enc[i].length)); });
      head.push(ascii('8BIM'), ascii('norm'), Uint8Array.of(255, 0, 0, 0), i32(extra.length), extra);
      recs.push(concat(head)); enc.forEach((e) => dataParts.push(e));
    });
    let layerInfo = concat([i16(layers.length), ...recs, ...dataParts]);
    if (layerInfo.length % 2) layerInfo = concat([layerInfo, new Uint8Array(1)]);
    const layerSection = concat([i32(layerInfo.length), layerInfo, i32(0)]); // + グローバルレイヤーマスク情報(空)
    push(i32(layerSection.length)); push(layerSection);

    // ---- 統合イメージ（CMYK 4チャンネル・RLE）----
    const cp = toPlanes(composite);
    const cenc = [0, 1, 2, 3].map((k) => packBits(cp[k]));
    push(i16(1));
    cenc.forEach((r) => { const cnt = new Uint8Array(height * 2); r.counts.forEach((c, i) => { cnt[i * 2] = c >> 8; cnt[i * 2 + 1] = c & 255; }); push(cnt); });
    cenc.forEach((r) => push(r.data));
    return new Blob(parts, { type: 'image/vnd.adobe.photoshop' });
  }
  // 大きな絵（部屋一周の壁など）用：タイル（横 4096px × 縦 256px）ずつ描いて CMYK に変換・圧縮するので、
  // 絵全体の大きさの canvas を作らない（メモリを使い切って固まるのを防ぐ）。途中で画面に処理を返し、進み具合を知らせる。
  // layers: [{ name, draw(ctx) }]（ctx は絵全体の座標）。compositeDraw(ctx): 統合イメージ（白地の上に全レイヤー）
  // 縦か横が 30000px を超える絵は PSD に入らないので、Photoshop の大きなドキュメント形式（PSB）で書く
  // 重い処理（CMYK への変換・圧縮・統合イメージの合成・ZIP 用の CRC32）は別スレッド（assets/js/wall-psd-worker.js）で行い、
  // この画面では絵を描いて画素を読むだけにする（保存中も画面が固まらない）。Worker が使えないときは、この画面で少しずつ行う。
  const WALL_PSD_JS = '{{CFP_ASSET_URL}}js/wall-psd-worker.js?ver={{CFP_VERSION}}';
  const WALL_PSD_VER = 1;
  function startWallWorker(url) {
    return new Promise((resolve) => {
      let wk = null;
      const fail = () => { if (wk) wk.terminate(); resolve(null); };
      try { wk = new Worker(url); } catch (e) { resolve(null); return; }
      const timer = setTimeout(fail, 8000);
      wk.onerror = () => { clearTimeout(timer); fail(); };
      wk.onmessage = (ev) => { if (ev.data ? ev.data.type === 'ready' : false) { clearTimeout(timer); if (ev.data.ver === WALL_PSD_VER) resolve(wk); else fail(); } };
    });
  }
  async function getWallWorker() {
    if (!window.Worker) return null;
    let wk = await startWallWorker(WALL_PSD_JS);
    if (wk) return wk;
    // 別のドメイン（CDN など）から読まれて起動できないときは、内容を読み込んでこのページの Worker として起動する
    try {
      const text = await (await fetch(WALL_PSD_JS + '.' + Date.now(), { cache: 'no-store' })).text();
      wk = await startWallWorker(URL.createObjectURL(new Blob([text], { type: 'text/javascript' })));
    } catch (e) { wk = null; }
    return wk;
  }
  async function writeCmykPsdWorker(wk, width, height, layers, dpi, onProgress) {
    const call = (msg, transfer) => new Promise((resolve, reject) => {
      wk.onmessage = (ev) => { const m = ev.data; if (m.type === 'error') reject(new Error(m.message || 'PSDを作成できませんでした')); else resolve(m); };
      wk.onerror = (e) => reject(new Error((e ? e.message : '') || 'PSDを作成できませんでした'));
      wk.postMessage(msg, transfer || []);
    });
    await call({ type: 'begin', width, height, names: layers.map((L) => L.name), dpi });
    const TW = 4096, TH = 256;
    const tile = document.createElement('canvas');
    tile.width = Math.min(TW, width); tile.height = Math.min(TH, height);
    const tctx = tile.getContext('2d', { willReadFrequently: true });
    const bands = Math.ceil(height / TH);
    let pending = null;
    for (let b = 0; b !== bands; b++) {
      const y0 = b * TH, bh = Math.min(TH, height - y0);
      const bufs = [];
      for (const L of layers) {
        const buf = new Uint8ClampedArray(width * bh * 4);
        for (let x0 = 0; x0 < width; x0 += TW) {
          const bw = Math.min(TW, width - x0);
          tctx.setTransform(1, 0, 0, 1, 0, 0);
          tctx.clearRect(0, 0, tile.width, tile.height);
          tctx.setTransform(1, 0, 0, 1, -x0, -y0);
          tctx.save(); L.draw(tctx); tctx.restore();
          const d = tctx.getImageData(0, 0, bw, bh).data;
          for (let yy = 0; yy !== bh; yy++) buf.set(d.subarray(yy * bw * 4, (yy + 1) * bw * 4), (yy * width + x0) * 4);
          await new Promise((res) => setTimeout(res, 0)); // 画面に処理を返す
        }
        bufs.push(buf.buffer);
      }
      if (pending) await pending; // 別スレッドが前の帯を終えるまで待つ（メモリを使いすぎない）
      pending = call({ type: 'band', y0, bh, bufs }, bufs);
      if (onProgress) onProgress((b + 0.5) / bands * 0.97);
    }
    if (pending) await pending;
    if (onProgress) onProgress(0.98);
    const r = await call({ type: 'end' });
    tile.width = tile.height = 1;
    const blob = new Blob(r.parts, { type: 'image/vnd.adobe.photoshop' });
    blob.cfpCrc = r.crc; // ZIP にまとめるときに使う（もう一度読み直さなくてよい）
    return blob;
  }
  async function writeCmykPsdTiled(width, height, layers, compositeDraw, dpi, onProgress) {
    const wk = await getWallWorker();
    if (wk) {
      try { return await writeCmykPsdWorker(wk, width, height, layers, dpi, onProgress); }
      finally { wk.terminate(); }
    }
    const TW = 4096, TH = 256;
    const big = width > 30000 || height > 30000;
    const tile = document.createElement('canvas');
    tile.width = Math.min(TW, width); tile.height = Math.min(TH, height);
    const tctx = tile.getContext('2d', { willReadFrequently: true });
    const be = (bytes, v) => { const u = new Uint8Array(bytes); for (let i = bytes - 1; i >= 0; i--) { u[i] = v % 256; v = Math.floor(v / 256); } return u; };
    const i16 = (v) => be(2, v < 0 ? v + 65536 : v);
    const i32 = (v) => be(4, v < 0 ? v + 4294967296 : v);
    const len = (v) => be(big ? 8 : 4, v); // PSB では長さの一部が 8 バイト
    const ascii = (t) => Uint8Array.from(t.split('').map((c) => c.charCodeAt(0)));
    const concat = (arr) => { const t = arr.reduce((x, y) => x + y.length, 0); const u = new Uint8Array(t); let o = 0; arr.forEach((y) => { u.set(y, o); o += y.length; }); return u; };
    const RB = big ? 4 : 2; // 行ごとの圧縮バイト数の大きさ
    const rowCounts = (counts) => { const u = new Uint8Array(height * RB); counts.forEach((v, i) => u.set(be(RB, v), i * RB)); return u; };
    const rowBuf = new Uint8Array(width * 2 + 4);
    const rleRow = (plane, base) => { // 1行を PackBits で圧縮
      let i = 0, r = 0;
      while (i !== width) {
        const v = plane[base + i];
        let run = 1;
        while (i + run !== width) { if (run === 128) break; if (plane[base + i + run] !== v) break; run++; }
        if (run >= 2) { rowBuf[r++] = 257 - run; rowBuf[r++] = v; i += run; continue; }
        const start = i; i++;
        while (i !== width) {
          if (i - start === 128) break;
          if (i + 1 !== width) { if (plane[base + i] === plane[base + i + 1]) break; }
          i++;
        }
        rowBuf[r++] = i - start - 1;
        for (let q = start; q !== i; q++) rowBuf[r++] = plane[base + q];
      }
      return rowBuf.slice(0, r);
    };
    const totalSteps = (layers.length + 1) * Math.ceil(height / TH);
    let step = 0;
    // draw: 描く関数 → チャンネルごとの { counts, chunks }（C,M,Y,K と、withAlpha なら A）
    const encode = async (draw, withAlpha, white) => {
      const ch = [0, 1, 2, 3, 4].map(() => ({ counts: new Uint32Array(height), chunks: [], size: 0 }));
      for (let y0 = 0; y0 < height; y0 += TH) {
        const bh = Math.min(TH, height - y0), n = width * bh;
        const pl = [new Uint8Array(n), new Uint8Array(n), new Uint8Array(n), new Uint8Array(n), new Uint8Array(n)];
        for (let x0 = 0; x0 < width; x0 += TW) {
          const bw = Math.min(TW, width - x0);
          tctx.setTransform(1, 0, 0, 1, 0, 0);
          tctx.clearRect(0, 0, tile.width, tile.height);
          if (white) { tctx.fillStyle = '#ffffff'; tctx.fillRect(0, 0, tile.width, tile.height); }
          tctx.setTransform(1, 0, 0, 1, -x0, -y0);
          tctx.save(); draw(tctx); tctx.restore();
          const d = tctx.getImageData(0, 0, bw, bh).data;
          let last = -1, lc = 255, lm = 255, ly = 255, lk = 255;
          for (let yy = 0; yy !== bh; yy++) {
            for (let xx = 0; xx !== bw; xx++) {
              const j = (yy * bw + xx) * 4, i = yy * width + x0 + xx;
              const al = d[j + 3];
              pl[4][i] = al;
              if (al === 0) { pl[0][i] = pl[1][i] = pl[2][i] = pl[3][i] = 255; continue; }
              const rr = d[j], gg = d[j + 1], bb = d[j + 2];
              const key = rr * 65536 + gg * 256 + bb;
              if (key !== last) {
                const mx = Math.max(rr, gg, bb);
                let c = 0, m = 0, yv = 0;
                if (mx > 0) { c = Math.round((mx - rr) * 255 / mx); m = Math.round((mx - gg) * 255 / mx); yv = Math.round((mx - bb) * 255 / mx); }
                last = key; lc = 255 - c; lm = 255 - m; ly = 255 - yv; lk = mx; // 255 = インクなし
              }
              pl[0][i] = lc; pl[1][i] = lm; pl[2][i] = ly; pl[3][i] = lk;
            }
          }
        }
        for (let c = 0; c !== (withAlpha ? 5 : 4); c++) {
          for (let yy = 0; yy !== bh; yy++) {
            const row = rleRow(pl[c], yy * width);
            ch[c].counts[y0 + yy] = row.length; ch[c].chunks.push(row); ch[c].size += row.length;
          }
        }
        step++;
        if (onProgress) onProgress(step / totalSteps);
        await new Promise((res) => setTimeout(res, 0)); // 画面に処理を返す（固まらない）
      }
      return ch;
    };
    const chanBytes = (c) => [i16(1), rowCounts(c.counts)].concat(c.chunks); // 圧縮方式(1=RLE) + 行バイト数 + データ
    const chanLen = (c) => 2 + height * RB + c.size;

    const parts = [];
    parts.push(ascii('8BPS'), i16(big ? 2 : 1), new Uint8Array(6), i16(4), i32(height), i32(width), i16(8), i16(4), i32(0));
    const fx = Math.round(dpi * 65536);
    const resBody = concat([ascii('8BIM'), i16(1005), i16(0), i32(16), i32(fx), i16(1), i16(1), i32(fx), i16(1), i16(1)]);
    parts.push(i32(resBody.length), resBody);

    const recs = [], data = [];
    let dataLen = 0;
    for (const L of layers) {
      const ch = await encode(L.draw, true, false);
      const order = [[-1, ch[4]], [0, ch[0]], [1, ch[1]], [2, ch[2]], [3, ch[3]]];
      // 旧形式のレイヤー名は ASCII だけ（日本語は「?」）。日本語の名前は luni（Unicode）で持つ
      const nameBytes = Uint8Array.from(L.name.split('').map((c) => (c.charCodeAt(0) > 126 ? 63 : c.charCodeAt(0)))).subarray(0, 255);
      const pad = (4 - ((1 + nameBytes.length) % 4)) % 4;
      const pascal = concat([Uint8Array.of(nameBytes.length), nameBytes, new Uint8Array(pad)]);
      const ub = new Uint8Array(L.name.length * 2);
      for (let i = 0; i !== L.name.length; i++) { const c = L.name.charCodeAt(i); ub[i * 2] = c >> 8; ub[i * 2 + 1] = c % 256; }
      let luniData = concat([i32(L.name.length), ub]);
      if (luniData.length % 4) luniData = concat([luniData, new Uint8Array(4 - (luniData.length % 4))]);
      const luni = concat([ascii('8BIM'), ascii('luni'), i32(luniData.length), luniData]);
      const extra = concat([i32(0), i32(0), pascal, luni]);
      const head = [i32(0), i32(0), i32(height), i32(width), i16(5)];
      order.forEach((o) => { head.push(i16(o[0])); head.push(len(chanLen(o[1]))); });
      head.push(ascii('8BIM'), ascii('norm'), Uint8Array.of(255, 0, 0, 0), i32(extra.length), extra);
      recs.push(concat(head));
      order.forEach((o) => { chanBytes(o[1]).forEach((u) => { data.push(u); dataLen += u.length; }); });
    }
    const recLen = recs.reduce((t, u) => t + u.length, 0);
    let layerInfoLen = 2 + recLen + dataLen;
    const odd = layerInfoLen % 2;
    layerInfoLen += odd;
    parts.push(len((big ? 8 : 4) + layerInfoLen + 4), len(layerInfoLen), i16(layers.length));
    recs.forEach((u) => parts.push(u));
    data.forEach((u) => parts.push(u));
    if (odd) parts.push(new Uint8Array(1));
    parts.push(i32(0)); // グローバルレイヤーマスク情報（空）

    const comp = await encode(compositeDraw, false, true);
    parts.push(i16(1));
    [0, 1, 2, 3].forEach((c) => parts.push(rowCounts(comp[c].counts)));
    [0, 1, 2, 3].forEach((c) => comp[c].chunks.forEach((u) => parts.push(u)));
    return new Blob(parts, { type: 'image/vnd.adobe.photoshop' });
  }


  // 大きなカーペット（例：6.5m×7.5m＝約4,900万画素）でも画面が固まらないよう、減色とPSD作成を
  // 別のスレッド（Web Worker：assets/js/carpet-psd-worker.js）で行い、進み具合をボタンに表示する。
  // Worker が使えないときは、同じ処理をこの画面で少しずつ行う（どちらも少ないメモリで、仕上がりは同じ）。
  // ?ver= を付けて、ブラウザ・サーバーのキャッシュに残った古い部品（1レイヤーのPSDを作る）を読まないようにする
  const CARPET_PSD_JS = '{{CFP_ASSET_URL}}js/carpet-psd-worker.js?ver={{CFP_VERSION}}';
  const CARPET_PSD_VER = 9;
  // 起動して「準備できた」と返ってきた Worker（データを渡す前に確かめる。だめなら null）
  function startCarpetWorker(url) {
    return new Promise((resolve) => {
      let wk = null;
      const fail = () => { if (wk) wk.terminate(); resolve(null); };
      try { wk = new Worker(url); } catch (e) { resolve(null); return; }
      const timer = setTimeout(fail, 8000);
      wk.onerror = () => { clearTimeout(timer); fail(); };
      // 図を描くための OffscreenCanvas が Worker の中で使えるときだけ使う（使えなければこの画面で作る）
      wk.onmessage = (ev) => { if (ev.data ? ev.data.type === 'ready' : false) { clearTimeout(timer); if (ev.data.offscreen ? ev.data.ver === CARPET_PSD_VER : false) resolve(wk); else fail(); } };
    });
  }
  async function getCarpetWorker() {
    if (!window.Worker) return null;
    let wk = await startCarpetWorker(CARPET_PSD_JS);
    if (wk) return wk;
    // 別のドメイン（CDN など）から読まれて起動できないときは、内容を読み込んでこのページの Worker として起動する
    try {
      const text = await (await fetch(CARPET_PSD_JS + '.' + Date.now(), { cache: 'no-store' })).text();
      wk = await startCarpetWorker(URL.createObjectURL(new Blob([text], { type: 'text/javascript' })));
    } catch (e) { wk = null; }
    return wk;
  }
  function loadCarpetPsdScript() {
    const isNew = () => (window.CFPCarpetPsd ? window.CFPCarpetPsd.ver === CARPET_PSD_VER : false);
    if (isNew()) return Promise.resolve(window.CFPCarpetPsd);
    return new Promise((resolve, reject) => {
      const sc = document.createElement('script');
      sc.src = CARPET_PSD_JS + '.' + Date.now();
      sc.onload = () => (isNew() ? resolve(window.CFPCarpetPsd) : reject(new Error('PSD作成の部品が古いままです。ブラウザのキャッシュとサイトのキャッシュ（Autoptimize など）を削除して、ページを読み込み直してください。')));
      sc.onerror = () => reject(new Error('PSD作成の部品（carpet-psd-worker.js）を読み込めませんでした'));
      document.head.appendChild(sc);
    });
  }
  async function makeCarpetPsd(job, progress) {
    const wk = await getCarpetWorker();
    if (wk) {
      return new Promise((resolve, reject) => {
        wk.onmessage = (ev) => {
          const m = ev.data;
          if (m.type === 'progress') { progress(m.value); return; }
          wk.terminate();
          if (m.type === 'done') resolve(m); else reject(new Error(m.message || 'PSDを作成できませんでした'));
        };
        wk.onerror = (e) => { wk.terminate(); reject(new Error((e ? e.message : '') || 'PSDを作成できませんでした')); };
        wk.postMessage(job, [job.rgba]);
      });
    }
    const lib = await loadCarpetPsdScript();
    return lib.run(job, progress);
  }

  // 変換画像を実寸（1px = 1mm・指定サイズ＋上下左右の余白）で作る。元画像を先に実寸まで引き伸ばしてから色を変換するので、
  // サイズが大きくても最小1pxで表現できる（画面のプレビューは最大1000pxに縮めているため、保存には使わない）。
  // 設定が変わるまでは作った画像を使い回す。
  let carpetFullCache = null;
  async function carpetReducedFull(progress) {
    if (!state.loadedImg) return null;
    const gen = state.reduceGen || 0;
    if (carpetFullCache) { if (carpetFullCache.gen === gen) return carpetFullCache; }
    const sizeW = Math.max(1, Math.round(parseFloat($('cc-width').value) || 1000));
    const sizeH = Math.max(1, Math.round(parseFloat($('cc-height').value) || 1000));
    const w = sizeW + CARPET_BLEED * 2, h = sizeH + CARPET_BLEED * 2;
    const ditherFactor = Math.min(1, Math.max(0, (parseFloat(($('cc-dither') || {}).value) || 0) / 100));
    const activeEntries = getActivePaletteEntries();
    const c = document.createElement('canvas');
    c.width = w; c.height = h;
    const ctx = c.getContext('2d', { willReadFrequently: true });
    if (!ctx) throw new Error('画像を用意できませんでした（大きすぎる可能性があります）。');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    drawImageCover(ctx, state.loadedImg, w, h);
    const data = ctx.getImageData(0, 0, w, h).data;
    const res = await makeCarpetPsd({ mode: 'reduce', rgba: data.buffer, width: w, height: h, palette: activeEntries.map((e) => e.rgb), dither: ditherFactor, lut: carpetLut(activeEntries) }, progress || (() => {}));
    ctx.putImageData(new ImageData(new Uint8ClampedArray(res.parts[0]), w, h), 0, 0);
    carpetFullCache = { gen, canvas: c, width: w, height: h, sizeW, sizeH, bleed: CARPET_BLEED };
    return carpetFullCache;
  }
  window.cfpCarpetReducedFull = carpetReducedFull;

  // 人間の変換の学習（Gemini・管理者だけ。assets/js/gemini-learn.js）が使う部品
  window.cfpCarpetLearn = {
    colors: ALL_COLORS,
    freeCount: FREE_COUNT,
    original: () => $('cc-original'),
    // 元画像と同じ切り抜き方（縦横比を変えずにいっぱい・画像の大きさ）で描く
    drawCover: (ctx, img, W, H) => drawImageCover(ctx, img, W, H),
    // システムの変換の色の組合せ：std（標準色のみ）・op3（標準色13＋オプション3）・op6（標準色10＋オプション6）
    sets: () => {
      const original = $('cc-original');
      if (!original || !original.width) return null;
      const look = carpetLook();
      const hist = colorHistogram(original, LOOKS[look].edge);
      const rel = colorRelations(hist, original);
      const free = [], opt = [];
      for (let i = 0; i < ALL_COLORS.length; i++) (i < FREE_COUNT ? free : opt).push(i);
      const vs = state.variantSets || {};
      return {
        std: vs.std || selectPalette(hist, free, 16, null, look, rel),
        op3: vs.op3 || selectPalette(hist, free.concat(opt), 16, { free: 13, opt: 3 }, look, rel),
        op6: selectPalette(hist, free.concat(opt), 16, { free: 10, opt: 6 }, look, rel)
      };
    },
    // 色の組合せ（ALL_COLORS の番号）で、画面と同じ変換をした画像
    render: (indices) => {
      const original = $('cc-original');
      const entries = indices.map((i) => ALL_COLORS[i]);
      const factor = Math.min(1, Math.max(0, (parseFloat(($('cc-dither') || {}).value) || 0) / 100));
      return getReducedImageData(original, original.width, original.height, factor, entries, { lut: carpetLut(entries) });
    },
    // 学習した変換の色の対応表：選んだ色（entries）の中から、システムと同じ見え方の近さで1点ずつ選ぶ。
    // ただし、その色がいちばん近い「色のまとまり」に Gemini が割り当てた色（slot）は選ばれやすくする（bias：0〜1、小さいほど強く）
    blendLut: (entries, clusterLabs, slot, bias) => {
      const L = LOOKS[carpetLook()] || LOOKS.natural;
      const pl = entries.map((e) => rgbToLab(e.rgb[0], e.rgb[1], e.rgb[2]));
      const lut = new Uint8Array(32768);
      for (let i = 0; i !== 32768; i++) {
        const lab = rgbToLab((i >> 10) * 8 + 4, ((i >> 5) % 32) * 8 + 4, (i % 32) * 8 + 4);
        let nk = 0, nd = Infinity;
        for (let k = 0; k !== clusterLabs.length; k++) {
          const q = clusterLabs[k], d = (lab[0] - q[0]) ** 2 + (lab[1] - q[1]) ** 2 + (lab[2] - q[2]) ** 2;
          if (d < nd) { nd = d; nk = k; }
        }
        const pref = slot[nk], t = lookTarget(lab, L);
        let best = pref, bd = Infinity;
        for (let p = 0; p !== pl.length; p++) {
          const d = lookDist(t, pl[p], L) * (p === pref ? bias : 1);
          if (d < bd) { bd = d; best = p; }
        }
        lut[i] = best;
      }
      return lut;
    },
    // 色の対応表（32768：RGB を5bitずつ → entries の番号）で変換した画像
    renderLut: (entries, lut, factor) => {
      const original = $('cc-original');
      return getReducedImageData(original, original.width, original.height, Math.min(1, Math.max(0, factor || 0)), entries, { lut });
    },
    // いま選ばれている色（人間が選んだ色）・階調表現（0〜100）・いまの変換画像（シミュレーターで変換した結果）
    active: () => ({
      indices: Array.from(state.activePaletteIndices).sort((a, b) => a - b),
      dither: Math.round(Math.min(100, Math.max(0, parseFloat(($('cc-dither') || {}).value) || 0))),
      canvas: $('cc-reduced')
    }),
    // 学習した変換の色の組合せを、パレットに反映する（そのあとの変換・見積もり・保存はシステムの変換）
    select: (indices) => {
      state.activePaletteIndices.clear();
      indices.forEach((i) => state.activePaletteIndices.add(i));
      const base = $('cc-base-palette-selector'), op = $('cc-op-palette-selector');
      if (base) Array.from(base.children).forEach((el, i) => el.classList.toggle('active', state.activePaletteIndices.has(i)));
      if (op) Array.from(op.children).forEach((el, j) => el.classList.toggle('active', state.activePaletteIndices.has(FREE_COUNT + j)));
      reprocessReduction();
      calculateEstimate();
      refreshVariantSelection();
    }
  };

  // 新ページ（公開の注文ページ）から来た注文を、この特許ページ（管理者だけ）で変換するための部品（assets/js/carpet-order-admin.js が使う）
  window.cfpCarpetOrder = {
    // 注文の画像を読み込む（読み込み後に done）
    loadFile: (file, done) => handleFile(file, done),
    // 注文の仕様（パイル形状・サイズ・地域）を画面に入れる
    setSpec: (spec) => {
      if ($('cc-material') ? spec.material : false) $('cc-material').value = spec.material;
      if ($('cc-width') ? spec.width : false) $('cc-width').value = spec.width;
      if ($('cc-height') ? spec.height : false) $('cc-height').value = spec.height;
      if ($('cc-region') ? spec.region : false) $('cc-region').value = spec.region;
      calculateEstimate();
      if (state.loadedImg) updateCarpetCanvas();
    },
    // 3通りの自動変換：画面の変換画像・使う色の名前（3通りがそろうまでは null）
    variants: () => {
      if (!state.variantSets) return null;
      const out = {};
      let ok = true;
      Object.keys(VARIANTS).forEach((v) => {
        const cv = $('cc-var-' + v);
        if (!cv ? true : !cv.width) ok = false;
        out[v] = { label: VARIANTS[v].label, canvas: cv, colors: state.variantSets[v].map((i) => ALL_COLORS[i].name) };
      });
      return ok ? out : null;
    },
    // 3通りの自動変換の色（パレット番号）
    autoSets: () => (state.variantSets ? { std: state.variantSets.std.slice(), op3: state.variantSets.op3.slice(), max: state.variantSets.max.slice() } : null),
    // パレットの全色（番号・名前・色・有償か）。パレットの版を切り替えると色が変わるので、毎回読む
    palette: () => ALL_COLORS.map((c, i) => ({ i: i, name: c.name, rgb: c.rgb.slice(), paid: c.isOp ? c.price > 0 : false })),
    // いまパレットで選んでいる色（パレット番号）と階調表現（0〜100）
    current: () => ({
      indices: Array.from(state.activePaletteIndices).sort((a, b) => a - b),
      dither: Math.round(Math.min(100, Math.max(0, parseFloat(($('cc-dither') || {}).value) || 0)))
    }),
    // 指定した色・階調表現で変換した画像と、実際に使われた色の名前
    render: (indices, ditherPct) => {
      const original = $('cc-original');
      if (!original || !original.width) return null;
      const entries = indices.map((i) => ALL_COLORS[i]).filter(Boolean);
      if (!entries.length) return null;
      const factor = Math.min(1, Math.max(0, (Number(ditherPct) || 0) / 100));
      const { imageData, usedEntries } = getReducedImageData(original, original.width, original.height, factor, entries, { lut: carpetLut(entries) });
      const cv = document.createElement('canvas');
      cv.width = original.width;
      cv.height = original.height;
      cv.getContext('2d').putImageData(imageData, 0, 0);
      return { canvas: cv, used: usedEntries.map((c) => c.name), names: entries.map((c) => c.name) };
    },
    // 実寸（1px = 1mm・上下左右5mm）のPSD（変換画像と割付のレイヤー）を、指定した色・階調表現で作る
    psd: async (indices, ditherPct, progress) => {
      if (!state.loadedImg) throw new Error('画像がありません。');
      const entries = indices.map((i) => ALL_COLORS[i]).filter(Boolean);
      if (!entries.length) throw new Error('色がありません。');
      const sizeW = Math.max(1, Math.round(parseFloat($('cc-width').value) || 1000));
      const sizeH = Math.max(1, Math.round(parseFloat($('cc-height').value) || 1000));
      const imageW = sizeW + CARPET_BLEED * 2, imageH = sizeH + CARPET_BLEED * 2;
      const factor = Math.min(1, Math.max(0, (Number(ditherPct) || 0) / 100));
      const off = document.createElement('canvas');
      off.width = imageW;
      off.height = imageH;
      const octx = off.getContext('2d', { willReadFrequently: true });
      if (!octx) throw new Error('画像を用意できませんでした（大きすぎる可能性があります）。');
      octx.imageSmoothingEnabled = true;
      octx.imageSmoothingQuality = 'high';
      drawImageCover(octx, state.loadedImg, imageW, imageH);
      const data = octx.getImageData(0, 0, imageW, imageH).data;
      off.width = 1; off.height = 1;
      const res = await makeCarpetPsd({ rgba: data.buffer, width: imageW, height: imageH, palette: entries.map((e) => e.rgb), dither: factor, lut: carpetLut(entries),
        info: null, bleed: CARPET_BLEED, names: { cad: '①CAD画像（図面）', room: '②部屋', img: '③変換画像（減色・実寸 ' + imageW + '×' + imageH + 'mm＝' + sizeW + '×' + sizeH + 'mm＋上下左右' + CARPET_BLEED + 'mm・階調表現 ' + Math.round(factor * 100) + '%）', grid: '④割付（50cm角・端で切るタイルは薄い赤・センター印）' } },
        progress || (() => {}));
      return { blob: new Blob(res.parts, { type: 'image/vnd.adobe.photoshop' }), width: imageW, height: imageH, psb: Math.max(imageW, imageH) > 30000 };
    }
  };

  async function downloadPsd() {
    if (!state.loadedImg) {
      alert('先に画像を選択してください。');
      return;
    }
    const button = $('cc-download-psd');
    const buttonLabel = button.textContent;
    button.disabled = true;
    button.textContent = 'PSDを作成中…';
    try {
      // 指定サイズ（CADの部屋から算出したサイズも同じ）の上下左右に 5mm ずつ足した大きさ
      const sizeW = Math.max(1, Math.round(parseFloat($('cc-width').value) || 1000));
      const sizeH = Math.max(1, Math.round(parseFloat($('cc-height').value) || 1000));
      const imageW = sizeW + CARPET_BLEED * 2, imageH = sizeH + CARPET_BLEED * 2;
      const ditherFactor = Math.min(1, Math.max(0, (parseFloat(($('cc-dither') || {}).value) || 0) / 100));
      const activeEntries = getActivePaletteEntries();
      // 元画像を実寸（1px=1mm）に描いて、その画素を渡す（プレビューの縮小画像は使わない）
      const off = document.createElement('canvas');
      off.width = imageW;
      off.height = imageH;
      const octx = off.getContext('2d', { willReadFrequently: true });
      if (!octx) throw new Error('画像を用意できませんでした（大きすぎる可能性があります）。');
      octx.imageSmoothingEnabled = true;
      octx.imageSmoothingQuality = 'high';
      drawImageCover(octx, state.loadedImg, imageW, imageH); // 画面と同じく、縦横比を変えずにいっぱいまで引き伸ばす
      const data = octx.getImageData(0, 0, imageW, imageH).data;
      off.width = 1; off.height = 1; // メモリを空ける
      let opaque = false;
      for (let i = 3; i < data.length; i += 4096) { if (data[i]) { opaque = true; break; } }
      if (!opaque) throw new Error('画像を実寸に描けませんでした（ブラウザのメモリ不足の可能性があります）。カーペットのサイズを確かめて、もう一度お試しください。');
      // CAD表示で部屋を選んでいれば、その部屋のカーペット割付（図面・部屋の形・50cm角の割付）もレイヤーに入れる
      const cadEl = document.querySelector('.cad-floor-plan-widget');
      let info = null;
      try { info = cadEl ? (cadEl.cfpWidget ? await cadEl.cfpWidget.carpetPsdInfo(sizeW, sizeH, CARPET_BLEED) : null) : null; } catch (e) { info = null; }
      const res = await makeCarpetPsd({ rgba: data.buffer, width: imageW, height: imageH, palette: activeEntries.map((e) => e.rgb), dither: ditherFactor, lut: carpetLut(activeEntries),
        info: info, bleed: CARPET_BLEED, names: { cad: '①CAD画像（図面）', room: '②部屋' + (info ? '（' + info.name + '）' : ''), img: '③変換画像（減色・実寸 ' + imageW + '×' + imageH + 'mm＝' + sizeW + '×' + sizeH + 'mm＋上下左右' + CARPET_BLEED + 'mm' + (carpetImageScale() !== 1 ? '・画像の大きさ ' + Math.round(carpetImageScale() * 100) + '%' + (carpetImageScale() < 1 ? '・余白は透明（色なし）' : '') : '') + '）', grid: '④割付（50cm角・端で切るタイルは薄い赤・センター印）' } },
        (v) => { button.textContent = 'PSDを作成中… ' + Math.round(v * 100) + '%'; });
      const used = res.used.map((i) => activeEntries[i]);
      state.lastUsedColorEntries = used;
      renderUsedColorsUI(used);
      const blob = new Blob(res.parts, { type: 'image/vnd.adobe.photoshop' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'carpet_4layers_25.4dpi_dither' + Math.round(ditherFactor * 100) + 'pct_' + Date.now() + (Math.max(imageW, imageH) > 30000 ? '.psb' : '.psd');
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    } catch (error) {
      alert('PSDファイルの生成中にエラーが発生しました。\n' + error.message);
    } finally {
      button.disabled = false;
      button.textContent = buttonLabel;
    }
  }

  // =====================================================================
  // 床デザイン画像の保存（PNG・①カーペット用の減色画像をそのまま保存するだけの簡易版）
  // =====================================================================
  // 実寸（1px = 1mm）の変換画像を PNG で保存（画面のプレビューの縮小画像ではなく、元画像を実寸にしてから変換したもの）

  // ---------------------------------------------------------------------------
  // カーペットの SVG（実寸 mm・Inkscape のレイヤー付き）：①CAD画像 ②部屋 ③変換画像 ④割付（50cm角・端で切るタイル・センター）
  // ③は変換画像（実寸 1px = 1mm）を色ごとに画素の境目でなぞったベクター（パレットの色ごとのグループ・色の名前付き）。
  // 点が細かすぎる（境目が多すぎる）ときは、③を画像（PNG）で入れる。
  // ---------------------------------------------------------------------------
  const SVG_MAX_EDGES = 4000000;
  function traceColors(data, w, h, entries) {
    // 画素 → 色の番号（255 = 余白・色なし）
    const key = new Map(entries.map((e, i) => [(e.rgb[0] << 16) | (e.rgb[1] << 8) | e.rgb[2], i]));
    const L = new Uint8Array(w * h);
    for (let i = 0, j = 0; i < L.length; i++, j += 4) {
      if (data[j + 3] < 128) { L[i] = 255; continue; }
      const v = key.get((data[j] << 16) | (data[j + 1] << 8) | data[j + 2]);
      L[i] = v === undefined ? 255 : v;
    }
    // 境目の数を先に数える（多すぎれば null）
    let edges = 0;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const c = L[y * w + x];
      if (c === 255) continue;
      if (y === 0 ? true : L[(y - 1) * w + x] !== c) edges++;
      if (y === h - 1 ? true : L[(y + 1) * w + x] !== c) edges++;
      if (x === 0 ? true : L[y * w + x - 1] !== c) edges++;
      if (x === w - 1 ? true : L[y * w + x + 1] !== c) edges++;
    }
    if (edges > SVG_MAX_EDGES) return null;
    const W1 = w + 1;
    const out = [];
    for (let c = 0; c < entries.length; c++) {
      // 色 c の境目（色の側を右に見て時計回り）：始点 → 終点
      const from = [], to = [];
      const add = (x1, y1, x2, y2) => { from.push(y1 * W1 + x1); to.push(y2 * W1 + x2); };
      for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
        if (L[y * w + x] !== c) continue;
        if (y === 0 ? true : L[(y - 1) * w + x] !== c) add(x, y, x + 1, y);
        if (x === w - 1 ? true : L[y * w + x + 1] !== c) add(x + 1, y, x + 1, y + 1);
        if (y === h - 1 ? true : L[(y + 1) * w + x] !== c) add(x + 1, y + 1, x, y + 1);
        if (x === 0 ? true : L[y * w + x - 1] !== c) add(x, y + 1, x, y);
      }
      if (!from.length) continue;
      const first = new Map(), second = new Map();
      for (let e = 0; e < from.length; e++) { if (first.has(from[e])) second.set(from[e], e); else first.set(from[e], e); }
      const used = new Uint8Array(from.length);
      const next = (v) => {
        const a = first.get(v);
        if (a !== undefined ? !used[a] : false) return a;
        const b = second.get(v);
        return b !== undefined ? (used[b] ? -1 : b) : -1;
      };
      let d = '';
      for (let e0 = 0; e0 < from.length; e0++) {
        if (used[e0]) continue;
        // 1周なぞり、向きが変わる点だけを残す（横 H・縦 V だけのパス）
        const pts = [];
        let e = e0;
        while (e >= 0) {
          used[e] = 1;
          pts.push(from[e]);
          e = next(to[e]);
        }
        const xy = pts.map((v) => [v % W1, Math.floor(v / W1)]);
        const keep = xy.filter((p, i) => {
          const a = xy[(i + xy.length - 1) % xy.length], b = xy[(i + 1) % xy.length];
          return !((a[0] === p[0] ? p[0] === b[0] : false) || (a[1] === p[1] ? p[1] === b[1] : false));
        });
        if (keep.length < 3) continue;
        d += 'M' + keep[0][0] + ' ' + keep[0][1];
        for (let i = 1; i < keep.length; i++) d += keep[i][0] === keep[i - 1][0] ? 'V' + keep[i][1] : 'H' + keep[i][0];
        d += 'Z';
      }
      out.push({ entry: entries[c], d });
    }
    return out;
  }

  async function downloadCarpetSvg() {
    if (!state.loadedImg) { alert('先に画像を選択してください。'); return; }
    const button = $('cc-download-svg');
    const label = button.textContent;
    button.disabled = true;
    button.textContent = 'SVGを作成中…';
    try {
      const full = await carpetReducedFull((v) => { button.textContent = 'SVGを作成中…（変換画像 ' + Math.round(v * 100) + '%）'; });
      if (!full) throw new Error('変換画像を作れませんでした。');
      const w = full.width, h = full.height, B = full.bleed;
      const esc = (t) => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
      const toUrl = (blob) => new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(new Error('画像を読み込めませんでした')); fr.readAsDataURL(blob); });
      const pngOf = (cv) => new Promise((res) => cv.toBlob(res, 'image/png'));
      const cadEl = document.querySelector('.cad-floor-plan-widget');
      let info = null;
      try { info = cadEl ? (cadEl.cfpWidget ? await cadEl.cfpWidget.carpetPsdInfo(full.sizeW, full.sizeH, B) : null) : null; } catch (e) { info = null; }
      await new Promise((r) => setTimeout(r, 0));
      // ① CAD画像
      let cad = '';
      if (info ? info.cad : false) {
        const c = info.cad, k = Math.min(1, 4000 / Math.max(c.sw, c.sh));
        const cv = document.createElement('canvas');
        cv.width = Math.max(1, Math.round(c.sw * k)); cv.height = Math.max(1, Math.round(c.sh * k));
        const x = cv.getContext('2d');
        x.fillStyle = '#ffffff'; x.fillRect(0, 0, cv.width, cv.height);
        x.imageSmoothingQuality = 'high';
        x.drawImage(c.bitmap, c.sx, c.sy, c.sw, c.sh, 0, 0, cv.width, cv.height);
        const url = await toUrl(await pngOf(cv));
        cad = '<image x="0" y="0" width="' + w + '" height="' + h + '" preserveAspectRatio="none" href="' + url + '" xlink:href="' + url + '"/>\n';
      }
      // ② 部屋
      let room = '';
      if (info ? (info.room ? info.room.length >= 3 : false) : false) {
        room = '<path d="' + info.room.map((q, i) => (i ? 'L' : 'M') + (Math.round(q[0] * 10) / 10) + ' ' + (Math.round(q[1] * 10) / 10)).join(' ') + ' Z" fill="#2563eb" fill-opacity="0.10" stroke="#2563eb" stroke-width="8"/>\n';
      }
      // ③ 変換画像（色ごとのベクター。細かすぎるときは画像）
      button.textContent = 'SVGを作成中…（色ごとの形をなぞっています）';
      await new Promise((r) => setTimeout(r, 30));
      const data = full.canvas.getContext('2d').getImageData(0, 0, w, h).data;
      const entries = getActivePaletteEntries();
      const traced = traceColors(data, w, h, entries);
      let img = '', vector = !!traced;
      const hex = (rgb) => '#' + rgb.map((v) => v.toString(16).padStart(2, '0')).join('');
      if (traced) {
        traced.forEach((t) => {
          img += '<g id="color-' + esc(t.entry.name) + '" inkscape:label="' + esc(t.entry.name) + '"><path d="' + t.d + '" fill="' + hex(t.entry.rgb) + '" fill-rule="nonzero" stroke="none"/></g>\n';
        });
      } else {
        const url = await toUrl(await pngOf(full.canvas));
        img = '<image x="0" y="0" width="' + w + '" height="' + h + '" preserveAspectRatio="none" style="image-rendering:pixelated" href="' + url + '" xlink:href="' + url + '"/>\n';
      }
      // ④ 割付（50cm角・端で切るタイルは薄い赤・外枠・センター）
      const tiles = [];
      if (info ? (info.tiles ? info.tiles.length : false) : false) info.tiles.forEach((t) => tiles.push(t));
      else for (let y = B; y < h - B; y += 500) for (let x = B; x < w - B; x += 500) tiles.push({ x, y, w: Math.min(500, w - B - x), h: Math.min(500, h - B - y), cut: false });
      const r1 = (v) => Math.round(v * 10) / 10;
      let grid = '';
      tiles.forEach((t) => { if (t.cut) grid += '<rect x="' + r1(t.x) + '" y="' + r1(t.y) + '" width="' + r1(t.w) + '" height="' + r1(t.h) + '" fill="#ef4444" fill-opacity="0.14" stroke="none"/>\n'; });
      tiles.forEach((t) => { grid += '<rect x="' + r1(t.x) + '" y="' + r1(t.y) + '" width="' + r1(t.w) + '" height="' + r1(t.h) + '" fill="none" stroke="#ef4444" stroke-width="3"/>\n'; });
      grid += '<rect x="' + (B + 2) + '" y="' + (B + 2) + '" width="' + (w - B * 2 - 4) + '" height="' + (h - B * 2 - 4) + '" fill="none" stroke="#dc2626" stroke-width="8"/>\n';
      const cc = info ? info.center : null;
      const cx = r1(cc ? cc[0] : w / 2), cy = r1(cc ? cc[1] : h / 2);
      const m = Math.min(w, h), arm = r1(Math.min(Math.max(300, m * 0.12), m * 0.15)), rr = r1(arm * 0.45);
      const cross = 'M' + (cx - arm) + ' ' + cy + ' H' + (cx + arm) + ' M' + cx + ' ' + (cy - arm) + ' V' + (cy + arm);
      grid += '<g id="center" inkscape:label="センター"><path d="' + cross + '" fill="none" stroke="#ffffff" stroke-width="14"/><path d="' + cross + '" fill="none" stroke="#dc2626" stroke-width="7"/>'
        + '<circle cx="' + cx + '" cy="' + cy + '" r="' + rr + '" fill="none" stroke="#dc2626" stroke-width="7"/><circle cx="' + cx + '" cy="' + cy + '" r="' + r1(rr * 0.3) + '" fill="#dc2626"/>'
        + '<text x="' + r1(cx + rr * 1.2) + '" y="' + r1(cy - rr * 1.2) + '" font-size="' + Math.round(arm * 0.45) + '" font-weight="bold" font-family="Noto Sans JP, sans-serif" fill="#dc2626" stroke="#ffffff" stroke-width="10" paint-order="stroke">センター</text></g>\n';
      const layer = (id, nm, body) => '<g id="' + id + '" inkscape:groupmode="layer" inkscape:label="' + esc(nm) + '">\n' + body + '</g>\n';
      const imgName = '③変換画像（' + (vector ? '色ごとのベクター' : '画像') + '・実寸 ' + w + '×' + h + 'mm＝' + full.sizeW + '×' + full.sizeH + 'mm＋上下左右' + B + 'mm）';
      const svg = '<?xml version="1.0" encoding="UTF-8"?>\n'
        + '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="' + w + 'mm" height="' + h + 'mm" viewBox="0 0 ' + w + ' ' + h + '">\n'
        + '<title>' + esc('カーペット ' + full.sizeW + '×' + full.sizeH + 'mm') + '</title>\n'
        + layer('layer1', '①CAD画像（図面）', cad) + layer('layer2', '②部屋' + (info ? '（' + info.name + '）' : ''), room)
        + layer('layer3', imgName, img) + layer('layer4', '④割付（50cm角・端で切るタイルは薄い赤・センター）', grid)
        + '</svg>\n';
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
      a.download = 'carpet_' + full.sizeW + 'x' + full.sizeH + 'mm_' + Date.now() + '.svg';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      setStatus('ok', '✅ カーペットの SVG を保存しました（実寸 ' + w + '×' + h + 'mm・4レイヤー）。' + (vector ? '変換画像は色ごとのベクター（' + traced.length + '色）です。' : '変換画像は点が細かすぎるため、画像（PNG）で入れました（階調表現を下げるとベクターになります）。'));
    } catch (err) {
      alert('SVGを作成できませんでした: ' + err.message);
    } finally {
      button.disabled = false;
      button.textContent = label;
    }
  }

  async function downloadFloorImagePng() {
    const canvas = $('cc-reduced');
    if (!canvas || !canvas.width || !state.loadedImg) {
      alert('先に「① カーペット用デザイン」で画像を処理してください。');
      return;
    }
    let full = null;
    try { full = await carpetReducedFull(); } catch (e) { full = null; }
    const src = full ? full.canvas : canvas;
    const blob = await new Promise((res) => src.toBlob(res, 'image/png'));
    if (!blob) { alert('画像を保存できませんでした（大きすぎる可能性があります）。'); return; }
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'floor_design_' + (full ? full.width + 'x' + full.height + 'mm_' : '') + Date.now() + '.png';
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 60000);
  }

  // =====================================================================
  // 壁紙デザイン画像の保存（PSD・2レイヤー：①デザイン層 ＋ ②裁断ガイド層）
  // ガイド層は赤色の線で、
  //   ・横方向：910mm間隔の縦線（壁紙ロール幅の目安）
  //   ・縦方向：「お部屋パース」の壁の高さ位置に横線（その下が+200mmの裁断代）
  // を描画する。実寸(1px=1mm)で書き出すため、画像サイズは
  //   幅 = お部屋パースの「お部屋の幅」(mm)
  //   高さ = お部屋パースの「壁の高さ」(mm) + 200mm（裁断代）
  // を使用する。
  // =====================================================================
  // 壁紙の印刷・保存の寸法（mm）：壁の上下に100mmずつの裁断代。
  // 巾（PITCH：仕上がりの幅＝1巾が受け持つ壁の幅、初期900mm）の左右に合わせ代（MARGIN：片側、初期10mm）を足した幅で
  // 1巾を作る（ROLL＝900＋10＋10＝920mm。910mm なら 910＋7.5＋7.5＝925mm）。隣の巾とは合わせ代2つ分（OVERLAP＝20mm）重なり、重なりの真ん中がカット線
  // （巾の端から合わせ代＝EDGE）。SIDE：貼り始め（スタート側）の端の余白（壁の端から最初の巾の端まで。10〜100mm・5mm刻み）
  const WALL_PRINT = { PITCH: 900, MARGIN: 10, TRIM_TOP: 100, TRIM_BOTTOM: 100, SIDE: 10 };
  WALL_PRINT.ROLL = WALL_PRINT.PITCH + WALL_PRINT.MARGIN * 2; // 1巾の幅（合わせ代込み。925mm）
  WALL_PRINT.OVERLAP = WALL_PRINT.MARGIN * 2;                  // 隣の巾と重なる幅（15mm）
  WALL_PRINT.EDGE = WALL_PRINT.MARGIN;                         // カット線の外側の余白（合わせ代）
  WALL_PRINT.STEP = WALL_PRINT.PITCH;                          // 1巾が受け持つ壁の幅（カット線からカット線まで。910mm）
  // 巾（仕上がりの幅）は画面では 910mm / 900mm から選ぶ（合わせ代は 7.5mm / 10mm に自動。範囲としては850〜930mm）、合わせ代（片側）は6〜15mmを0.5mm刻み、上下の余白（裁断代）は30〜100mmを5mm刻みで調整できる
  // 巾の数：スタート側の余白＋壁の幅を覆い、反対側にも（合わせ代−5mm）以上の余白が残る数
  WALL_PRINT.count = function (W) { return Math.max(1, Math.ceil((this.SIDE + W - 5) / this.STEP)); };
  // 壁の左端の位置（絵の左端から mm）：左寄せスタートはスタート側の余白、右寄せスタートは右端から余白をとった位置
  WALL_PRINT.startX = function (W, FW, right) { return right ? FW - this.SIDE - W : this.SIDE; };
  // 枠を横に動かした量 fx（mm）も入れた巾の並び：巾は STEP ごとに並び、壁にかからなくなった巾は除き、
  // 足りなくなった側（壁の端から合わせ代−5mm以上の余白が要る）に巾を足す。
  // 返り値：N（巾の数）、FW（絵の幅＝最初の巾の左端から最後の巾の右端まで）、ox（絵の中での壁の左端）
  WALL_PRINT.frames = function (W, right, fx) {
    const P = this, m = Math.max(0, P.MARGIN - 5), o = fx || 0;
    const s0 = right ? W + P.SIDE + o - P.ROLL : o - P.SIDE; // 貼り始めの巾の左端（壁の左端から）
    const kmin = Math.floor((-m - s0) / P.STEP + 1e-9);
    const kmax = Math.max(kmin, Math.ceil((W + m - P.ROLL - s0) / P.STEP - 1e-9));
    const N = kmax - kmin + 1;
    return { N, FW: Math.round(N * P.STEP + P.OVERLAP), ox: -(s0 + kmin * P.STEP) };
  };
  WALL_PRINT.set = function (roll, overlap, trim, side) {
    if (side !== undefined) this.SIDE = Math.min(100, Math.max(10, Math.round((parseFloat(side) || 10) / 5) * 5));
    const r = Math.min(930, Math.max(850, Math.round(parseFloat(roll)) || 900));
    const o = Math.min(15, Math.max(6, Math.round((parseFloat(overlap) || 10) * 2) / 2));
    // r：巾（仕上がりの幅）、o：合わせ代（片側）→ 1巾の幅は r + o × 2
    this.PITCH = r;
    this.MARGIN = o;
    this.ROLL = r + o * 2;
    this.OVERLAP = o * 2;
    this.EDGE = o;
    this.STEP = r;
    if (trim !== undefined) {
      const tv = Math.min(100, Math.max(30, Math.round((parseFloat(trim) || 100) / 5) * 5));
      this.TRIM_TOP = tv;
      this.TRIM_BOTTOM = tv;
    }
  };
  window.cfpWallPrint = WALL_PRINT;

  // 壁の左上が (ox, oy) にある壁（wallW × wallH、1px=1mm）として、貼り方どおりにデザインを描く。
  // 壁の外（裁断代・重なり）にも、柄・画像の続きを描く（1枚の画像の外は白）
  // k: 1mm を何pxで描くか（省略時 1。画面表示用に小さく描くとき 1 未満）
  // sceneW / sceneH: 絵全体の大きさ（mm）。タイルに分けて描くとき（ctx がずらしてある）に渡す
  // sc: 画像の大きさ（壁の中心を基準に拡大縮小。1 = 100%）
  function drawWallDesign(ctx, source, ox, oy, wallW, wallH, k, sceneW, sceneH, sc) {
    k = k || 1;
    if (!sceneW) ctx.setTransform(k, 0, 0, k, 0, 0);
    const sw = source.naturalWidth || source.width, sh = source.naturalHeight || source.height;
    const r = getWallRepeat();
    const cw = sceneW || ctx.canvas.width / k, chh = sceneH || ctx.canvas.height / k;
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, cw, chh);
    ctx.imageSmoothingQuality = 'high';
    // 拡大縮小：見えている範囲（0..cw, 0..chh）を、拡大縮小前の座標に直して柄を敷く範囲にする
    let xa = 0, xb = cw, ya = 0, yb = chh;
    if (sc ? r.on : false) {
      if (sc !== 1) {
        const cx = ox + wallW / 2, cy = oy + wallH / 2;
        ctx.translate(cx, cy); ctx.scale(sc, sc); ctx.translate(-cx, -cy);
        xa = cx - cx / sc; xb = cx + (cw - cx) / sc; ya = cy - cy / sc; yb = cy + (chh - cy) / sc;
      }
    }
    if (r.on) {
      const tw = Math.max(1, Math.round(r.mm)), th = Math.max(1, Math.round(r.mm * sh / sw));
      const tile = document.createElement('canvas');
      tile.width = tw;
      tile.height = th;
      tile.getContext('2d').drawImage(source, 0, 0, tw, th);
      // 柄の区切りを壁の左端・天井に合わせる
      const x0 = ox - Math.ceil((ox - xa) / tw) * tw, y0 = oy - Math.ceil((oy - ya) / th) * th;
      for (let y = y0; y <= yb; y += th) {
        for (let x = x0; x <= xb; x += tw) ctx.drawImage(tile, x, y);
      }
      return;
    }
    if (r.mode === 'wrap') {
      const b = wrapBand(sw / sh);
      const k = wallW / b.W;
      ctx.drawImage(source, ox + (b.s0 - b.D) * k, oy + (wallH - b.ih * k) / 2, b.iw * k, b.ih * k);
      return;
    }
    const iw = singleImageWidthMm(sw / sh);
    const ih = iw * sh / sw;
    ctx.drawImage(source, ox + (wallW - iw) / 2, oy + (wallH - ih) / 2, iw, ih);
  }

  // 壁のデザインを切り分けず1枚に（左右の余白・上下100mmの裁断代を含む）、3レイヤーのCMYK PSDにする。
  //   ①CAD図面（展開図の壁の範囲）／②壁紙の画像（切り分けなし）／③巾の枠（赤・各巾の幅×高さ）
  // cad: 展開図から切り出した壁の絵（壁の範囲の大きさ、1枚のcanvas）。無ければ空のレイヤー
  WALL_PRINT.getSource = function () {
    const c = getWallSource();
    return c ? ((c.naturalWidth || c.width) ? c : null) : null;
  };
  WALL_PRINT.renderDesign = function (canvas, ox, oy, wallW, wallH, k, sc) {
    const src = WALL_PRINT.getSource();
    if (src) drawWallDesign(canvas.getContext('2d'), src, ox, oy, wallW, wallH, k, 0, 0, sc || 1);
    else {
      const x = canvas.getContext('2d');
      x.fillStyle = '#ffffff';
      x.fillRect(0, 0, canvas.width, canvas.height);
    }
    return !!src;
  };
  // 巾の枠の線：各巾の枠（赤・オレンジ交互）、壁の範囲（紫の実線）、合わせ代の半分の位置のカット線（紫、壁の範囲の上下の線とつなぐ）
  // right: true = 右の端から巾を並べる（右寄せスタート）、false = 左の端から（左寄せスタート）
  // 多角形（変形した壁）と縦線 x の交わり：線が壁の中にある区間 [[y0, y1], ...]
  WALL_PRINT.cutSegments = function (poly, x) {
    const ys = [];
    for (let i = 0; i !== poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length];
      if ((a[0] <= x) !== (b[0] <= x)) ys.push(a[1] + (x - a[0]) * (b[1] - a[1]) / (b[0] - a[0]));
    }
    ys.sort((m, n) => m - n);
    const out = [];
    for (let i = 0; i + 1 < ys.length; i += 2) out.push([ys[i], ys[i + 1]]);
    return out;
  };
  // shapes: 壁の形（絵の座標、mm）の配列。壁をつなげたときは複数。無ければ四角1つ
  WALL_PRINT.drawFrames = function (fx, W, WH, N, FW, H, right, shapes, fo) {
    const P = WALL_PRINT;
    fo = fo || { x: 0, y: 0 }; // 枠を動かした量（mm）
    const ox = P.startX(W, FW, right);
    if (!shapes || !shapes.length) shapes = [[[ox, P.TRIM_TOP], [ox + W, P.TRIM_TOP], [ox + W, P.TRIM_TOP + WH], [ox, P.TRIM_TOP + WH]]];
    for (let i = 0; i !== N; i++) {
      const x = (right ? N - 1 - i : i) * P.STEP; // 横の位置は巾の並び（frames）に入っている
      fx.strokeStyle = i % 2 ? '#ff7a00' : '#ff0000';
      fx.lineWidth = 3;
      fx.strokeRect(x + 1.5, fo.y + 1.5 + (i % 2) * 4, P.ROLL - 3, H - 3 - (i % 2) * 8);
    }
    fx.strokeStyle = '#d000d0';
    fx.lineWidth = 2;
    shapes.forEach((pts) => {
      fx.beginPath();
      pts.forEach((q, i) => { if (i === 0) fx.moveTo(q[0], q[1]); else fx.lineTo(q[0], q[1]); });
      fx.closePath();
      fx.stroke();
    });
    // カット線：隣り合う巾の重なりの真ん中。壁の中にある部分だけ
    for (let i = 1; i !== N; i++) {
      const cx = i * P.STEP + P.EDGE;
      shapes.forEach((pts) => P.cutSegments(pts, cx).forEach((sg) => {
        fx.beginPath();
        fx.moveTo(cx, sg[0]);
        fx.lineTo(cx, sg[1]);
        fx.stroke();
      }));
    }
  };
  // ---- Illustrator 用（.ai）の保存 ----
  // 中身は PDF 互換の .ai（Illustrator で開ける形式）。レイヤー（PDF のオプションコンテンツ）は
  // ①CAD図面（画像・RGB JPEG）②壁紙の画像（CMYK・可逆圧縮）③巾の枠（ベクトル線・CMYK）の3つ。1mm = 72/25.4 pt の実寸。
  // 幅が約5m（PDF の1ページの上限 200インチ）を超えるときは、UserUnit（単位の倍率）を使って実寸を保つ。
  // layers: [{ name, kind: 'jpeg' | 'cmyk' | 'vector', draw(ctx) }]（下から順。ctx は絵の座標・1px = 1mm）
  async function writeAiPdf(width, height, layers, onProgress) {
    const MM = 72 / 25.4;
    const u = Math.max(1, Math.ceil(Math.max(width, height) * MM / 14000));
    const k = MM / u; // PDF の単位 / mm
    const Wp = width * k, Hp = height * k;
    const enc = new TextEncoder();
    const n3 = (v) => String(Math.round(v * 1000) / 1000);
    const utf16 = (t) => { let h = 'FEFF'; for (let i = 0; i !== t.length; i++) h += t.charCodeAt(i).toString(16).toUpperCase().padStart(4, '0'); return '<' + h + '>'; };
    // 色：PSD と同じ単純な RGB → CMYK
    const cmyk = (r, g, b) => {
      const mx = Math.max(r, g, b);
      if (mx === 0) return [0, 0, 0, 1];
      return [(mx - r) / mx, (mx - g) / mx, (mx - b) / mx, 1 - mx / 255];
    };
    const hexCmyk = (hex) => { const v = parseInt(String(hex).replace('#', ''), 16) || 0; return cmyk(Math.floor(v / 65536), Math.floor(v / 256) % 256, v % 256).map((x) => n3(x)).join(' '); };
    const objs = []; // [{ id, parts }]
    let nextId = 1;
    const alloc = () => nextId++;
    const put = (id, parts) => objs.push({ id, parts });
    const TW = 4096;
    const tiles = [];
    for (let x0 = 0; x0 < width; x0 += TW) tiles.push({ x0, w: Math.min(TW, width - x0) });
    const tile = document.createElement('canvas');
    const tctx = () => tile.getContext('2d', { willReadFrequently: true });
    const content = [];
    const xobj = [], props = [], ocgs = [];
    const rasterSteps = layers.filter((L) => L.kind !== 'vector').length * tiles.length;
    let step = 0;
    const deflate = typeof CompressionStream === 'function';
    for (let li = 0; li !== layers.length; li++) {
      const L = layers[li];
      const ocg = alloc();
      put(ocg, ['<< /Type /OCG /Name ' + utf16(L.name) + ' >>']);
      ocgs.push(ocg);
      props.push('/L' + li + ' ' + ocg + ' 0 R');
      content.push('/OC /L' + li + ' BDC\n');
      if (L.kind === 'vector') {
        // 線を記録する ctx（canvas と同じ呼び方で、PDF の線にする）
        const ops = [];
        const rec = {
          strokeStyle: '#000000', lineWidth: 1, tx: 0, ty: 0, path: [],
          translate(x, y) { this.tx += x; this.ty += y; },
          save() {}, restore() {}, setTransform() {},
          X(x) { return n3((x + this.tx) * k); }, Y(y) { return n3(Hp - (y + this.ty) * k); },
          // 分けたファイルでは、このファイルの範囲（横 0〜width）に入らない線は書かない（アートボードの外に線を残さない）
          lo: Infinity, hi: -Infinity,
          see(x) { const v = x + this.tx; if (v < this.lo) this.lo = v; if (v > this.hi) this.hi = v; },
          inside() { return this.hi >= -1 ? this.lo <= width + 1 : false; },
          beginPath() { this.path = []; this.lo = Infinity; this.hi = -Infinity; },
          moveTo(x, y) { this.see(x); this.path.push(this.X(x) + ' ' + this.Y(y) + ' m'); },
          lineTo(x, y) { this.see(x); this.path.push(this.X(x) + ' ' + this.Y(y) + ' l'); },
          closePath() { this.path.push('h'); },
          style() { return hexCmyk(this.strokeStyle) + ' K ' + n3(this.lineWidth * k) + ' w\n'; },
          stroke() { if (this.path.length ? this.inside() : false) ops.push(this.style() + this.path.join(' ') + ' S\n'); },
          strokeRect(x, y, w, h) {
            this.lo = Infinity; this.hi = -Infinity; this.see(x); this.see(x + w);
            if (!this.inside()) return;
            ops.push(this.style() + this.X(x) + ' ' + this.Y(y + h) + ' ' + n3(w * k) + ' ' + n3(h * k) + ' re S\n');
          }
        };
        L.draw(rec);
        // 壁の範囲の線がファイルの端をまたぐときは、ファイルの範囲で切り抜く
        content.push('q 0 0 ' + n3(Wp) + ' ' + n3(Hp) + ' re W n 0 J 0 j\n' + ops.join('') + 'Q\n');
      } else {
        for (const t of tiles) {
          tile.width = t.w; tile.height = height;
          const x = tctx();
          x.setTransform(1, 0, 0, 1, 0, 0);
          x.fillStyle = '#ffffff';
          x.fillRect(0, 0, t.w, height); // 透明なところは白（CAD の下地・画像の外）
          x.save(); x.translate(-t.x0, 0); L.draw(x); x.restore();
          const id = alloc(), nm = '/Im' + id;
          if (L.kind === 'jpeg') {
            const blob = await new Promise((res) => tile.toBlob(res, 'image/jpeg', 0.92));
            if (!blob) throw new Error('画像を用意できませんでした');
            put(id, ['<< /Type /XObject /Subtype /Image /Width ' + t.w + ' /Height ' + height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + blob.size + ' >>\nstream\n', blob, '\nendstream']);
          } else {
            // CMYK（0 = インクなし）。256行ずつ変換して、そのまま圧縮する
            const chunks = [];
            let writer = null, done = null;
            if (deflate) {
              const cs = new CompressionStream('deflate');
              writer = cs.writable.getWriter();
              done = new Response(cs.readable).blob();
            }
            for (let y0 = 0; y0 < height; y0 += 256) {
              const bh = Math.min(256, height - y0);
              const d = x.getImageData(0, y0, t.w, bh).data;
              const out = new Uint8Array(t.w * bh * 4);
              let last = -1, c0 = 0, c1 = 0, c2 = 0, c3 = 0;
              for (let i = 0; i !== d.length; i += 4) {
                const rr = d[i], gg = d[i + 1], bb = d[i + 2];
                const key = rr * 65536 + gg * 256 + bb;
                if (key !== last) {
                  last = key;
                  const mx = Math.max(rr, gg, bb);
                  if (mx === 0) { c0 = 0; c1 = 0; c2 = 0; c3 = 255; }
                  else { c0 = Math.round((mx - rr) * 255 / mx); c1 = Math.round((mx - gg) * 255 / mx); c2 = Math.round((mx - bb) * 255 / mx); c3 = 255 - mx; }
                }
                out[i] = c0; out[i + 1] = c1; out[i + 2] = c2; out[i + 3] = c3;
              }
              if (writer) await writer.write(out); else chunks.push(out);
              await new Promise((res) => setTimeout(res, 0)); // 画面に処理を返す
            }
            let data;
            if (writer) { await writer.close(); data = await done; } else data = new Blob(chunks);
            put(id, ['<< /Type /XObject /Subtype /Image /Width ' + t.w + ' /Height ' + height + ' /ColorSpace /DeviceCMYK /BitsPerComponent 8' + (writer ? ' /Filter /FlateDecode' : '') + ' /Length ' + data.size + ' >>\nstream\n', data, '\nendstream']);
          }
          xobj.push(nm + ' ' + id + ' 0 R');
          content.push('q ' + n3(t.w * k) + ' 0 0 ' + n3(height * k) + ' ' + n3(t.x0 * k) + ' 0 cm ' + nm + ' Do Q\n');
          step++;
          if (onProgress) onProgress(step / Math.max(1, rasterSteps));
          await new Promise((res) => setTimeout(res, 0));
        }
      }
      content.push('EMC\n');
    }
    tile.width = tile.height = 1;
    const contentId = alloc(), pageId = alloc(), pagesId = alloc(), catalogId = alloc(), infoId = alloc();
    const cbytes = enc.encode(content.join(''));
    put(contentId, ['<< /Length ' + cbytes.length + ' >>\nstream\n', cbytes, '\nendstream']);
    put(pageId, ['<< /Type /Page /Parent ' + pagesId + ' 0 R /MediaBox [0 0 ' + n3(Wp) + ' ' + n3(Hp) + ']' + (u > 1 ? ' /UserUnit ' + u : '')
      + ' /Resources << /XObject << ' + xobj.join(' ') + ' >> /Properties << ' + props.join(' ') + ' >> >> /Contents ' + contentId + ' 0 R >>']);
    put(pagesId, ['<< /Type /Pages /Kids [' + pageId + ' 0 R] /Count 1 >>']);
    const refs = ocgs.map((o) => o + ' 0 R').join(' ');
    put(catalogId, ['<< /Type /Catalog /Pages ' + pagesId + ' 0 R /OCProperties << /OCGs [' + refs + '] /D << /Order [' + refs + '] /ON [' + refs + '] >> >> >>']);
    put(infoId, ['<< /Producer (cad-floor-plan wallpaper) /Title ' + utf16('壁紙データ（巾の枠）' + width + '×' + height + 'mm') + ' >>']);
    // ファイル：見出し・オブジェクト・相互参照表
    const parts = [];
    let pos = 0;
    const add = (p) => { const b = typeof p === 'string' ? enc.encode(p) : p; parts.push(b); pos += b instanceof Blob ? b.size : b.length; };
    add('%PDF-1.6\n');
    add(Uint8Array.of(37, 226, 227, 207, 211, 10));
    const offs = {};
    objs.sort((a, b) => a.id - b.id).forEach((o) => { offs[o.id] = pos; add(o.id + ' 0 obj\n'); o.parts.forEach(add); add('\nendobj\n'); });
    const xref = pos;
    let xr = 'xref\n0 ' + nextId + '\n0000000000 65535 f \n';
    for (let i = 1; i !== nextId; i++) xr += String(offs[i]).padStart(10, '0') + ' 00000 n \n';
    add(xr + 'trailer\n<< /Size ' + nextId + ' /Root ' + catalogId + ' 0 R /Info ' + infoId + ' 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
    return new Blob(parts, { type: 'application/postscript' });
  }

  // ---- Illustrator 用（.ai）の確認用シート（参考データと同じ形式）----
  // 縮尺 1/10 の1枚のシートに、上：全体図（画像・巾の枠・壁の範囲・寸法）、下：分割図（巾ごとに離して並べた画像・寸法）、
  // どちらも巾ごとにトンボと「N_【案件名】」「天↑地」。いちばん下：ピッチの見本と仕様。
  // レイヤーは「グラフィック」（画像）「分割」（巾の枠・トンボ・名前）「壁面ライン」「寸法」「仕様」（下から）。
  // 中身は PDF 互換の .ai。画像は CMYK（実寸 1px=1mm の画像をシートに 1/10 で配置。分割図は同じ画像を巾ごとに切り抜いて再利用）。
  // o: { W, WH, right, shapes, walls: [{ W, WH, no }], off, name, onProgress }
  // AI の文字に埋め込むフォント（Noto Sans JP Regular・SIL Open Font License。Mac・Windows どちらでも同じ見た目）。
  // 読み込めないときは null（文字はフォントを埋め込まずに書く）
  const SHEET_FONT_JS = '{{CFP_ASSET_URL}}js/pdf-font.js?ver={{CFP_VERSION}}';
  const SHEET_FONT_URL = '{{CFP_ASSET_URL}}fonts/NotoSansJP-Regular.ttf?ver={{CFP_VERSION}}';
  function loadSheetFont() {
    const ready = () => (window.CFPPdfFont ? window.CFPPdfFont.load(SHEET_FONT_URL) : Promise.reject(new Error('フォントの部品がありません')));
    if (window.CFPPdfFont) return ready().catch(() => null);
    return new Promise((resolve) => {
      const sc = document.createElement('script');
      sc.src = SHEET_FONT_JS;
      sc.onload = () => ready().then(resolve, () => resolve(null));
      sc.onerror = () => resolve(null);
      document.head.appendChild(sc);
    });
  }

  WALL_PRINT.buildAiSheet = async function (o) {
    const P = WALL_PRINT;
    const font = await loadSheetFont();
    if (o.onFont) o.onFont(font);
    const off = o.off || { img: { x: 0, y: 0 }, frame: { x: 0, y: 0 } };
    const W = o.W, WH = o.WH, right = !!o.right;
    const H = WH + P.TRIM_TOP + P.TRIM_BOTTOM;
    const fr = P.frames(W, right, off.frame ? off.frame.x : 0);
    const N = fr.N, FW = fr.FW, ox = fr.ox;
    const name = (o.name || '').trim() || '物件名';
    const src = P.getSource();
    const SC = 0.1;                 // 縮尺 1/10（シートの mm ＝ 実寸 mm × 0.1）
    const GAP = 80;                 // 分割図の巾と巾のすき間（実寸 mm）
    const MM = 72 / 25.4;
    const PTM = 25.4 / 72;          // 1pt（シートの mm）
    const f1 = (v) => String(Math.round(v * 10) / 10);
    const multi = (o.walls || []).length > 1;
    // ---- シートの配置（シートの mm、左上が原点・下向き）。見本と同じ間隔 ----
    // 分割図：貼り始めの巾は全体図と同じ位置、そこから巾ごとに（すき間＋合わせ代の分）ずらして離す
    const D = P.ROLL + GAP - P.STEP;
    const anchor = right ? N - 1 : 0;
    const splitR = (i) => i * P.STEP + (i - anchor) * D;             // 分割図の i 番目（左から）の巾の左端（実寸、全体図の絵の座標）
    const minR = Math.min(0, splitR(0)), maxR = Math.max(FW, splitR(N - 1) + P.ROLL);
    const LM = 40, TOPM = (multi ? 58 : 43) + 8;
    const s1x = LM - minR * SC, s1y = TOPM;                        // 全体図の左上
    const s1w = FW * SC, s1h = H * SC;
    const s2y = s1y + s1h + 78;                                      // 分割図の上端（見本：全体図の下から 78mm）
    const s2h = H * SC;
    const specY = s2y + s2h + 76;                                    // 見本（ピッチ）の枠の上端
    const pageW = Math.max(s1x + maxR * SC, s1x + 260) + 25;
    const pageH = specY + 30 + 45;
    const u = Math.max(1, Math.ceil(Math.max(pageW, pageH) * MM / 14000));
    const kk = MM / u;               // PDF の単位 / シートの mm
    const Hp = pageH * kk;
    const n3 = (v) => String(Math.round(v * 1000) / 1000);
    const X = (x) => n3(x * kk), Y = (y) => n3(Hp - y * kk);
    const enc = new TextEncoder();
    const utf16 = (t) => { let h = ''; for (let i = 0; i !== t.length; i++) h += t.charCodeAt(i).toString(16).toUpperCase().padStart(4, '0'); return h; };
    const objs = []; let nextId = 1;
    const alloc = () => nextId++;
    const put = (id, parts) => objs.push({ id, parts });
    // o.svg：同じ内容を SVG（Inkscape のレイヤー付き・シートの mm 単位）で作る
    const SVG = !!o.svg;
    let picUrl = '';
    if (SVG) {
      // 全体の絵を1枚の PNG（実寸 1px = 1mm）にして埋め込み、全体図・分割図で使い回す
      const c = document.createElement('canvas');
      c.width = FW; c.height = H;
      const x = c.getContext('2d');
      x.fillStyle = '#ffffff'; x.fillRect(0, 0, FW, H);
      if (src) drawWallDesign(x, src, ox + off.img.x, P.TRIM_TOP + off.img.y, W, WH, 1, FW, H, off.scale || 1);
      const pb = await new Promise((res) => c.toBlob(res, 'image/png'));
      c.width = c.height = 1;
      if (!pb) throw new Error('画像を用意できませんでした（大きすぎる可能性があります）。');
      picUrl = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(new Error('画像を読み込めませんでした')); fr.readAsDataURL(pb); });
      if (o.onProgress) o.onProgress(0.9);
    }
    // ---- 画像（全体の絵）を CMYK のタイルにする ----
    const TW = 4096, tiles = [];
    const tile = document.createElement('canvas');
    const xobj = [];
    const deflate = typeof CompressionStream === 'function';
    let step = 0;
    const total = Math.ceil(FW / TW);
    for (let x0 = 0; x0 < (SVG ? 0 : FW); x0 += TW) {
      const tw = Math.min(TW, FW - x0);
      tile.width = tw; tile.height = H;
      const x = tile.getContext('2d', { willReadFrequently: true });
      x.fillStyle = '#ffffff'; x.fillRect(0, 0, tw, H);
      x.save(); x.translate(-x0, 0);
      if (src) drawWallDesign(x, src, ox + off.img.x, P.TRIM_TOP + off.img.y, W, WH, 1, FW, H, off.scale || 1);
      x.restore();
      const chunks = []; let writer = null, done = null;
      if (deflate) { const cs = new CompressionStream('deflate'); writer = cs.writable.getWriter(); done = new Response(cs.readable).blob(); }
      for (let y0 = 0; y0 < H; y0 += 256) {
        const bh = Math.min(256, H - y0);
        const d = x.getImageData(0, y0, tw, bh).data;
        const out = new Uint8Array(tw * bh * 4);
        let last = -1, c0 = 0, c1 = 0, c2 = 0, c3 = 0;
        for (let i = 0; i !== d.length; i += 4) {
          const rr = d[i], gg = d[i + 1], bb = d[i + 2], key = rr * 65536 + gg * 256 + bb;
          if (key !== last) {
            last = key;
            const mx = Math.max(rr, gg, bb);
            if (mx === 0) { c0 = 0; c1 = 0; c2 = 0; c3 = 255; }
            else { c0 = Math.round((mx - rr) * 255 / mx); c1 = Math.round((mx - gg) * 255 / mx); c2 = Math.round((mx - bb) * 255 / mx); c3 = 255 - mx; }
          }
          out[i] = c0; out[i + 1] = c1; out[i + 2] = c2; out[i + 3] = c3;
        }
        if (writer) await writer.write(out); else chunks.push(out);
        await new Promise((res) => setTimeout(res, 0));
      }
      let data;
      if (writer) { await writer.close(); data = await done; } else data = new Blob(chunks);
      const id = alloc();
      put(id, ['<< /Type /XObject /Subtype /Image /Width ' + tw + ' /Height ' + H + ' /ColorSpace /DeviceCMYK /BitsPerComponent 8' + (writer ? ' /Filter /FlateDecode' : '') + ' /Length ' + data.size + ' >>\nstream\n', data, '\nendstream']);
      xobj.push('/Im' + id + ' ' + id + ' 0 R');
      tiles.push({ id, x0, w: tw });
      step++;
      if (o.onProgress) o.onProgress(step / total * 0.95);
    }
    tile.width = tile.height = 1;
    // 絵（実寸 mm）を、シートの (dx, dy) を左上にして 1/10 で描く。clip: シートの mm の四角 [x, y, w, h]
    const svgDefs = [];
    const drawPic = (dx, dy, clip, from, to) => {
      if (SVG) {
        const id = 'clip' + svgDefs.length;
        svgDefs.push('<clipPath id="' + id + '"><rect x="' + n3(clip[0]) + '" y="' + n3(clip[1]) + '" width="' + n3(clip[2]) + '" height="' + n3(clip[3]) + '"/></clipPath>');
        return '<g clip-path="url(#' + id + ')"><use href="#pic" xlink:href="#pic" x="' + n3(dx) + '" y="' + n3(dy) + '"/></g>\n';
      }
      let s = 'q ' + X(clip[0]) + ' ' + Y(clip[1] + clip[3]) + ' ' + n3(clip[2] * kk) + ' ' + n3(clip[3] * kk) + ' re W n\n';
      tiles.forEach((t) => {
        if (t.x0 + t.w < from || t.x0 > to) return;
        s += 'q ' + n3(t.w * SC * kk) + ' 0 0 ' + n3(H * SC * kk) + ' ' + X(dx + t.x0 * SC) + ' ' + Y(dy + H * SC) + ' cm /Im' + t.id + ' Do Q\n';
      });
      return s + 'Q\n';
    };
    // ---- 線・文字の道具 ----
    // SVG では色・線の太さを覚えておき、線・四角・文字ごとに書く（CMYK は RGB に直す）
    const st = { stroke: '#000000', fill: '#000000', width: 0.1 };
    const rgbHex = (c, m, y, k) => '#' + [c, m, y].map((v) => Math.round(255 * (1 - v) * (1 - k)).toString(16).padStart(2, '0')).join('');
    const K = (c, m, y, k) => { if (SVG) { st.stroke = rgbHex(c, m, y, k); return ''; } return n3(c) + ' ' + n3(m) + ' ' + n3(y) + ' ' + n3(k) + ' K\n'; };
    const Kf = (c, m, y, k) => { if (SVG) { st.fill = rgbHex(c, m, y, k); return ''; } return n3(c) + ' ' + n3(m) + ' ' + n3(y) + ' ' + n3(k) + ' k\n'; };
    const lw = (pt) => { if (SVG) { st.width = pt * PTM; return ''; } return n3(pt / u) + ' w\n'; };
    const sAttr = () => ' fill="none" stroke="' + st.stroke + '" stroke-width="' + String(Math.round(st.width * 1e5) / 1e5) + '"';
    const line = (x1, y1, x2, y2) => (SVG ? '<line x1="' + n3(x1) + '" y1="' + n3(y1) + '" x2="' + n3(x2) + '" y2="' + n3(y2) + '"' + sAttr() + '/>\n' : X(x1) + ' ' + Y(y1) + ' m ' + X(x2) + ' ' + Y(y2) + ' l S\n');
    const rect = (x, y, w, h) => (SVG ? '<rect x="' + n3(x) + '" y="' + n3(y) + '" width="' + n3(w) + '" height="' + n3(h) + '"' + sAttr() + '/>\n' : X(x) + ' ' + Y(y + h) + ' ' + n3(w * kk) + ' ' + n3(h * kk) + ' re S\n');
    const xmlEsc = (t) => t.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    const qo = SVG ? '' : 'q 0 J 0 j ', qc = SVG ? '' : 'Q\n';
    // 文字の幅（フォントを埋め込むときはフォントの幅）。使った文字を数えて、あとで埋め込むフォントに入れる
    const usedG = new Map();   // グリフ番号 → 文字
    const tw = (t, size) => {
      let w = 0;
      for (const ch of t) w += font ? font.adv(font.gid(ch.codePointAt(0))) / 1000 : (ch.charCodeAt(0) < 128 ? 0.55 : 1);
      return w * size;
    };
    const enc16 = (t) => {
      if (!font) return utf16(t);
      let h = '';
      for (const ch of t) {
        const g = font.gid(ch.codePointAt(0));
        if (!usedG.has(g)) usedG.set(g, ch);
        h += g.toString(16).toUpperCase().padStart(4, '0');
      }
      return h;
    };
    // 文字（size はシートの mm）。align: 'c' 中央 / 'l' 左 / 'r' 右。rot: 90 で縦（左に倒す）
    const text = (str, x, y, size, align, rot) => {
      const w = tw(str, size), a = align || 'c';
      if (SVG) {
        if (font) enc16(str); // 使った文字を数える（SVG に入れるフォントのため）
        const fa = ' font-size="' + String(Math.round(size * 1e4) / 1e4) + '" fill="' + st.fill + '" font-family="Noto Sans JP, sans-serif"';
        if (rot) {
          const yy = a === 'c' ? y + w / 2 : y;
          return '<text x="' + n3(x) + '" y="' + n3(yy) + '" transform="rotate(-90 ' + n3(x) + ' ' + n3(yy) + ')"' + fa + '>' + xmlEsc(str) + '</text>\n';
        }
        const xx = a === 'c' ? x - w / 2 : (a === 'r' ? x - w : x);
        return '<text x="' + n3(xx) + '" y="' + n3(y) + '"' + fa + '>' + xmlEsc(str) + '</text>\n';
      }
      const fs = n3(size * kk);
      if (rot) {
        const yy = a === 'c' ? y + w / 2 : y;
        return 'BT /F1 ' + fs + ' Tf 0 1 -1 0 ' + X(x) + ' ' + Y(yy) + ' Tm <' + enc16(str) + '> Tj ET\n';
      }
      const xx = a === 'c' ? x - w / 2 : (a === 'r' ? x - w : x);
      return 'BT /F1 ' + fs + ' Tf ' + X(xx) + ' ' + Y(y) + ' Td <' + enc16(str) + '> Tj ET\n';
    };
    // 寸法：見本と同じ（文字 20pt・線 0.455pt・端の線 4mm）。上の寸法は線の 12.6pt 上、下の寸法は線の 27.8pt 下に数字
    const TS = 20 * PTM;
    const DT = 2;                    // 端の線の半分（シートの mm）
    const hdim = (x1, x2, y, v, below) => line(x1, y, x2, y) + line(x1, y - DT, x1, y + DT) + line(x2, y - DT, x2, y + DT) + text(f1(v), (x1 + x2) / 2, below ? y + 27.8 * PTM : y - 12.6 * PTM, TS, 'c');
    const vdim = (x, y1, y2, v) => line(x, y1, x, y2) + line(x - DT, y1, x + DT, y1) + line(x - DT, y2, x + DT, y2) + text(f1(v), x - 12.6 * PTM, (y1 + y2) / 2, TS, 'c', 90);
    const px1 = (xr) => s1x + xr * SC, py1 = (yr) => s1y + yr * SC;     // 全体図：絵の実寸 → シート
    const stripX = (i) => s1x + splitR(i) * SC;                           // 分割図：i 番目の巾の左端（シート）
    const stripNo = (i) => (right ? N - i : i + 1);                       // 貼り始めが 1
    const label = (i) => stripNo(i) + '_【' + name + '】';
    // 巾 i が受け持つ壁の範囲（実寸、巾の左端から）：カット線（巾の端から合わせ代の半分）の間で、壁の中だけ
    const part = (i) => {
      const x0 = i * P.STEP;
      const a0 = Math.max(x0 + P.EDGE, ox), a1 = Math.min(x0 + P.ROLL - P.EDGE, ox + W);
      return a1 > a0 ? { l: a0 - x0, r: a1 - x0 } : null;
    };
    // ---- 分割の枠（トンボと名前）：見本と同じ ----
    // 巾の枠（rx, ry, rw, rh）の中の、仕上がりの四角（qx0..qx1, qy0..qy1）に、
    //   横のトンボ：仕上がりの上下の高さで、巾の枠の左右の外側に 5mm（実寸）、
    //   縦のトンボ：仕上がりの左右の位置で、巾の枠の上下の外側に 5mm（実寸）、
    //   名前「N_【案件名】」（1.2pt）：仕上がりの左端の少し右、巾の枠の上の外側・下の外側、
    //   「天↑地」（1.2pt・縦書き）：巾の枠の左の外側、上の角・下の角
    const TL = 5 * SC, NS = 1.2 * PTM, TD = 1.2 * PTM;
    const tategaki = (str, cx, top, size, fromBottom) => {
      const n = str.length, y0 = fromBottom ? top - n * size : top;
      let t = '';
      for (let k = 0; k !== n; k++) t += text(str[k], cx, y0 + (k + 0.88) * size, size, 'c');
      return t;
    };
    const trim = (rx, ry, rw, rh, qx0, qx1, qy0, qy1, lab, tdSize) => {
      // トンボは各所とも、下に白線（0.2268pt）・上に黒線（0.03pt）の2本（画像の上でも見えるように。見本と同じ）。
      // 右側の横のトンボ（上下）は、巾の枠の右端から 2mm（実寸）内側に寄せる
      const RI = 2 * SC;
      const ticks = line(rx - TL, qy0, rx, qy0) + line(rx - TL, qy1, rx, qy1) + line(rx + rw - RI, qy0, rx + rw + TL - RI, qy0) + line(rx + rw - RI, qy1, rx + rw + TL - RI, qy1)
        + line(qx0, ry - TL, qx0, ry) + line(qx1, ry - TL, qx1, ry) + line(qx0, ry + rh, qx0, ry + rh + TL) + line(qx1, ry + rh, qx1, ry + rh + TL);
      let t = K(0, 0, 0, 0) + lw(0.2268) + ticks + K(0, 0, 0, 1) + lw(0.03) + ticks;
      // 裁断ライン：仕上がりの四角（左右＝カット線、上下＝壁の上端・下端）を透明な線で重ねる（見えないが選択できる）
      t += SVG
        ? '<rect class="cut-line" x="' + n3(qx0) + '" y="' + n3(qy0) + '" width="' + n3(qx1 - qx0) + '" height="' + n3(qy1 - qy0) + '" fill="none" stroke="#000000" stroke-opacity="0" stroke-width="' + n3(PTM) + '"><title>裁断ライン</title></rect>\n'
        : 'q /GS0 gs ' + lw(1) + X(qx0) + ' ' + Y(qy1) + ' ' + n3((qx1 - qx0) * kk) + ' ' + n3((qy1 - qy0) * kk) + ' re S Q\n' + K(0, 0, 0, 1) + lw(0.03);
      t += Kf(0, 0, 0, 0.99);
      t += text(lab, qx0 + 2.6 * PTM, ry - 0.29 * PTM, NS, 'l') + text(lab, qx0 + 2.6 * PTM, ry + rh + 1.21 * PTM, NS, 'l');
      const ts = (tdSize || TD) * 2 / 3;   // 「天↑地」は見本の 2/3 の大きさ
      t += Kf(0, 0, 0, 1) + tategaki('天↑地', rx - 0.66 * PTM, ry + 0.56 * PTM, ts) + tategaki('天↑地', rx - 0.66 * PTM, ry + rh - 0.56 * PTM, ts, true);
      return t;
    };
    // ---- レイヤーの中身 ----
    let gfx = '', div = '', wall = '', spec = '', dim = '';
    // グラフィック：全体図と、巾ごとの画像（巾の枠で切り抜く）
    gfx += drawPic(s1x, s1y, [s1x, s1y, s1w, s1h], 0, FW);
    for (let i = 0; i !== N; i++) {
      const xs = i * P.STEP, sx = stripX(i);
      gfx += drawPic(sx - xs * SC, s2y, [sx, s2y, P.ROLL * SC, s2h], xs, xs + P.ROLL);
    }
    // 分割：全体図の巾の枠（分割外枠・0.1mm）と、全体図・分割図の巾ごとのトンボと名前
    div += qo + K(0, 0, 0, 1) + lw(0.2835);
    for (let i = 0; i !== N; i++) div += rect(px1(i * P.STEP), s1y, P.ROLL * SC, s1h);
    const qy0 = P.TRIM_TOP * SC, qy1 = (P.TRIM_TOP + WH) * SC;
    for (let i = 0; i !== N; i++) {
      const q = part(i);
      if (!q) continue;
      const fx = px1(i * P.STEP), sx = stripX(i);
      div += trim(fx, s1y, P.ROLL * SC, s1h, fx + q.l * SC, fx + q.r * SC, s1y + qy0, s1y + qy1, label(i));
      div += trim(sx, s2y, P.ROLL * SC, s2h, sx + q.l * SC, sx + q.r * SC, s2y + qy0, s2y + qy1, label(i));
    }
    // 見本の枠（ピッチ）：巾 × 300mm（実寸）の枠に、ピッチ × 200mm の仕上がり
    const lgx = s1x + (minR + 800) * SC, lgw = P.ROLL * SC, lgh = 30;
    div += K(0, 0, 0, 1) + lw(0.0312) + rect(lgx, specY, lgw, lgh);
    div += trim(lgx, specY, lgw, lgh, lgx + P.EDGE * SC, lgx + lgw - P.EDGE * SC, specY + 5, specY + lgh - 5, '1_【' + name + '】', 1.0 * PTM);
    div += qc;
    // 壁面全体のライン：全体の範囲（マゼンタ）、壁の範囲（シアン）
    wall += qo + K(0, 1, 0, 0) + lw(0.99) + rect(s1x, s1y, s1w, s1h);
    wall += K(1, 0, 0, 0) + lw(0.99);
    (o.shapes || []).forEach((pts) => {
      wall += SVG
        ? '<path d="' + pts.map((q, i) => (i ? 'L' : 'M') + n3(px1(q[0])) + ' ' + n3(py1(q[1]))).join(' ') + ' Z"' + sAttr() + '/>\n'
        : pts.map((q, i) => X(px1(q[0])) + ' ' + Y(py1(q[1])) + (i ? ' l' : ' m')).join(' ') + ' h S\n';
    });
    wall += qc;
    // 仕様：ピッチ（見本の枠の上）と、案件名などの欄
    const today = new Date();
    const date = today.getFullYear() + '/' + (today.getMonth() + 1) + '/' + today.getDate();
    const lines = [
      '案件名：' + name,
      '壁：幅 ' + f1(W) + ' × 高さ ' + f1(WH) + ' mm' + (multi ? '（壁 ' + o.walls.map((w) => w.no).join('→') + ' をつなげる）' : ''),
      '巾 ' + f1(P.PITCH) + ' mm ＋ 合わせ代 ' + f1(P.MARGIN) + ' mm × 2 ＝ ' + f1(P.ROLL) + ' mm ／ ' + f1(P.STEP) + 'ピッチ ／ ' + N + ' 巾（' + (right ? '右' : '左') + 'から貼る）',
      '上下の余白 ' + f1(P.TRIM_TOP) + ' mm ／ スタート側の端の余白 ' + f1(P.SIDE) + ' mm ／ 全体 ' + f1(FW) + ' × ' + f1(H) + ' mm',
      '縮尺 1/10 ／ 作成日 ' + date + ' ／ 確認用'
    ];
    spec += (SVG ? '' : 'q ') + Kf(0, 0, 0, 1);
    spec += text(f1(P.STEP) + 'ピッチ', lgx + lgw / 2, specY - 6, 53 * PTM, 'c');
    lines.forEach((t, i) => { spec += text(t, lgx + lgw + 25, specY + 4 + i * 6, 4, 'l'); });
    spec += qc;
    // 寸法：全体図の上（壁ごと → 余白｜壁｜余白 → 全体）・左（余白｜壁の高さ｜余白 → 全体）・下（巾ごとの仕上がり）、
    // 分割図の上（巾ごとに 左｜仕上がり｜右 → 巾）・左
    dim += qo + K(0, 0, 0, 1) + Kf(0, 0, 0, 1) + lw(0.455);
    const wl = px1(ox), wr = px1(ox + W);
    const r1 = s1y - 13.05, r2 = r1 - 15.2, r3 = r2 - 15.2;
    if (multi) {
      let acc = ox;
      o.walls.forEach((w) => { dim += hdim(px1(acc), px1(acc + w.W), r1, w.W); acc += w.W; });
    }
    const rm = multi ? r2 : r1, rt = multi ? r3 : r2;
    if (ox > 0.5) dim += hdim(s1x, wl, rm, ox);
    dim += hdim(wl, wr, rm, W);
    if (FW - ox - W > 0.5) dim += hdim(wr, s1x + s1w, rm, FW - ox - W);
    dim += hdim(s1x, s1x + s1w, rt, FW);
    const vd = (x, y) => vdim(x - 9.5, y, y + qy0, P.TRIM_TOP) + vdim(x - 9.5, y + qy0, y + qy1, WH) + vdim(x - 9.5, y + qy1, y + s1h, P.TRIM_BOTTOM) + vdim(x - 23.5, y, y + s1h, H);
    dim += vd(s1x, s1y);
    for (let i = 0; i !== N; i++) {
      const q = part(i);
      if (q) dim += hdim(px1(i * P.STEP + q.l), px1(i * P.STEP + q.r), s1y + s1h + 9.5, q.r - q.l, true);
    }
    for (let i = 0; i !== N; i++) {
      const sx = stripX(i), sw = P.ROLL * SC, q = part(i) || { l: P.EDGE, r: P.ROLL - P.EDGE };
      dim += hdim(sx, sx + sw, s2y - 28.75, P.ROLL);
      dim += hdim(sx, sx + q.l * SC, s2y - 13.6, q.l) + hdim(sx + q.l * SC, sx + q.r * SC, s2y - 13.6, q.r - q.l) + hdim(sx + q.r * SC, sx + sw, s2y - 13.6, P.ROLL - q.r);
    }
    dim += vd(stripX(0), s2y);
    dim += qc;
    const names = ['グラフィック', '分割', '壁面ライン', '寸法', '仕様'];
    const bodies = [gfx, div, wall, dim, spec];
    const fileBase = 'wallpaper_sheet_' + N + 'strips_' + FW + 'x' + H + 'mm_pitch' + P.PITCH + '_margin' + P.MARGIN + (right ? '_right' : '_left') + '_' + Date.now();
    // ---- SVG にまとめる（Inkscape のレイヤー。文字は Noto Sans JP、使った文字だけのフォントも中に入れる）----
    if (SVG) {
      let fontCss = '';
      if (font) {
        const sub = font.subset(Array.from(usedG.keys()));
        let bin = '';
        for (let i = 0; i < sub.length; i += 0x8000) bin += String.fromCharCode.apply(null, sub.subarray(i, i + 0x8000));
        fontCss = '<style>@font-face{font-family:"Noto Sans JP";src:url(data:font/ttf;base64,' + btoa(bin) + ') format("truetype");}</style>';
      }
      const svg = '<?xml version="1.0" encoding="UTF-8"?>\n'
        + '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"'
        + ' width="' + n3(pageW) + 'mm" height="' + n3(pageH) + 'mm" viewBox="0 0 ' + n3(pageW) + ' ' + n3(pageH) + '">\n'
        + '<title>' + xmlEsc('確認用 ' + name) + '</title>\n' + fontCss + '\n'
        + '<defs><image id="pic" width="' + n3(FW * SC) + '" height="' + n3(H * SC) + '" preserveAspectRatio="none" href="' + picUrl + '" xlink:href="' + picUrl + '"/>' + svgDefs.join('') + '</defs>\n'
        + '<rect x="0" y="0" width="' + n3(pageW) + '" height="' + n3(pageH) + '" fill="#ffffff" sodipodi:insensitive="true"/>\n'
        + bodies.map((b, i) => '<g id="' + names[i] + '" data-name="' + names[i] + '" inkscape:groupmode="layer" inkscape:label="' + names[i] + '">\n' + b + '</g>\n').join('')
        + '</svg>\n';
      if (o.onProgress) o.onProgress(1);
      return { name: fileBase + '.svg', blob: new Blob([svg], { type: 'image/svg+xml' }), width: FW, height: H, strips: N, svg: true, sheet: true, font: font ? font.name : '' };
    }
    // ---- PDF にまとめる ----
    const ocgs = names.map((nm) => { const id = alloc(); put(id, ['<< /Type /OCG /Name <FEFF' + utf16(nm) + '> >>']); return id; });
    let content = '';
    // レイヤーごとに、ページ全体の切り抜きで1つのまとまり（Illustrator ではクリップグループ）にする。
    // Illustrator は PDF のレイヤーを読まないため、同梱のスクリプト（cfp-layers.jsx）がこのまとまりを順にレイヤーへ分ける
    const pageClip = '0 0 ' + n3(pageW * kk) + ' ' + n3(Hp) + ' re W n\n';
    bodies.forEach((b, i) => { content += '/OC /L' + i + ' BDC\nq ' + pageClip + b + 'Q\nEMC\n'; });
    const fontId = alloc(), cidId = alloc(), fdId = alloc();
    if (font) {
      // 使った文字だけのフォント（サブセット）を埋め込む（CIDFontType2・Identity-H・ToUnicode 付きで、文字として編集・検索できる）
      const gids = Array.from(usedG.keys()).sort((a, b) => a - b);
      const sub = font.subset(gids);
      let fdata = new Blob([sub]), filter = '';
      if (typeof CompressionStream === 'function') {
        fdata = await new Response(new Blob([sub]).stream().pipeThrough(new CompressionStream('deflate'))).blob();
        filter = ' /Filter /FlateDecode';
      }
      const tagChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      let tag = '';
      for (let i = 0; i !== 6; i++) tag += tagChars[Math.floor(Math.random() * 26)];
      const base = tag + '+' + font.name;
      const ffId = alloc(), tuId = alloc();
      put(ffId, ['<< /Length ' + fdata.size + ' /Length1 ' + sub.length + filter + ' >>\nstream\n', fdata, '\nendstream']);
      put(fdId, ['<< /Type /FontDescriptor /FontName /' + base + ' /Flags 4 /FontBBox [' + font.bbox.join(' ') + '] /ItalicAngle 0 /Ascent ' + font.ascent + ' /Descent ' + font.descent + ' /CapHeight ' + font.capHeight + ' /StemV 80 /FontFile2 ' + ffId + ' 0 R >>']);
      const Wd = gids.map((g) => g + ' [' + font.adv(g) + ']').join(' ');
      put(cidId, ['<< /Type /Font /Subtype /CIDFontType2 /BaseFont /' + base + ' /CIDSystemInfo << /Registry (Adobe) /Ordering (Identity) /Supplement 0 >> /FontDescriptor ' + fdId + ' 0 R /DW 1000 /W [' + Wd + '] /CIDToGIDMap /Identity >>']);
      // ToUnicode（グリフ番号 → 文字）
      const hex4 = (v) => v.toString(16).toUpperCase().padStart(4, '0');
      const uni = (ch) => { let h = ''; for (let i = 0; i !== ch.length; i++) h += hex4(ch.charCodeAt(i)); return h; };
      let cmap = '/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n';
      for (let i = 0; i < gids.length; i += 100) {
        const chunk = gids.slice(i, i + 100);
        cmap += chunk.length + ' beginbfchar\n' + chunk.map((g) => '<' + hex4(g) + '> <' + uni(usedG.get(g)) + '>').join('\n') + '\nendbfchar\n';
      }
      cmap += 'endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n';
      const cb = enc.encode(cmap);
      put(tuId, ['<< /Length ' + cb.length + ' >>\nstream\n', cb, '\nendstream']);
      put(fontId, ['<< /Type /Font /Subtype /Type0 /BaseFont /' + base + ' /Encoding /Identity-H /DescendantFonts [' + cidId + ' 0 R] /ToUnicode ' + tuId + ' 0 R >>']);
    } else {
      put(fdId, ['<< /Type /FontDescriptor /FontName /KozGoPr6N-Regular /Flags 4 /FontBBox [-538 -374 1254 1418] /ItalicAngle 0 /Ascent 880 /Descent -120 /CapHeight 763 /StemV 116 >>']);
      put(cidId, ['<< /Type /Font /Subtype /CIDFontType0 /BaseFont /KozGoPr6N-Regular /CIDSystemInfo << /Registry (Adobe) /Ordering (Japan1) /Supplement 6 >> /FontDescriptor ' + fdId + ' 0 R /DW 1000 /W [1 95 500 231 632 500] >>']);
      put(fontId, ['<< /Type /Font /Subtype /Type0 /BaseFont /KozGoPr6N-Regular-UniJIS-UTF16-H /Encoding /UniJIS-UTF16-H /DescendantFonts [' + cidId + ' 0 R] >>']);
    }
    const contentId = alloc(), pageId = alloc(), pagesId = alloc(), catalogId = alloc(), infoId = alloc();
    const cbytes = enc.encode(content);
    put(contentId, ['<< /Length ' + cbytes.length + ' >>\nstream\n', cbytes, '\nendstream']);
    put(pageId, ['<< /Type /Page /Parent ' + pagesId + ' 0 R /MediaBox [0 0 ' + n3(pageW * kk) + ' ' + n3(Hp) + ']' + (u > 1 ? ' /UserUnit ' + u : '')
      + ' /Resources << /ExtGState << /GS0 << /Type /ExtGState /CA 0 /ca 0 >> >> /Font << /F1 ' + fontId + ' 0 R >> /XObject << ' + xobj.join(' ') + ' >> /Properties << ' + ocgs.map((id, i) => '/L' + i + ' ' + id + ' 0 R').join(' ') + ' >> >> /Contents ' + contentId + ' 0 R >>']);
    put(pagesId, ['<< /Type /Pages /Kids [' + pageId + ' 0 R] /Count 1 >>']);
    const refs = ocgs.map((id) => id + ' 0 R').join(' ');
    put(catalogId, ['<< /Type /Catalog /Pages ' + pagesId + ' 0 R /OCProperties << /OCGs [' + refs + '] /D << /Order [' + refs + '] /ON [' + refs + '] >> >> >>']);
    put(infoId, ['<< /Producer (cad-floor-plan wallpaper) /Title <FEFF' + utf16('確認用 ' + name) + '> >>']);
    const parts = []; let pos = 0;
    const add = (p) => { const b = typeof p === 'string' ? enc.encode(p) : p; parts.push(b); pos += b instanceof Blob ? b.size : b.length; };
    add('%PDF-1.6\n'); add(Uint8Array.of(37, 226, 227, 207, 211, 10));
    const offs = {};
    objs.sort((a, b) => a.id - b.id).forEach((ob) => { offs[ob.id] = pos; add(ob.id + ' 0 obj\n'); ob.parts.forEach(add); add('\nendobj\n'); });
    const xref = pos;
    let xr = 'xref\n0 ' + nextId + '\n0000000000 65535 f \n';
    for (let i = 1; i !== nextId; i++) xr += String(offs[i]).padStart(10, '0') + ' 00000 n \n';
    add(xr + 'trailer\n<< /Size ' + nextId + ' /Root ' + catalogId + ' 0 R /Info ' + infoId + ' 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
    if (o.onProgress) o.onProgress(1);
    return {
      name: fileBase + '.ai',
      blob: new Blob(parts, { type: 'application/postscript' }), width: FW, height: H, strips: N, ai: true, sheet: true, font: font ? font.name : ''
    };
  };

  // buildWhole と同じ内容を、タイルに分けて作る（大きな壁でも固まらない）。cadDraw(ctx): CAD図面を絵の座標に描く関数
  // split: 1ファイルの幅の上限（mm。0 / false なら分けない）。超えるときは巾の区切りで分けて ZIP にまとめる
  // （GIMP は CMYK の PSD を RGB に変えながら読むため、大きいほど開くのに時間とメモリがかかる）
  // format: 'ai' のときは Illustrator 用（.ai・PDF互換）、それ以外は CMYK の PSD
  WALL_PRINT.buildWholeAsync = async function (cadDraw, W, WH, right, shapes, off, label, onProgress, split, format) {
    const ai = format === 'ai';
    const ext = ai ? '.ai' : '.psd';
    // .ai はレイヤーの種類（画像・ベクトル）を指定して書く
    const write = (w, h, defs, compDraw, cb) => (ai
      ? writeAiPdf(w, h, defs.map((L, i) => ({ name: L.name, draw: L.draw, kind: ['jpeg', 'cmyk', 'vector'][i] })), cb)
      : writeCmykPsdTiled(w, h, defs, compDraw, 25.4, cb));
    off = off || { img: { x: 0, y: 0 }, frame: { x: 0, y: 0 } };
    const P = WALL_PRINT;
    const H = WH + P.TRIM_TOP + P.TRIM_BOTTOM;
    const fr = P.frames(W, right, off.frame ? off.frame.x : 0); // 枠を動かした分も入れた巾の並び
    const N = fr.N, FW = fr.FW, ox = fr.ox;
    const src = P.getSource();
    const cadL = (ctx) => { if (cadDraw) cadDraw(ctx); };
    const design = (ctx) => {
      if (src) drawWallDesign(ctx, src, ox + off.img.x, P.TRIM_TOP + off.img.y, W, WH, 1, FW, H, off.scale || 1);
      else { ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, FW, H); }
    };
    const frame = (ctx) => P.drawFrames(ctx, W, WH, N, FW, H, right, shapes, off.frame);
    const layerDefs = [
      { name: '①CAD図面（' + (label || '壁の範囲 ' + W + '×' + WH + 'mm') + '）', draw: cadL },
      { name: '②壁紙の画像（切り分けなし・左右の余白と上下' + P.TRIM_TOP + 'mmを含む）', draw: design },
      { name: '③巾の枠（巾' + P.PITCH + 'mm＋合わせ代' + P.MARGIN + 'mm×2＝' + P.ROLL + 'mm・' + N + '巾・' + (right ? '右' : '左') + '寄せスタート・紫＝壁の範囲とカット線）', draw: frame }
    ];
    const comp = (ctx) => { cadL(ctx); design(ctx); frame(ctx); };
    const MAXW = split === true ? 20000 : Math.max(Math.ceil(P.ROLL), +split || 0); // 1ファイルの幅の上限（mm）
    if (split ? FW > MAXW : false) {
      // 巾を左から並べ、1ファイルに入る巾の数ずつ区切る（隣のファイルとは、巾の重なり（合わせ代）の分だけ重なる）
      const xs = [];
      for (let i = 0; i !== N; i++) xs.push(right ? FW - P.ROLL - i * P.STEP : i * P.STEP);
      xs.sort((a, b) => a - b);
      const per = Math.max(1, Math.floor((MAXW - P.ROLL) / P.STEP) + 1);
      const M = Math.ceil(N / per);
      const files = [];
      const stamp = Date.now();
      const lines = ['壁紙データ（巾の枠）：幅 ' + FW + 'mm が ' + MAXW + 'mm を超えるため、巾の区切りで ' + M + ' 個の ' + (ai ? 'AI（Illustrator）ファイル' : 'PSD') + '（それぞれ幅 ' + MAXW + 'mm 以内）に分けました。',
        (ai ? '各AI：実寸（1mm = 1mm）・PDF互換の .ai、壁紙の画像は CMYK、巾の枠は線（ベクトル）。レイヤーは' : '各PSD：CMYK・1px = 1mm・25.4dpi、レイヤーは') + ' ①CAD図面 ②壁紙の画像 ③巾の枠。ファイル名の先頭の番号（01, 02 …）の順に左から並べると、元の1枚の絵になります。',
        '隣り合うファイルは、巾の重なり（合わせ代 ' + P.MARGIN + 'mm×2＝' + P.OVERLAP + 'mm）の分だけ同じ絵が入っています。', ''];
      for (let k = 0; k !== M; k++) {
        const first = k * per, last = Math.min(N, (k + 1) * per) - 1;
        const x0 = Math.max(0, Math.floor(xs[first])), x1 = Math.min(FW, Math.ceil(xs[last] + P.ROLL));
        const pw = x1 - x0;
        const sh = (fn) => (ctx) => { ctx.translate(-x0, 0); fn(ctx); };
        const blob = await write(pw, H, layerDefs.map((L) => ({ name: L.name, draw: sh(L.draw) })), sh(comp),
          (f) => { if (onProgress) onProgress((k + f) / M); });
        // 先頭に通し番号（01_, 02_ …）を付けて、名前順に並べると左から順になるようにする
        const z2 = (v) => String(v).padStart(Math.max(2, String(M).length), '0');
        const name = z2(k + 1) + '_wallpaper_part' + z2(k + 1) + 'of' + z2(M) + '_strips' + (first + 1) + '-' + (last + 1) + '_x' + x0 + '-' + x1 + 'mm_' + pw + 'x' + H + 'mm' + ext;
        files.push({ name, blob });
        lines.push((k + 1) + '. ' + name + '（' + (first + 1) + '〜' + (last + 1) + '巾目・全体の左から ' + x0 + '〜' + x1 + 'mm）');
      }
      files.push({ name: '00_README_分けた' + (ai ? 'AI' : 'PSD') + 'について.txt', blob: new Blob([lines.join('\r\n')], { type: 'text/plain' }) });
      const zip = await makeZip(files);
      return {
        name: 'wallpaper_whole_' + FW + 'x' + H + 'mm_' + M + 'files_' + (right ? 'right' : 'left') + '_' + stamp + '.zip',
        blob: zip, width: FW, height: H, strips: N, split: M, maxw: MAXW
      };
    }
    const blob = await write(FW, H, layerDefs, comp, onProgress);
    const psb = ai ? false : (FW > 30000 || H > 30000);
    return {
      name: 'wallpaper_whole_' + FW + 'x' + H + 'mm_pitch' + P.PITCH + '_margin' + P.MARGIN + (right ? '_right' : '_left') + '_' + Date.now() + (ai ? '.ai' : (psb ? '.psb' : '.psd')),
      blob, width: FW, height: H, strips: N, psb, ai
    };
  };
  // cadFull: CAD図面のレイヤー（絵の大きさのcanvas、壁の位置に描いたもの）。W: 壁の幅（つなげたときは合計）、WH: 壁の高さ（最大）
  // off: { img: {x, y}, frame: {x, y} } 画像・枠を動かした量（mm）
  WALL_PRINT.buildWhole = function (cadFull, W, WH, right, shapes, off, label) {
    off = off || { img: { x: 0, y: 0 }, frame: { x: 0, y: 0 } };
    const P = WALL_PRINT;
    const H = WH + P.TRIM_TOP + P.TRIM_BOTTOM;
    const fr = P.frames(W, right, off.frame ? off.frame.x : 0); // 枠を動かした分も入れた巾の並び
    const N = fr.N, FW = fr.FW, ox = fr.ox;
    const mk = () => { const c = document.createElement('canvas'); c.width = FW; c.height = H; return c; };
    const cadL = mk();
    if (cadFull) cadL.getContext('2d').drawImage(cadFull, 0, 0);
    const design = mk();
    P.renderDesign(design, ox + off.img.x, P.TRIM_TOP + off.img.y, W, WH);
    const frame = mk();
    P.drawFrames(frame.getContext('2d'), W, WH, N, FW, H, right, shapes, off.frame);
    const comp = mk();
    const cx = comp.getContext('2d');
    cx.fillStyle = '#ffffff';
    cx.fillRect(0, 0, FW, H);
    cx.drawImage(cadL, 0, 0);
    cx.drawImage(design, 0, 0);
    cx.drawImage(frame, 0, 0);
    return {
      name: 'wallpaper_whole_' + FW + 'x' + H + 'mm_pitch' + P.PITCH + '_margin' + P.MARGIN + (right ? '_right' : '_left') + '_' + Date.now() + '.psd',
      blob: writeCmykPsd(FW, H, comp, [
        { name: '①CAD図面（' + (label || '壁の範囲 ' + W + '×' + WH + 'mm') + '）', canvas: cadL },
        { name: '②壁紙の画像（切り分けなし・左右の余白と上下' + P.TRIM_TOP + 'mmを含む）', canvas: design },
        { name: '③巾の枠（巾' + P.PITCH + 'mm＋合わせ代' + P.MARGIN + 'mm×2＝' + P.ROLL + 'mm・' + N + '巾・' + (right ? '右' : '左') + '寄せスタート・紫＝壁の範囲とカット線）', canvas: frame }
      ], 25.4),
      width: FW, height: H, strips: N
    };
  };

  // 壁1面分のデザイン（1px=1mm）。貼り方（繰り返し／壁ごとに中央／一周）に合わせる
  function buildWallDesignCanvas(source, w, h, wallH) {
    const r = getWallRepeat();
    if (r.on) return tileWallCanvas(source, w, h, r.mm);
    return r.mode === 'wrap' ? wrapWallCanvas(source, w, h, wallH) : coverWallCanvas(source, w, h, wallH);
  }

  // ---- ZIP（無圧縮）：複数ファイルを1つにまとめてダウンロードするため ----
  const CRC_TABLE = (() => {
    const tb = new Uint32Array(256);
    for (let n = 0; n !== 256; n++) {
      let c = n;
      for (let k = 0; k !== 8; k++) c = (c % 2) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      tb[n] = c >>> 0;
    }
    return tb;
  })();
  function crc32(u8) {
    let c = 0xFFFFFFFF;
    for (let i = 0; i !== u8.length; i++) c = CRC_TABLE[((c ^ u8[i]) >>> 0) % 256] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  async function makeZip(files) {
    const enc = new TextEncoder();
    const parts = [], central = [];
    let offset = 0;
    const u16 = (v) => Uint8Array.of(v % 256, Math.floor(v / 256) % 256);
    const u32 = (v) => Uint8Array.of(v % 256, Math.floor(v / 256) % 256, Math.floor(v / 65536) % 256, Math.floor(v / 16777216) % 256);
    // 保存した日時（パソコンの時刻）をファイルの更新日時に入れる（0 のままだと解凍後 1980年1月1日 になる）
    const now = new Date();
    const dosTime = now.getHours() * 2048 + now.getMinutes() * 32 + Math.floor(now.getSeconds() / 2);
    const dosDate = (Math.max(1980, now.getFullYear()) - 1980) * 512 + (now.getMonth() + 1) * 32 + now.getDate();
    for (const f of files) {
      // PSD は作るときに CRC32 を計算済み（cfpCrc）。そのときは中身を読み直さない（大きなファイルで固まらない）
      const known = typeof f.blob.cfpCrc === 'number';
      const data = known ? f.blob : new Uint8Array(await f.blob.arrayBuffer());
      const dlen = known ? f.blob.size : data.length;
      const name = enc.encode(f.name);
      const crc = known ? f.blob.cfpCrc : crc32(data);
      const head = [u16(20), u16(0x0800), u16(0), u16(dosTime), u16(dosDate), u32(crc), u32(dlen), u32(dlen), u16(name.length), u16(0)];
      const local = [Uint8Array.of(0x50, 0x4b, 0x03, 0x04)].concat(head, [name]);
      local.forEach((p) => parts.push(p));
      parts.push(data);
      central.push([Uint8Array.of(0x50, 0x4b, 0x01, 0x02), u16(20)].concat(head, [u16(0), u16(0), u16(0), u32(0), u32(offset), name]));
      offset += local.reduce((s, p) => s + p.length, 0) + dlen;
    }
    let csize = 0;
    central.forEach((c) => c.forEach((p) => { parts.push(p); csize += p.length; }));
    parts.push(Uint8Array.of(0x50, 0x4b, 0x05, 0x06), u16(0), u16(0), u16(files.length), u16(files.length), u32(csize), u32(offset), u16(0));
    return new Blob(parts, { type: 'application/zip' });
  }

  // ---- 壁紙への印刷用：910mm幅（ロール幅）の巾に分割したCMYK PSDを、ZIPにまとめて保存 ----
  // 1巾 = 幅910mm（隣の巾と合わせ代10mmだけ重なる。壁を受け持つのはカット線からカット線までの900mm）× 高さ（壁の高さ + 上下100mmずつ）。
  // 赤枠（別レイヤー）は、その巾が受け持つ壁の範囲（左右の重なり・上下の裁断代の内側）。
  async function downloadWallPrintStrips() {
    const canvas = getWallSource();
    if (!canvas || !(canvas.naturalWidth || canvas.width)) {
      alert('先に「② 壁紙用デザイン」で画像を処理してください。');
      return;
    }
    const button = $('btn-save-wall-print');
    const label = button ? button.textContent : '';
    if (button) button.disabled = true;
    try {
      const P = WALL_PRINT;
      const W = Math.max(1, Math.round(parseFloat($('persp-width')?.value) || 3000));
      const WH = Math.max(1, Math.round(parseFloat($('persp-wall-height')?.value) || 2400));
      const H = WH + P.TRIM_TOP + P.TRIM_BOTTOM;
      const N = P.count(W);
      // 全巾分の絵：壁の左端が x = SIDE（スタート側の余白）、天井が y = TRIM_TOP
      const full = document.createElement('canvas');
      full.width = N * P.STEP + P.OVERLAP;
      full.height = H;
      drawWallDesign(full.getContext('2d'), canvas, P.SIDE + (window.cfpWallShift || { x: 0 }).x, P.TRIM_TOP + (window.cfpWallShift || { y: 0 }).y, W, WH, 1, 0, 0, (window.cfpWallShift || { s: 1 }).s || 1);

      const files = [];
      const strips = [];
      const stamp = Date.now();
      for (let i = 0; i !== N; i++) {
        if (button) button.textContent = '印刷用データを作成中… ' + (i + 1) + ' / ' + N;
        await new Promise((res) => setTimeout(res, 0));
        const strip = document.createElement('canvas');
        strip.width = P.ROLL;
        strip.height = H;
        strip.getContext('2d').drawImage(full, i * P.STEP, 0, P.ROLL, H, 0, 0, P.ROLL, H);
        // 赤枠：この巾が受け持つ壁の範囲（最後の巾は壁の右端まで）
        const frame = document.createElement('canvas');
        frame.width = P.ROLL;
        frame.height = H;
        const fx = frame.getContext('2d');
        fx.strokeStyle = '#ff0000';
        fx.lineWidth = 2;
        // この巾が受け持つ壁の範囲：壁の範囲と、カット線からカット線（両端の巾は枠の端）の重なり
        const lo = Math.max(P.SIDE - i * P.STEP, i === 0 ? 0 : P.EDGE);
        const hi = Math.min(P.SIDE + W - i * P.STEP, i === N - 1 ? P.ROLL : P.STEP + P.EDGE);
        fx.strokeRect(lo + 1, P.TRIM_TOP + 1, Math.max(1, hi - lo - 2), WH - 2);
        const comp = document.createElement('canvas');
        comp.width = P.ROLL;
        comp.height = H;
        const cx = comp.getContext('2d');
        cx.drawImage(strip, 0, 0);
        cx.drawImage(frame, 0, 0);
        strips.push({ design: strip, frame: frame });
        const no = String(i + 1).padStart(2, '0');
        files.push({
          name: 'wallpaper_' + no + '_of_' + String(N).padStart(2, '0') + '_' + P.ROLL + 'x' + H + 'mm.psd',
          blob: writeCmykPsd(P.ROLL, H, comp, [
            { name: '①壁紙 ' + (i + 1) + '巾目（左から） 幅' + P.ROLL + 'mm×高さ' + H + 'mm', canvas: strip },
            { name: '②赤枠（壁の範囲：左右の重なり10mm・上下の裁断代100mmの内側）', canvas: frame }
          ], 25.4)
        });
      }
      // ---- 変換後全体データ：全巾分の絵（左右の重なり・上下の裁断代を含む）＋赤枠（壁の範囲）と巾の境目 ----
      if (button) button.textContent = '全体データを作成中…';
      await new Promise((res) => setTimeout(res, 0));
      const fullFrame = document.createElement('canvas');
      fullFrame.width = full.width;
      fullFrame.height = H;
      const ff = fullFrame.getContext('2d');
      ff.strokeStyle = '#ff0000';
      ff.lineWidth = 3;
      ff.strokeRect(P.SIDE + 1.5, P.TRIM_TOP + 1.5, W - 3, WH - 3);
      ff.lineWidth = 2;
      for (let i = 1; i !== N; i++) {
        const lx = P.EDGE + i * P.STEP + 0.5;
        ff.beginPath(); ff.moveTo(lx, 0); ff.lineTo(lx, H); ff.stroke();
      }
      const fullComp = document.createElement('canvas');
      fullComp.width = full.width;
      fullComp.height = H;
      fullComp.getContext('2d').drawImage(full, 0, 0);
      fullComp.getContext('2d').drawImage(fullFrame, 0, 0);
      const extra = [];
      extra.push({
        name: '02_変換後全体データ_' + full.width + 'x' + H + 'mm.psd',
        blob: writeCmykPsd(full.width, H, fullComp, [
          { name: '①壁紙 全体（' + N + '巾分・左右の重なりと上下の裁断代を含む）', canvas: full },
          { name: '②赤枠（壁の範囲）・巾の境目', canvas: fullFrame }
        ], 25.4)
      });

      // ---- 910mm幅で切った長いデータ：巾を縦につなげ、1巾おきに180°回転（上下を逆向き）して連続させる ----
      // 1巾目は上が天井側、2巾目は下が天井側…と交互にすることで、隣り合う巾の端どうし（天井側どうし・床側どうし）がつながる。
      // PSDの高さの上限（30,000px）を超えるときは、複数のファイルに分ける。
      const perFile = Math.max(1, Math.floor(30000 / H));
      const parts = Math.ceil(N / perFile);
      for (let pi = 0; pi !== parts; pi++) {
        if (button) button.textContent = '長いデータを作成中… ' + (pi + 1) + ' / ' + parts;
        await new Promise((res) => setTimeout(res, 0));
        const first = pi * perFile, count = Math.min(perFile, N - first);
        const longD = document.createElement('canvas');
        const longF = document.createElement('canvas');
        longD.width = longF.width = P.ROLL;
        longD.height = longF.height = count * H;
        const ld = longD.getContext('2d'), lf = longF.getContext('2d');
        for (let j = 0; j !== count; j++) {
          const si = first + j;
          const put = (ctx, src) => {
            ctx.save();
            if (si % 2 === 1) { ctx.translate(P.ROLL, j * H + H); ctx.rotate(Math.PI); }
            else ctx.translate(0, j * H);
            ctx.drawImage(src, 0, 0);
            ctx.restore();
          };
          put(ld, strips[si].design);
          put(lf, strips[si].frame);
        }
        const longC = document.createElement('canvas');
        longC.width = P.ROLL;
        longC.height = count * H;
        longC.getContext('2d').drawImage(longD, 0, 0);
        longC.getContext('2d').drawImage(longF, 0, 0);
        extra.push({
          name: '03_' + P.ROLL + 'mm幅ロール連続データ_' + (first + 1) + '-' + (first + count) + '巾目_' + P.ROLL + 'x' + (count * H) + 'mm' + (parts > 1 ? '_' + (pi + 1) + 'of' + parts : '') + '.psd',
          blob: writeCmykPsd(P.ROLL, count * H, longC, [
            { name: '①壁紙 ' + (first + 1) + '〜' + (first + count) + '巾目（偶数巾は180°回転）', canvas: longD },
            { name: '②赤枠（各巾の壁の範囲）', canvas: longF }
          ], 25.4)
        });
      }
      // 元データ（アップロードされたファイルそのまま）
      if (cwState.file) extra.unshift({ name: '01_元データ_' + cwState.file.name, blob: cwState.file });
      files.forEach((x) => { x.name = '04_巾ごと/' + x.name; });
      files.unshift(...extra);

      const info = [
        '壁紙 印刷用データ（910mm幅の巾に分割）',
        '',
        '壁のサイズ（図面）：幅 ' + W + ' mm × 高さ ' + WH + ' mm',
        '1巾のサイズ：幅 ' + P.ROLL + ' mm × 高さ ' + H + ' mm（壁の高さ + 上下 ' + P.TRIM_TOP + ' mm ずつの裁断代）',
        '1巾の幅：巾 ' + P.PITCH + ' mm ＋ 合わせ代 ' + P.MARGIN + ' mm × 2 ＝ ' + P.ROLL + ' mm。隣の巾と ' + P.OVERLAP + ' mm 重なり、重なりの真ん中がカット線。1巾が受け持つ壁の幅は ' + P.STEP + ' mm',
        '巾数：' + N + ' 巾（左から順に 01, 02, …）',
        '赤枠：各巾が受け持つ壁の範囲（別レイヤー「②赤枠」。印刷しない場合はレイヤーを非表示にしてください）',
        '形式：CMYK・8bit・PSD・25.4dpi（1px = 1mm）。RGBからの単純変換のため、印刷色は校正してください。',
        '貼り方：' + ({ repeat: '柄を繰り返して貼る（柄の大きさ ' + getWallRepeat().mm + ' mm）', center: '1枚を壁ごとに中央に貼る', wrap: '1枚を部屋を一周して続けて貼る（奥の壁の部分）' }[getWallRepeat().mode] || ''),
        '',
        '【入っているデータ】',
        '01_元データ … アップロードされた壁紙用デザイン画像（そのまま）',
        '02_変換後全体データ … 減色後のデザインを壁全体に貼った絵（全 ' + N + ' 巾分。左右の重なり・上下の裁断代を含む）。赤枠＝壁の範囲、縦線＝巾の境目',
        '03_910mm幅ロール連続データ … 910mm幅の巾を縦に1本につなげたデータ。1巾目は上が天井側、2巾目は180°回転して下が天井側…と交互（1巾目の上をA・下をCとすると、AC→CA→AC→CA の順）。隣り合う巾は天井側どうし・床側どうしでつながります。PSDの高さ上限（30,000mm）を超える場合は複数ファイルに分けています',
        '04_巾ごと … 1巾ずつのPSD（すべて天井側が上）'
      ].join('\r\n');
      files.push({ name: 'README_印刷データについて.txt', blob: new Blob([new TextEncoder().encode('﻿' + info)], { type: 'text/plain' }) });
      if (button) button.textContent = 'ZIPにまとめています…';
      const zip = await makeZip(files);
      const link = document.createElement('a');
      link.href = URL.createObjectURL(zip);
      link.download = 'wallpaper_print_' + P.ROLL + 'mm_' + W + 'x' + WH + '_' + N + 'strips_' + stamp + '.zip';
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 2000);
    } catch (err) {
      alert('壁紙の印刷用データの作成中にエラーが発生しました。\n' + err.message);
    } finally {
      if (button) { button.disabled = false; button.textContent = label; }
    }
  }

  async function downloadWallImagePsd() {
    const canvas = getWallSource();
    if (!canvas || !(canvas.naturalWidth || canvas.width)) {
      alert('先に「② 壁紙用デザイン」で画像を処理してください。');
      return;
    }
    const button = $('btn-save-wall-image');
    if (button) button.disabled = true;
    try {
      const agPsd = await loadAgPsd();

      const P = WALL_PRINT;
      const widthMm = parseFloat(document.getElementById('persp-width')?.value) || 3000;
      const wallHeightMm = parseFloat(document.getElementById('persp-wall-height')?.value) || 2400;

      const imageW = Math.max(1, Math.round(widthMm));
      const WH = Math.max(1, Math.round(wallHeightMm));
      const imageH = WH + P.TRIM_TOP + P.TRIM_BOTTOM;

      // ①デザイン層：貼り方に合わせて実寸(1px=1mm)で描画（壁の上下に100mmずつの裁断代）
      const designCanvas = document.createElement('canvas');
      designCanvas.width = imageW;
      designCanvas.height = imageH;
      drawWallDesign(designCanvas.getContext('2d'), canvas, (window.cfpWallShift || { x: 0 }).x, P.TRIM_TOP + (window.cfpWallShift || { y: 0 }).y, imageW, WH, 1, 0, 0, (window.cfpWallShift || { s: 1 }).s || 1);

      // ②裁断ガイド層：赤枠（壁の範囲）と、巾の境目（カット線の間隔ごと）の縦線
      const guideCanvas = document.createElement('canvas');
      guideCanvas.width = imageW;
      guideCanvas.height = imageH;
      const gctx = guideCanvas.getContext('2d');
      gctx.strokeStyle = '#ff0000';
      gctx.lineWidth = 3;
      gctx.strokeRect(1.5, P.TRIM_TOP + 1.5, imageW - 3, WH - 3);
      gctx.lineWidth = 2;
      for (let x = P.STEP; x < imageW; x += P.STEP) {
        gctx.beginPath();
        gctx.moveTo(x + 0.5, 0);
        gctx.lineTo(x + 0.5, imageH);
        gctx.stroke();
      }

      // Photoshop以外のビューアーでも中身が分かるよう、合成プレビュー用キャンバスを用意
      const compositeCanvas = document.createElement('canvas');
      compositeCanvas.width = imageW;
      compositeCanvas.height = imageH;
      const cctx = compositeCanvas.getContext('2d');
      cctx.drawImage(designCanvas, 0, 0);
      cctx.drawImage(guideCanvas, 0, 0);

      // 壁紙は CMYK で保存（ガイド線は C0 M100 Y100 K0 の赤）
      const blob = writeCmykPsd(imageW, imageH, compositeCanvas, [
        { name: '①壁紙デザイン（実寸・幅' + imageW + 'mm×高さ' + imageH + 'mm）', canvas: designCanvas },
        { name: '②裁断ガイド（赤枠＝壁の範囲・上下' + P.TRIM_TOP + 'mmの裁断代／縦線＝巾の境目 ' + P.STEP + 'mmごと）', canvas: guideCanvas }
      ], 25.4);
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = 'wallpaper_design_guide_' + imageW + 'x' + imageH + '_' + Date.now() + '.psd';
      document.body.appendChild(link); link.click(); link.remove();
      setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    } catch (err) {
      alert('壁紙デザインのPSDファイル生成中にエラーが発生しました。\n' + err.message);
    } finally {
      if (button) button.disabled = false;
    }
  }
  // =====================================================================
  // 床・壁 画像保存 ここまで
  // =====================================================================

  function generateOrderNumber() {
    const now = new Date();
    const pad = (n, len) => String(n).padStart(len, '0');
    const datePart = '' + now.getFullYear() + pad(now.getMonth() + 1, 2) + pad(now.getDate(), 2);
    const randomPart = pad(Math.floor(Math.random() * 10000), 4);
    return 'ORD-' + datePart + '-' + randomPart;
  }

  function sendOrderMail() {
    const name = $('cc-name').value.trim();
    const tel = $('cc-tel').value.trim();
    const email = $('cc-email') ? $('cc-email').value.trim() : '';
    const address = $('cc-address').value.trim();
    if (!name || !tel || !address || !email) {
      alert('お名前、電話番号、メールアドレス、お届け先ご住所を入力してください。');
      return;
    }
    if (!$('cc-quality-ok') || !$('cc-quality-ok').checked) {
      alert('「品質基準について」を最後まで読み、チェックボックスにチェックを入れてください。');
      if ($('cc-quality-open')) $('cc-quality-open').focus();
      return;
    }
    if (!$('cc-copyright-ok') || !$('cc-copyright-ok').checked) {
      alert('「著作権に抵触しないデザインであること」のチェックボックスにチェックを入れてください。');
      if ($('cc-copyright-ok')) $('cc-copyright-ok').focus();
      return;
    }
    doSendOrderMail(name, tel, address, email).catch(err => {
      alert('注文メールの準備中にエラーが発生しました。\n' + err.message);
    });
  }

  // ---------------------------------------------------------------------------
  // 注文メール送信：床（カーペット）・壁紙それぞれの「元画像」「変換後画像」を
  // 個別のPSDファイル（計最大4ファイル・壁紙未アップロード時は2ファイル）として
  // サーバー（Design Order Mailerプラグイン）にアップロードし、
  // メール本文にはダウンロードリンクと、両方の階調表現（誤差拡散）％を記載する（添付なし）。
  // ファイルは60日間サーバーに保存され、期限を過ぎると自動的に削除される。
  // ---------------------------------------------------------------------------
  function makeSingleLayerCmykPsdBlob(canvas, layerName) {
    return writeCmykPsd(canvas.width, canvas.height, canvas, [{ name: layerName, canvas: canvas }], 25.4);
  }

  function makeSingleLayerPsdBlob(agPsd, canvas, layerName) {
    const psdData = {
      width: canvas.width,
      height: canvas.height,
      bitsPerChannel: 8,
      colorMode: 3,
      resolution: 25.4,
      canvas: canvas,
      children: [{ name: layerName, top: 0, left: 0, right: canvas.width, bottom: canvas.height, canvas: canvas }]
    };
    const buffer = agPsd.writePsd(psdData, { generateThumbnail: true });
    return new Blob([buffer], { type: 'image/vnd.adobe.photoshop' });
  }

  async function doSendOrderMail(name, tel, address, email) {
    const materialText = $('cc-material-name').textContent;
    const opCostText = $('cc-op-cost').textContent;
    const width = $('cc-width').value;
    const height = $('cc-height').value;
    const tileCountText = $('cc-tile-count') ? $('cc-tile-count').textContent : '';
    const regionSelect = $('cc-region');
    const region = regionSelect ? regionSelect.options[regionSelect.selectedIndex].text : '';
    const subtotal = $('cc-subtotal').textContent;
    const shipping = $('cc-shipping').textContent;
    const tax = $('cc-tax') ? $('cc-tax').textContent : '';
    const total = $('cc-total').textContent;
    const company = $('cc-company') ? $('cc-company').value.trim() : '';
    const needReceipt = $('cc-receipt') ? $('cc-receipt').checked : false;
    const orderNumber = generateOrderNumber();
    const sizeText = '横幅 ' + width + ' mm × 縦幅 ' + height + ' mm (500x500mm規格)';

    if (!state.loadedImg) {
      alert('ご注文には、カーペット用デザイン画像のアップロードが必要です。先に画像を選択してください。');
      return;
    }

    if (typeof DOMailer === 'undefined') {
      alert('注文送信機能の準備ができていません。ページを再読み込みしてから再度お試しください。');
      return;
    }

    const hasWallDesign = !!cwState.loadedImg;
    const stamp = Date.now();
    const safeName = name.replace(/[\\\/:*?"<>|\s]+/g, '_');

    const sendBtn = $('cc-send-mail');
    if (sendBtn) sendBtn.disabled = true;
    setStatus('', '');

    try {
      const agPsd = await loadAgPsd();

      // ---- ① 床（カーペット）：元画像・変換後画像を実寸(1px=1mm)で個別に生成 ----
      const floorWMm = Math.max(1, Math.round(parseFloat($('cc-width').value) || 1000));
      const floorHMm = Math.max(1, Math.round(parseFloat($('cc-height').value) || 1000));
      const floorDitherEl = $('cc-dither');
      const floorDitherPct = floorDitherEl ? Math.round(parseFloat(floorDitherEl.value) || 0) : 0;
      const floorDitherFactor = Math.min(1, Math.max(0, floorDitherPct / 100));
      const floorActiveEntries = getActivePaletteEntries();

      const { imageData: floorReducedData, usedEntries: floorUsedEntries } =
        getReducedImageData(state.loadedImg, floorWMm, floorHMm, floorDitherFactor, floorActiveEntries, { lut: carpetLut(floorActiveEntries) });
      state.lastUsedColorEntries = floorUsedEntries;
      renderUsedColorsUI(floorUsedEntries);
      const floorColorsText = getUsedColorsSummaryText(floorUsedEntries);

      const floorOriginalCanvas = document.createElement('canvas');
      floorOriginalCanvas.width = state.loadedImg.naturalWidth || state.loadedImg.width;
      floorOriginalCanvas.height = state.loadedImg.naturalHeight || state.loadedImg.height;
      floorOriginalCanvas.getContext('2d').drawImage(state.loadedImg, 0, 0);

      const floorReducedCanvas = document.createElement('canvas');
      floorReducedCanvas.width = floorWMm;
      floorReducedCanvas.height = floorHMm;
      floorReducedCanvas.getContext('2d').putImageData(floorReducedData, 0, 0);

      const floorOriginalBlob = makeSingleLayerPsdBlob(agPsd, floorOriginalCanvas, '床：元画像（オリジナル）');
      const floorReducedBlob = makeSingleLayerPsdBlob(agPsd, floorReducedCanvas, '床：変換後画像（実寸出力・1px=1mm）');
      const floorOriginalFileName = 'floor_original_' + safeName + '_' + stamp + '.psd';
      const floorReducedFileName = 'floor_reduced_' + safeName + '_dither' + floorDitherPct + 'pct_' + stamp + '.psd';

      // ---- ② 壁紙：アップロードされている場合のみ、元画像・変換後画像を実寸で個別に生成 ----
      let wallColorsText = '未設定（壁紙用デザイン画像は未アップロード）';
      let wallDitherPct = 0;
      let wallOriginalBlob = null;
      let wallReducedBlob = null;
      let wallOriginalFileName = '';
      let wallReducedFileName = '';

      if (hasWallDesign) {
        const wallWidthMm = Math.max(1, Math.round(parseFloat($('persp-width')?.value) || 3000));
        const wallHeightMm = Math.max(1, Math.round(parseFloat($('persp-wall-height')?.value) || 2400));
        const wallDitherEl = $('cw-dither');
        wallDitherPct = wallDitherEl ? Math.round(parseFloat(wallDitherEl.value) || 0) : 0;
        const wallDitherFactor = Math.min(1, Math.max(0, wallDitherPct / 100));
        const wallActiveEntries = getWallActivePaletteEntries();

        const wallPlaced = getWallRepeat().on ? tileWallCanvas(cwState.loadedImg, wallWidthMm, wallHeightMm, getWallRepeat().mm) : (getWallRepeat().mode === 'wrap' ? wrapWallCanvas(cwState.loadedImg, wallWidthMm, wallHeightMm) : coverWallCanvas(cwState.loadedImg, wallWidthMm, wallHeightMm));
        let wallReducedData;
        if (isWallReduceOn()) {
          const res = getReducedImageData(wallPlaced, wallWidthMm, wallHeightMm, wallDitherFactor, wallActiveEntries);
          wallReducedData = res.imageData;
          cwState.lastUsedColorEntries = res.usedEntries;
          wallColorsText = getUsedColorsSummaryText(res.usedEntries);
        } else {
          // 減色なし（CMYK印刷）：元画像の色のまま
          wallReducedData = wallPlaced.getContext('2d').getImageData(0, 0, wallWidthMm, wallHeightMm);
          wallColorsText = '減色なし（元画像の色のまま・CMYK印刷）';
          wallDitherPct = 0;
        }

        const wallOriginalCanvas = document.createElement('canvas');
        wallOriginalCanvas.width = cwState.loadedImg.naturalWidth || cwState.loadedImg.width;
        wallOriginalCanvas.height = cwState.loadedImg.naturalHeight || cwState.loadedImg.height;
        wallOriginalCanvas.getContext('2d').drawImage(cwState.loadedImg, 0, 0);

        const wallReducedCanvas = document.createElement('canvas');
        wallReducedCanvas.width = wallWidthMm;
        wallReducedCanvas.height = wallHeightMm;
        wallReducedCanvas.getContext('2d').putImageData(wallReducedData, 0, 0);

        wallOriginalBlob = makeSingleLayerCmykPsdBlob(wallOriginalCanvas, '壁：元画像（オリジナル）');
        wallReducedBlob = makeSingleLayerCmykPsdBlob(wallReducedCanvas, '壁：変換後画像（実寸出力・1px=1mm）');
        wallOriginalFileName = 'wall_original_' + safeName + '_' + stamp + '.psd';
        wallReducedFileName = (isWallReduceOn() ? 'wall_reduced_' + safeName + '_dither' + wallDitherPct + 'pct_' : 'wall_converted_' + safeName + '_noreduce_') + stamp + '.psd';
      }

      // ---- ③ サーバーへアップロード（床2点＋壁2点、壁未設定時は床2点のみ） ----
      debug('デザインデータをサーバーへアップロードしています...しばらくお待ちください。');

      const uploadTasks = [
        DOMailer.uploadDesignFile(floorOriginalBlob, floorOriginalFileName),
        DOMailer.uploadDesignFile(floorReducedBlob, floorReducedFileName)
      ];
      if (hasWallDesign) {
        uploadTasks.push(DOMailer.uploadDesignFile(wallOriginalBlob, wallOriginalFileName));
        uploadTasks.push(DOMailer.uploadDesignFile(wallReducedBlob, wallReducedFileName));
      }

      const uploadResults = await Promise.all(uploadTasks);
      const tokens = uploadResults.map(r => r.token);

      // ---- ④ メール送信（リンクのみ記載・添付なし。床・壁それぞれの階調表現％も記載） ----
      const orderSummary = [
        '注文番号：' + orderNumber,
        '仕様：' + materialText,
        'オプションカラー：' + opCostText,
        '床（カーペット）使用カラー：' + floorColorsText,
        '床（カーペット）階調表現（誤差拡散）：' + floorDitherPct + '%',
        '壁紙 使用カラー：' + wallColorsText,
        '壁紙 階調表現（誤差拡散）：' + (hasWallDesign ? (isWallReduceOn() ? (wallDitherPct + '%') : '減色なし') : '未設定（壁紙用デザイン画像は未アップロード）'),
        '品質基準（マッシュオフィス・2026年01月20日制定）：全文を確認し、同意済み',
        '著作権・商標権・肖像権：侵害しないことを確認済み',
        '壁紙の合計（展開図から）：' + (window.cfpWallTotal ? window.cfpWallTotal.text : '未選択'),
        '制作サイズ：' + sizeText,
        tileCountText,
        'お届け先地域：' + region,
        '商品小計 (税別)：' + subtotal,
        '送料 (税別)：' + shipping,
        '消費税 (10%)：' + tax,
        '合計金額 (税込)：' + total
      ].join('\n');

      debug('ご注文メールを送信しています...');

      await DOMailer.sendOrderEmail(tokens, {
        name: name,
        company: company,
        phone: tel,
        email: email,
        address: address,
        memo: '注文番号：' + orderNumber,
        order_summary: orderSummary,
        need_receipt: needReceipt ? '1' : ''
      });

      setStatus('ok', '✅ ご注文を受け付けました（注文番号：' + orderNumber + '）。ありがとうございます。担当者より折り返しご連絡いたします。');
      debug('注文送信が完了しました。注文番号：' + orderNumber + '（デザインデータ保存期限：60日間）');
    } catch (err) {
      setStatus('err', '❌ 送信に失敗しました：' + err.message + ' 恐れ入りますが、お電話にてご連絡いただくか、時間をおいて再度お試しください。');
      debug('注文送信エラー: ' + err.message, true);
    } finally {
      if (sendBtn) sendBtn.disabled = false;
    }
  }

  function sendDeliveryInquiryMail() {
    const name = $('cc-name') ? $('cc-name').value.trim() : '';
    const recipient = 'mushroomyasu@gmail.com';
    const subject = encodeURIComponent('【納期確認・ご相談】' + (name ? name + '様より' : '') + 'オリジナルカーペットお問い合わせ');
    const body = encodeURIComponent([
      '納期・その他仕上がり、大口、カット等に関するお問い合わせ','',
      'このメールに、下記2点のファイル（必要に応じて）を添付の上、ご返信ください。',
      '① 元データ（オリジナルのデザイン画像ファイル）',
      '② 変換後データ（本ツールでダウンロードしたPSDファイル）','',
      '--------------------------------------------------',
      '※納期はデザイン内容・サイズにより変動いたします。正式なご注文の前に、必ず事前に納期をお問い合わせください。'
    ].join('\n'));
    window.location.href = 'mailto:' + recipient + '?subject=' + subject + '&body=' + body;
  }

  function sendSampleRequestMail(pileTypeName) {
    const name = $('cc-name') ? $('cc-name').value.trim() : '';
    const address = $('cc-address') ? $('cc-address').value.trim() : '';
    const recipient = 'mushroomyasu@gmail.com';
    const subject = encodeURIComponent('【無料サンプル請求】' + pileTypeName + ' サンプルご希望');
    const body = encodeURIComponent([
      pileTypeName + ' の無料サンプルを希望します。','',
      '■ お名前：' + (name || '（ご記入ください）'),
      '■ お届け先ご住所：' + (address || '（ご記入ください）'),
      '■ 電話番号：（ご記入ください）','',
      '--------------------------------------------------',
      '※サンプルの発送には数日お時間をいただく場合がございます。'
    ].join('\n'));
    window.location.href = 'mailto:' + recipient + '?subject=' + subject + '&body=' + body;
  }

  function initApp() {
    document.addEventListener('change', function(e) {
      if (e.target && e.target.id === 'cc-file') {
        const files = e.target.files;
        if (files && files.length > 0) {
          handleFile(files[0]);
        }
      }
      if (e.target && e.target.id === 'cw-file') {
        const files = e.target.files;
        if (files && files.length > 0) {
          handleWallFile(files[0]);
        }
      }
    });

    function snapSize(id) {
      const el = $(id);
      if (!el) return;
      let v = parseFloat(el.value) || 500;
      v = Math.max(500, Math.round(v / 500) * 500);
      el.value = v;
    }

    if ($('cc-material')) $('cc-material').onchange = calculateEstimate;
    // 画像の大きさ（拡大・縮小）：変えたら作り直す（少し待ってまとめて）
    if ($('cc-img-scale')) {
      let scaleTimer = null;
      $('cc-img-scale').oninput = (e) => {
        if ($('cc-img-scale-val')) $('cc-img-scale-val').textContent = e.target.value;
        clearTimeout(scaleTimer);
        scaleTimer = setTimeout(() => { if (state.loadedImg) updateCarpetCanvas(); }, 120);
      };
    }
    if ($('cc-region')) $('cc-region').onchange = calculateEstimate;
    // 元画像を別ウィンドウで表示（ポップアップが止められたときは、この画面の上に大きく表示）
    if ($('cc-show-original')) $('cc-show-original').onclick = () => {
      const img = state.loadedImg;
      if (!img) { alert('先に画像を選択してください。'); return; }
      const w = img.naturalWidth || img.width, h = img.naturalHeight || img.height;
      const title = '元画像（' + w + ' × ' + h + ' px）';
      // 読み込みに使ったURLはもう使えないので、元のファイルから作り直す（ファイルがなければ画像を描き写す）
      let url = '';
      if (state.file) url = URL.createObjectURL(state.file);
      else { const c = document.createElement('canvas'); c.width = w; c.height = h; c.getContext('2d').drawImage(img, 0, 0); url = c.toDataURL('image/png'); }
      if (state.file) setTimeout(() => URL.revokeObjectURL(url), 30 * 60 * 1000);
      const win = window.open('', 'cfp-original', 'width=' + Math.min(1200, Math.max(400, w + 40)) + ',height=' + Math.min(900, Math.max(300, h + 80)) + ',resizable=yes,scrollbars=yes');
      if (win) {
        win.document.open();
        win.document.write('<!doctype html><html lang="ja"><head><meta charset="utf-8"><title>' + title + '</title><style>body{margin:0;background:#18181b;color:#e4e4e7;font:13px sans-serif;text-align:center}p{margin:8px}img{max-width:100%;height:auto;background:repeating-conic-gradient(#ddd 0 25%,#fff 0 50%) 0 0/20px 20px}img.full{max-width:none}</style></head><body><p>' + title + '（画像をクリックすると、実際の大きさ／画面に合わせる を切り替え）</p><img id="im" alt="元画像"></body></html>');
        win.document.close();
        const im = win.document.getElementById('im');
        im.src = url;
        im.onclick = () => im.classList.toggle('full');
        win.focus();
        return;
      }
      const ov = document.createElement('div');
      ov.style.cssText = 'position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;cursor:zoom-out;';
      const im = document.createElement('img');
      im.src = url;
      im.alt = title;
      im.style.cssText = 'max-width:95vw;max-height:92vh;background:#fff;';
      ov.appendChild(im);
      ov.onclick = () => ov.remove();
      document.body.appendChild(ov);
    };
    // お見積もり明細のパイル形状：上の「仕様・パイル形状の選択」と同じにする
    if ($('cc-material2')) $('cc-material2').onchange = (e) => {
      const m = $('cc-material');
      if (!m) return;
      m.value = e.target.value;
      m.dispatchEvent(new Event('change', { bubbles: true }));
    };
    // お届け先ご住所の都道府県から、送料の地域を自動で選ぶ
    if ($('cc-address')) {
      const pickRegion = () => {
        const v = $('cc-address').value.replace(/\s/g, '');
        const note = $('cc-address-region');
        let r = '';
        if (/^沖縄/.test(v)) r = 'okinawa';
        else if (/^(北海道|徳島|香川|愛媛|高知|福岡|佐賀|長崎|熊本|大分|宮崎|鹿児島)/.test(v)) r = 'hokkaido_shikoku_kyushu';
        else if (/^(青森|岩手|宮城|秋田|山形|福島|茨城|栃木|群馬|埼玉|千葉|東京|神奈川|新潟|富山|石川|福井|山梨|長野|岐阜|静岡|愛知|三重|滋賀|京都|大阪|兵庫|奈良|和歌山|鳥取|島根|岡山|広島|山口)/.test(v)) r = 'honshu';
        const sel = $('cc-region');
        if (!r) { if (note) note.textContent = v ? '※都道府県名から入力すると、送料の地域を自動で選びます（いまは「' + (sel ? sel.options[sel.selectedIndex].textContent.split(' (')[0] : '') + '」で計算）。' : '※都道府県から入力すると、送料の地域を自動で選びます。'; return; }
        if (sel ? sel.value !== r : false) { sel.value = r; calculateEstimate(); }
        if (note) note.textContent = '✅ 送料の地域：' + sel.options[sel.selectedIndex].textContent + '（ご住所から自動で選びました）';
      };
      $('cc-address').addEventListener('input', pickRegion);
      $('cc-address').addEventListener('change', pickRegion);
      setTimeout(pickRegion, 0); // 途中保存から再開したときのご住所にも合わせる
    }
    if ($('cc-width')) $('cc-width').oninput = () => { calculateEstimate(); updateCarpetCanvas(); };
    if ($('cc-width')) $('cc-width').onchange = () => { snapSize('cc-width'); calculateEstimate(); updateCarpetCanvas(); };
    if ($('cc-height')) $('cc-height').oninput = () => { calculateEstimate(); updateCarpetCanvas(); };
    if ($('cc-height')) $('cc-height').onchange = () => { snapSize('cc-height'); calculateEstimate(); updateCarpetCanvas(); };
    if ($('cc-dither')) $('cc-dither').oninput = (event) => { if($('cc-dither-val')) $('cc-dither-val').textContent = event.target.value; reprocessReduction(); };
    // 元画像のプレビューの拡大・縮小（ホイール）と移動（ドラッグ）。色を選びやすくするため（表示だけ。画像は変えない）
    const oz = { s: 1, x: 0, y: 0, drag: null, moved: false };
    state.origZoom = oz;
    const ozApply = () => {
      const box = $('cc-orig-zoom'), cv = $('cc-original');
      if (!box || !cv) return;
      const W = box.clientWidth, H = box.clientHeight;
      // はみ出して空白が見えないように、動かせる範囲を制限する
      oz.x = Math.min(0, Math.max(W - W * oz.s, oz.x));
      oz.y = Math.min(0, Math.max(H - H * oz.s, oz.y));
      cv.style.transform = oz.s === 1 ? '' : 'translate(' + oz.x + 'px,' + oz.y + 'px) scale(' + oz.s + ')';
    };
    state.resetOrigZoom = () => { oz.s = 1; oz.x = 0; oz.y = 0; ozApply(); };
    if ($('cc-orig-zoom')) {
      const box = $('cc-orig-zoom');
      box.onwheel = (e) => {
        if (!state.loadedImg) return;
        e.preventDefault();
        const r = box.getBoundingClientRect();
        const mx = e.clientX - r.left, my = e.clientY - r.top;
        const ns = Math.min(16, Math.max(1, oz.s * (e.deltaY < 0 ? 1.25 : 0.8)));
        // カーソルの下の点がそのまま残るように
        oz.x = mx - (mx - oz.x) * ns / oz.s;
        oz.y = my - (my - oz.y) * ns / oz.s;
        oz.s = ns;
        ozApply();
      };
      box.onpointerdown = (e) => { oz.drag = { x: e.clientX, y: e.clientY, ox: oz.x, oy: oz.y }; oz.moved = false; };
      box.onpointermove = (e) => {
        if (!oz.drag) return;
        const dx = e.clientX - oz.drag.x, dy = e.clientY - oz.drag.y;
        if (!oz.moved ? Math.abs(dx) + Math.abs(dy) > 4 : false) { oz.moved = true; try { box.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ } }
        if (!oz.moved) return;
        oz.x = oz.drag.ox + dx; oz.y = oz.drag.oy + dy;
        ozApply();
      };
      box.onpointerup = () => { oz.drag = null; };
      box.onpointercancel = () => { oz.drag = null; };
      box.ondblclick = (e) => { e.preventDefault(); state.resetOrigZoom(); };
    }
    // 守る色：元画像のクリックした所の色（周り3×3の平均）を加える。チップを押すと外す
    const renderProtect = () => {
      const box = $('cc-protect-list');
      if (!box) return;
      box.innerHTML = '';
      (state.protect || []).forEach((c, i) => {
        const chip = document.createElement('button');
        chip.type = 'button';
        chip.className = 'psd-color-chip';
        chip.style.cssText = 'background:rgb(' + c.join(',') + ');border:2px solid #f59e0b;cursor:pointer;position:relative;';
        chip.title = '守る色 rgb(' + c.join(',') + ')：押すと外します';
        chip.textContent = '×';
        chip.style.color = (c[0] * 0.299 + c[1] * 0.587 + c[2] * 0.114) > 140 ? '#000' : '#fff';
        chip.onclick = () => { state.protect.splice(i, 1); renderProtect(); if (state.loadedImg) reprocessReduction(); };
        box.appendChild(chip);
      });
    };
    // （初期化が2回走っても1回だけ動くよう、onclick に入れる）
    let pickTimer = null;
    if ($('cc-original')) $('cc-original').onclick = (e) => {
      if (!state.loadedImg) return;
      if (state.origZoom ? state.origZoom.moved : false) { state.origZoom.moved = false; return; } // ドラッグで動かしたときは色を選ばない
      clearTimeout(pickTimer);
      if (e.detail > 1) return; // ダブルクリック（元の大きさに戻す）では色を選ばない
      const cv = $('cc-original'), r = cv.getBoundingClientRect();
      const x = Math.floor((e.clientX - r.left) / r.width * cv.width), y = Math.floor((e.clientY - r.top) / r.height * cv.height);
      const d = cv.getContext('2d').getImageData(Math.max(0, x - 1), Math.max(0, y - 1), 3, 3).data;
      let n = 0; const sum = [0, 0, 0];
      for (let i = 0; i < d.length; i += 4) { if (d[i + 3] < 128) continue; sum[0] += d[i]; sum[1] += d[i + 1]; sum[2] += d[i + 2]; n++; }
      if (!n) return; // the margin (no colour)
      const c = sum.map((v) => Math.round(v / n));
      pickTimer = setTimeout(() => {
        state.protect = (state.protect || []).concat([c]).slice(-4);
        renderProtect();
        reprocessReduction();
      }, 280);
    };
    // 仕上がりの印象：3通りの変換の色を選び直し、色の割り当てもやり直す
    if ($('cc-look')) $('cc-look').onchange = () => { if (state.loadedImg) reprocessReduction(); };
    // 3つの変換の上のスライダー：上のスライダーと同じ値にして、同じように反映する
    if ($('cc-dither2')) $('cc-dither2').oninput = (event) => {
      const v = event.target.value;
      if ($('cc-dither')) $('cc-dither').value = v;
      if ($('cc-dither-val')) $('cc-dither-val').textContent = v;
      if ($('cc-dither2-val')) $('cc-dither2-val').textContent = v;
      reprocessReduction();
    };
    if ($('cw-reduce-on')) $('cw-reduce-on').addEventListener('change', () => { syncWallReduceUi(); reprocessWallReduction(); });
    syncWallReduceUi();
    if ($('cw-dither')) $('cw-dither').oninput = (event) => { if($('cw-dither-val')) $('cw-dither-val').textContent = event.target.value; reprocessWallReduction(); };
    // 柄の大きさ・繰り返しの切り替え：お部屋パースとCAD表示（3D）に反映
    if ($('cw-repeat-mm')) $('cw-repeat-mm').addEventListener('input', () => { if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated(); });
    const syncSingleUi = () => {
      const on = ($('cw-wall-mode') ? $('cw-wall-mode').value : 'repeat') === 'repeat';
      if ($('cw-single-scale')) $('cw-single-scale').disabled = on;
      if ($('cw-repeat-mm')) $('cw-repeat-mm').disabled = !on;
      if ($('cw-single-scale-val')) $('cw-single-scale-val').textContent = $('cw-single-scale').value;
    };
    syncSingleUi();
    if ($('cw-wall-mode')) $('cw-wall-mode').addEventListener('change', () => { syncSingleUi(); if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated(); });
    if ($('cw-single-scale')) $('cw-single-scale').addEventListener('input', () => { syncSingleUi(); if (typeof onCarpetDesignUpdated === 'function') onCarpetDesignUpdated(); });
    if ($('cc-download-psd')) $('cc-download-psd').onclick = downloadPsd;
    if ($('cc-download-svg')) $('cc-download-svg').onclick = downloadCarpetSvg;
    if ($('btn-save-floor-image')) $('btn-save-floor-image').onclick = downloadFloorImagePng;
    if ($('btn-save-wall-image')) $('btn-save-wall-image').onclick = downloadWallImagePsd;
    if ($('btn-save-wall-print')) $('btn-save-wall-print').onclick = downloadWallPrintStrips;
    if ($('cc-send-mail')) $('cc-send-mail').onclick = sendOrderMail;
    // 品質基準：全文を最後までスクロールして読むと、チェックできる
    const qDoc = $('cc-quality-doc'), qChk = $('cc-quality-ok'), qBtn = $('cc-quality-open'), qSt = $('cc-quality-status');
    // initApp runs twice on purpose (now and after 300 ms): bind only once
    if (qDoc && qChk && qBtn && !qBtn.dataset.bound) {
      qBtn.dataset.bound = '1';
      const markRead = () => {
        qChk.disabled = false;
        if (qSt) { qSt.textContent = '✅ 最後まで読みました。チェックできます。'; qSt.className = 'cfp-qs-status is-ok'; }
      };
      const atEnd = () => qDoc.scrollTop + qDoc.clientHeight >= qDoc.scrollHeight - 6;
      qBtn.addEventListener('click', () => {
        qDoc.hidden = !qDoc.hidden;
        qChk.closest('.cfp-agree-box').classList.toggle('is-open', !qDoc.hidden);
        qBtn.textContent = qDoc.hidden ? '📄 品質基準を読む（最後までスクロールするとチェックできます）' : '📄 品質基準を閉じる';
        if (!qDoc.hidden) { qDoc.focus({ preventScroll: true }); if (atEnd()) markRead(); }
      });
      qDoc.addEventListener('scroll', () => { if (atEnd()) markRead(); });
      // 未読のままチェック欄を押したときは、読むように案内する
      qChk.closest('.cfp-agree-box').addEventListener('click', (e) => {
        if (qChk.disabled && !e.target.closest('button') && !e.target.closest('.cfp-qs')) {
          if (qSt) { qSt.textContent = '⚠ 先に「品質基準を読む」を押して、最後までスクロールしてください。'; qSt.className = 'cfp-qs-status'; }
          if (qDoc.hidden) qBtn.click();
        }
      });
    }
    if ($('cc-delivery-inquiry')) $('cc-delivery-inquiry').onclick = sendDeliveryInquiryMail;
    if ($('cc-sample-loop')) $('cc-sample-loop').onclick = () => sendSampleRequestMail('ループパイル');
    if ($('cc-sample-cut')) $('cc-sample-cut').onclick = () => sendSampleRequestMail('カットパイル');

    document.querySelectorAll('[data-var-btn]').forEach((b) => {
      if (!b.dataset.bound) { b.dataset.bound = '1'; b.addEventListener('click', () => applyVariant(b.getAttribute('data-var-btn'))); }
    });
    // カラーパレットの版：開くたびに旧パレットから始める（新パレットはボタンで切り替え）。チップを作る前に色を入れ替える
    applyPaletteVersion('old', true);
    initPalette();
    initWallPalette();
    document.querySelectorAll('.cfp-palver-btn').forEach((b) => { b.onclick = () => applyPaletteVersion(b.getAttribute('data-palver')); });
    applyPaletteVersion(paletteVersion, true);
    if ($('cc-palette-version')) $('cc-palette-version').onchange = () => { if ($('cc-palette-version').value !== paletteVersion) applyPaletteVersion($('cc-palette-version').value); };
    calculateEstimate();
    debug('システム待機中... 画像を選択してください。');

    // 作業の途中保存・再開（assets/js/resume.js）から使う
    window.cfpToolApi = {
      files: () => ({ floor: state.file || null, wall: cwState.file || null }),
      palettes: () => ({ carpet: Array.from(state.activePaletteIndices), wall: Array.from(cwState.activePaletteIndices) }),
      setPalettes: (p) => {
        const apply = (set, list, baseId, opId) => {
          if (!Array.isArray(list)) return;
          set.clear();
          list.forEach((i) => set.add(i));
          const base = $(baseId), op = $(opId);
          if (base) Array.from(base.children).forEach((el, i) => el.classList.toggle('active', set.has(i)));
          if (op) Array.from(op.children).forEach((el, j) => el.classList.toggle('active', set.has(FREE_PALETTE.length + j)));
        };
        apply(state.activePaletteIndices, p ? p.carpet : null, 'cc-base-palette-selector', 'cc-op-palette-selector');
        apply(cwState.activePaletteIndices, p ? p.wall : null, 'cw-base-palette-selector', 'cw-op-palette-selector');
        reprocessReduction();
        reprocessWallReduction();
        calculateEstimate();
      },
      loadFloor: (file) => new Promise((resolve) => { state.skipAutoVariant = true; handleFile(file, resolve); setTimeout(resolve, 15000); }),
      loadWall: (file) => new Promise((resolve) => { handleWallFile(file, resolve); setTimeout(resolve, 15000); }),
      refresh: () => {
        syncWallReduceUi();
        syncSingleUi();
        calculateEstimate();
        updateCarpetCanvas();
        reprocessWallReduction();
      }
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
  setTimeout(initApp, 300);
})();
</script>

<script>
(function () {
  'use strict';
  if (window.__cocoonPerspInitialized) return;
  window.__cocoonPerspInitialized = true;

  const $ = (id) => document.getElementById(id);

  const perspState = {
    vAngle: 30,          // 縦回転（ボックス全体の rotateX）
    hAngle: 25,          // 横回転（ボックス全体の rotateY）
    widthMm: 3000,       // お部屋の幅（壁の横幅・床の横幅で共通）
    wallHeightMm: 2400,  // 壁の高さ
    floorDepthMm: 2500,  // 床の奥行き
    zoom: 1              // 拡大率（ドラッグ・ホイールで操作）
  };

  function getReducedCanvas(id) {
    const c = document.getElementById(id);
    if (c && c.width > 0 && c.height > 0) return c;
    return null;
  }

  // 画像は繰り返さず、各面1枚をそのまま伸縮して表示する
  function applyPlaneImage(el, canvas) {
    if (!el) return;
    if (canvas) {
      try {
        el.style.backgroundImage = 'url(' + canvas.toDataURL('image/png') + ')';
      } catch (err) {
        console.error('[パース表示] 画像の反映に失敗しました', err);
      }
    } else {
      el.style.backgroundImage = 'none';
    }
  }

  // 壁・床・側面壁を「1つの剛体の箱」として組み立てる。
  // 各面はお互いの辺を共有するように厳密に配置しているため、箱ごと回転させても
  // 継ぎ目にズレ・隙間が生じない（以前の「面ごとに別々の回転」方式で起きていた
  // 「側面の壁と床が噛み合わない」問題を、3D空間上で辺を一致させることで解消）。
  function layoutRoom() {
    const room = $('persp-room');
    const box = $('persp-box');
    const geo = $('persp-geo');
    const backWall = $('persp-back-wall');
    const floor = $('persp-floor');
    const sideWall = $('persp-side-wall');
    if (!room || !box || !geo || !backWall || !floor || !sideWall) return;

    const containerW = room.clientWidth || 640;
    const containerH = room.clientHeight || 360;

    const widthMm = Math.max(1, perspState.widthMm);
    const wallHeightMm = Math.max(1, perspState.wallHeightMm);
    const floorDepthMm = Math.max(1, perspState.floorDepthMm);

    // プレビュー枠に収まるよう、幅・高さの両方でスケールを決める
    const marginPx = 50;
    const availW = containerW - marginPx;
    const availH = containerH - marginPx;
    const scaleByWidth = availW / widthMm;
    // 奥行きは奥へ傾いて見えるため、高さの見積もりでは少なめに評価する
    const scaleByHeight = availH / (wallHeightMm + floorDepthMm * 0.7);
    const scale = Math.max(0.001, Math.min(scaleByWidth, scaleByHeight));

    const Wpx = widthMm * scale;   // 部屋の幅
    const Hpx = wallHeightMm * scale; // 壁の高さ
    const Dpx = floorDepthMm * scale; // 床の奥行き

    // 奥の壁：X:0..W, Y:0..H, Z=0 の平面（回転なし）
    backWall.style.left = '0px';
    backWall.style.top = '0px';
    backWall.style.width = Wpx + 'px';
    backWall.style.height = Hpx + 'px';
    backWall.style.transformOrigin = '0 0';
    backWall.style.transform = 'translateZ(0px)';

    // 床：壁の下端(Y=H)を軸に奥（-Z方向）へ90°折り曲げる。X:0..W, Y=H, Z:0..-D
    floor.style.left = '0px';
    floor.style.top = '0px';
    floor.style.width = Wpx + 'px';
    floor.style.height = Dpx + 'px';
    floor.style.transformOrigin = '0 0';
    floor.style.transform = 'translate3d(0px, ' + Hpx + 'px, 0px) rotateX(-90deg)';

    // 側面の壁：奥の壁の左端(X=0)を軸に奥（-Z方向）へ90°折り曲げる。X=0, Y:0..H, Z:0..-D
    // → 床・奥の壁と3辺すべてを共有する形になるため、隙間が生じない
    sideWall.style.left = '0px';
    sideWall.style.top = '0px';
    sideWall.style.width = Dpx + 'px';
    sideWall.style.height = Hpx + 'px';
    sideWall.style.transformOrigin = '0 0';
    sideWall.style.transform = 'rotateY(90deg)';

    // 壁紙の柄（縦横比は常に保つ）。横の壁は、画像を左右反転して渡しているので（applyPlaneImage）、
    // 室内から見た向きが奥の壁とそろう。要素の左端(x=0)が奥の壁との角。
    const wallRepeat = window.cfpGetWallRepeat ? window.cfpGetWallRepeat() : { on: false, mode: 'center', mm: 910, scale: 1 };
    const wsrc = document.getElementById('cw-reduced');
    const aspect = wsrc ? (wsrc.width ? wsrc.width / wsrc.height : 1) : 1;
    const setBg = (el, size, pos, repeat, white) => {
      el.style.backgroundSize = size;
      el.style.backgroundPosition = pos;
      el.style.backgroundRepeat = repeat;
      el.style.backgroundColor = white ? '#ffffff' : '';
    };
    // 「壁紙の巾の枠」で画像を動かした量（mm）。横の壁は左右反転して貼っているので、横方向は逆向きにずらす
    const sh = window.cfpWallShift || { x: 0, y: 0 };
    const sx = sh.x * scale, sy = sh.y * scale, ss = sh.s || 1; // ss: 画像の大きさ
    if (wallRepeat.mode === 'repeat') {
      // 角を柄の区切りにして、奥の壁は右へ、横の壁は左へ続ける（天井から）
      const size = Math.max(2, wallRepeat.mm * scale * ss) + 'px auto';
      setBg(backWall, size, sx + 'px ' + sy + 'px', 'repeat', false);
      setBg(sideWall, size, (-sx) + 'px ' + sy + 'px', 'repeat', false);
    } else if (wallRepeat.mode === 'wrap') {
      // 横の壁（奥行 D）→ 奥の壁（幅 W）を1本の帯として、1枚の画像を途切れずに貼る
      const b = window.cfpWrapBand ? window.cfpWrapBand(aspect) : { D: floorDepthMm, iw: widthMm + floorDepthMm, ih: (widthMm + floorDepthMm) / aspect, s0: 0 };
      const size = Math.max(2, b.iw * scale) + 'px auto';
      const gx = 0; // 大きさは wrapBand（画像の大きさの設定）に含まれる
      const y = (((wallHeightMm - b.ih) / 2) * scale + sy) + 'px';
      setBg(backWall, size, ((b.s0 - b.D) * scale - gx + sx) + 'px ' + y, 'no-repeat', !!wsrc);
      setBg(sideWall, size, ((b.D - b.iw - b.s0) * scale - gx - sx) + 'px ' + y, 'no-repeat', !!wsrc);
    } else {
      // 1枚を壁ごとに中央（どの壁でも同じ大きさ）
      const iw = window.cfpSingleImageWidthMm ? window.cfpSingleImageWidthMm(aspect) : Math.max(widthMm, floorDepthMm, wallHeightMm * aspect);
      const size = Math.max(2, iw * scale) + 'px auto';
      setBg(backWall, size, 'calc(50% + ' + sx + 'px) calc(50% + ' + sy + 'px)', 'no-repeat', !!wsrc);
      setBg(sideWall, size, 'calc(50% + ' + (-sx) + 'px) calc(50% + ' + sy + 'px)', 'no-repeat', !!wsrc);
    }
    if (window.cfpUpdateWallRepeatNote) window.cfpUpdateWallRepeatNote();

    // ジオメトリ全体（3面）を、部屋の中心点が原点(0,0,0)に来るよう平行移動する。
    // こうしておくことで、box側の回転軸は常に「部屋の中心」に固定され、
    // 幅・高さ・奥行きの数値やスライダーの角度に関わらず回転で画面外にズレなくなる。
    geo.style.transform = 'translate3d(' + (-Wpx / 2) + 'px, ' + (-Hpx / 2) + 'px, ' + (Dpx / 2) + 'px)';

    // 箱（box）自体は常にプレビュー枠の中心（0サイズの点）に置き、原点まわりで回転させるだけにする
    box.style.transform = 'scale(' + perspState.zoom + ') rotateX(' + perspState.vAngle + 'deg) rotateY(' + perspState.hAngle + 'deg)';
  }

  function updatePerspectiveRoom() {
    const carpetCanvas = getReducedCanvas('cc-reduced');
    const wallCanvas = getReducedCanvas('cw-reduced');

    applyPlaneImage($('persp-floor'), carpetCanvas);
    applyPlaneImage($('persp-back-wall'), wallCanvas);
    // 横の壁は裏側から見える向きに回転しているため、左右反転した画像を貼って室内から正しい向きに見せる
    let mirrored = null;
    if (wallCanvas) {
      mirrored = document.createElement('canvas');
      mirrored.width = wallCanvas.width;
      mirrored.height = wallCanvas.height;
      const mctx = mirrored.getContext('2d');
      mctx.translate(mirrored.width, 0);
      mctx.scale(-1, 1);
      mctx.drawImage(wallCanvas, 0, 0);
    }
    applyPlaneImage($('persp-side-wall'), mirrored);
    layoutRoom();

    const statusEl = $('persp-status');
    if (statusEl) {
      if (!carpetCanvas && !wallCanvas) {
        statusEl.textContent = '①・②でデザイン画像を処理すると、ここに自動反映されます。';
      } else if (carpetCanvas && !wallCanvas) {
        statusEl.textContent = '床（①カーペット用）のみ反映されています。壁の柄は「② 壁紙用デザイン」を処理すると反映されます。';
      } else if (!carpetCanvas && wallCanvas) {
        statusEl.textContent = '壁（②壁紙用）のみ反映されています。床の柄は「① カーペット用デザイン」を処理すると反映されます。';
      } else {
        statusEl.textContent = '✅ 床・壁ともにパースへ反映されています。';
      }
    }
    // CAD表示（cad-floor-plan）にも床・壁の変換後画像を反映させるための通知
    document.dispatchEvent(new Event('cfp:designs-updated'));
  }

  // 上のカーペット用・壁紙用デザインが再処理される（減色・パレット・サイズ変更の）たびに、
  // このパース表示を自動更新する
  window.onCarpetDesignUpdated = updatePerspectiveRoom;
  window.cfpLayoutPersp = layoutRoom; // 画像の位置だけが変わったとき（壁紙の巾の枠で画像を移動）

  let resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(layoutRoom, 150);
  });

  function initPerspective() {
    const vAngleEl = $('persp-vangle');
    const vAngleVal = $('persp-vangle-val');
    if (vAngleEl) {
      vAngleEl.oninput = () => {
        perspState.vAngle = parseFloat(vAngleEl.value) || 0;
        if (vAngleVal) vAngleVal.textContent = vAngleEl.value;
        layoutRoom();
      };
    }

    const hAngleEl = $('persp-hangle');
    const hAngleVal = $('persp-hangle-val');
    if (hAngleEl) {
      hAngleEl.oninput = () => {
        perspState.hAngle = parseFloat(hAngleEl.value) || 0;
        if (hAngleVal) hAngleVal.textContent = hAngleEl.value;
        layoutRoom();
      };
    }

    const widthEl = $('persp-width');
    if (widthEl) {
      widthEl.oninput = () => {
        perspState.widthMm = parseFloat(widthEl.value) || 3000;
        layoutRoom();
      };
    }

    const wallHeightEl = $('persp-wall-height');
    if (wallHeightEl) {
      wallHeightEl.oninput = () => {
        perspState.wallHeightMm = parseFloat(wallHeightEl.value) || 2400;
        layoutRoom();
      };
    }

    const floorDepthEl = $('persp-floor-depth');
    if (floorDepthEl) {
      floorDepthEl.oninput = () => {
        perspState.floorDepthMm = parseFloat(floorDepthEl.value) || 2500;
        layoutRoom();
      };
    }

    // CADお部屋シミュレーションと同じく、パースをドラッグで回転、ホイール（スマホは2本指）で拡大縮小、ダブルクリックで元に戻す
    const roomEl = $('persp-room');
    if (roomEl) {
      roomEl.style.cursor = 'grab';
      roomEl.style.touchAction = 'none';
      const pointers = new Map();
      let pinch = 0;
      const clampAngle = (v) => Math.max(-70, Math.min(70, v));
      const syncSliders = () => {
        if (vAngleEl) vAngleEl.value = Math.round(perspState.vAngle);
        if (vAngleVal) vAngleVal.textContent = Math.round(perspState.vAngle);
        if (hAngleEl) hAngleEl.value = Math.round(perspState.hAngle);
        if (hAngleVal) hAngleVal.textContent = Math.round(perspState.hAngle);
      };
      const dist = () => { const p = Array.from(pointers.values()); return Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y); };
      roomEl.addEventListener('pointerdown', (e) => {
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        roomEl.setPointerCapture(e.pointerId);
        roomEl.style.cursor = 'grabbing';
        if (pointers.size === 2) pinch = dist();
      });
      roomEl.addEventListener('pointermove', (e) => {
        const prev = pointers.get(e.pointerId);
        if (!prev) return;
        pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
        if (pointers.size === 2) {
          const d = dist();
          if (pinch) perspState.zoom = Math.max(0.4, Math.min(3, perspState.zoom * d / pinch));
          pinch = d;
        } else {
          perspState.hAngle = clampAngle(perspState.hAngle + (e.clientX - prev.x) * 0.4);
          perspState.vAngle = clampAngle(perspState.vAngle - (e.clientY - prev.y) * 0.4);
          syncSliders();
        }
        layoutRoom();
      });
      const up = (e) => {
        pointers.delete(e.pointerId);
        if (pointers.size < 2) pinch = 0;
        if (!pointers.size) roomEl.style.cursor = 'grab';
      };
      roomEl.addEventListener('pointerup', up);
      roomEl.addEventListener('pointercancel', up);
      roomEl.addEventListener('wheel', (e) => {
        e.preventDefault();
        perspState.zoom = Math.max(0.4, Math.min(3, perspState.zoom * (e.deltaY < 0 ? 1.1 : 0.9)));
        layoutRoom();
      }, { passive: false });
      roomEl.addEventListener('dblclick', () => {
        perspState.zoom = 1;
        perspState.vAngle = 30;
        perspState.hAngle = 25;
        syncSliders();
        layoutRoom();
      });
    }

    // 折りたたみを開いたときに、表示の大きさを計算し直す（閉じている間は幅が0のため）
    const fold = $('persp-fold');
    if (fold) fold.addEventListener('toggle', () => { if (fold.open) layoutRoom(); });

    updatePerspectiveRoom();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPerspective);
  } else {
    initPerspective();
  }
})();
</script>
