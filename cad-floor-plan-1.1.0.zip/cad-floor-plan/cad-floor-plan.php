<?php
/**
 * Plugin Name: CAD Floor Plan 3D Simulator
 * Plugin URI: https://github.com/mushroomyasuyuki/-
 * Description: DXF / ベクターPDF / JSON の間取りデータを読み込み、ブラウザ上で3D表示して床・壁の面積を計算します。有効化すると専用の固定ページを自動作成します。
 * Version: 1.1.0
 * Author: mushroomyasuyuki
 * License: MIT
 * Text Domain: cad-floor-plan
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('CFP_VERSION', '1.1.0');
define('CFP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CFP_PAGE_SLUG', 'cad-floor-plan');
define('CFP_SHORTCODE', 'cad_floor_plan');

final class CAD_Floor_Plan_Plugin {
    private static $instance = null;
    private $assets_enqueued = false;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'maybe_upgrade']);
        add_action('wp_enqueue_scripts', [$this, 'maybe_enqueue_assets']);
        add_shortcode(CFP_SHORTCODE, [$this, 'render_shortcode']);
        add_action('rest_api_init', [$this, 'register_rest']);
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_post_cfp_create_page', [$this, 'handle_create_page']);
    }

    /* ---------------------------------------------------------- versioning */

    public function maybe_upgrade() {
        $stored = get_option('cad_floor_plan_version');
        if ($stored === CFP_VERSION) {
            return;
        }
        // Version-specific migrations go here, keyed on $stored.
        update_option('cad_floor_plan_version', CFP_VERSION);
    }

    /* ------------------------------------------------------------- the page */

    /**
     * Returns the ID of the simulator page, creating it if it does not exist.
     */
    public static function ensure_page() {
        $id = (int) get_option('cad_floor_plan_page_id');
        if ($id) {
            $page = get_post($id);
            if ($page && $page->post_type === 'page' && $page->post_status !== 'trash') {
                return $id;
            }
        }

        $existing = get_page_by_path(CFP_PAGE_SLUG);
        if ($existing && $existing->post_status !== 'trash' && has_shortcode($existing->post_content, CFP_SHORTCODE)) {
            update_option('cad_floor_plan_page_id', $existing->ID);
            return (int) $existing->ID;
        }

        $new_id = wp_insert_post([
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_title'   => 'CADお部屋シミュレーション',
            'post_name'    => CFP_PAGE_SLUG,
            'post_content' => '<!-- wp:shortcode -->[' . CFP_SHORTCODE . ']<!-- /wp:shortcode -->',
        ], true);

        if (is_wp_error($new_id)) {
            return 0;
        }
        update_option('cad_floor_plan_page_id', $new_id);
        return (int) $new_id;
    }

    public function handle_create_page() {
        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('権限がありません。', 'cad-floor-plan'), 403);
        }
        check_admin_referer('cfp_create_page');
        $id = self::ensure_page();
        wp_safe_redirect(add_query_arg(
            ['page' => 'cad-floor-plan', 'cfp_page' => $id ? 'ok' : 'error'],
            admin_url('admin.php')
        ));
        exit;
    }

    /* --------------------------------------------------------------- assets */

    public function maybe_enqueue_assets() {
        $post = get_post();
        if ($post && has_shortcode($post->post_content, CFP_SHORTCODE)) {
            $this->enqueue_assets();
        }
    }

    private function enqueue_assets() {
        if ($this->assets_enqueued) {
            return;
        }
        $this->assets_enqueued = true;

        wp_enqueue_style('cfp-style', CFP_PLUGIN_URL . 'assets/css/style.css', [], CFP_VERSION);

        wp_register_script('cfp-three', 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js', [], '128', true);
        wp_register_script('cfp-parser', CFP_PLUGIN_URL . 'assets/js/cad-parser.js', [], CFP_VERSION, true);
        wp_register_script('cfp-renderer', CFP_PLUGIN_URL . 'assets/js/three-room-renderer.js', ['cfp-three', 'cfp-parser'], CFP_VERSION, true);
        wp_register_script('cfp-main', CFP_PLUGIN_URL . 'assets/js/main.js', ['cfp-renderer'], CFP_VERSION, true);

        wp_localize_script('cfp-parser', 'cadFloorPlanData', [
            'pdfJsUrl'     => apply_filters('cad_floor_plan_pdfjs_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js'),
            'pdfWorkerUrl' => apply_filters('cad_floor_plan_pdfjs_worker_url', 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'),
            'version'      => CFP_VERSION,
        ]);

        wp_enqueue_script('cfp-main');
    }

    /* ------------------------------------------------------------ shortcode */

    public function render_shortcode($atts) {
        $atts = shortcode_atts([
            'width'  => '',
            'height' => '600',
            'sample' => 'default',
        ], $atts, CFP_SHORTCODE);

        $this->enqueue_assets();

        $style = $atts['width'] !== '' ? 'max-width:' . absint($atts['width']) . 'px;' : '';

        ob_start();
        ?>
        <div class="cad-floor-plan-widget" data-height="<?php echo esc_attr(absint($atts['height'])); ?>" data-sample="<?php echo esc_attr($atts['sample']); ?>"<?php echo $style ? ' style="' . esc_attr($style) . '"' : ''; ?>>
            <div class="cfp-container">
                <div class="cfp-header">
                    <h2>CADお部屋シミュレーション</h2>
                    <p>DXF / PDF（ベクター）/ JSON の間取りを3D表示し、床・壁の面積を計算します</p>
                </div>

                <div class="cfp-input-area">
                    <div class="cfp-drop" data-cfp="drop">
                        <span class="cfp-drop-title">ファイルをドロップ、またはクリックして選択</span>
                        <input type="file" data-cfp="file" accept=".dxf,.pdf,.json">
                        <div class="cfp-drop-note">対応形式: DXF / PDF（ベクター）/ JSON<br>DWGはDXFに書き出してください</div>
                    </div>
                    <div class="cfp-info-panel">
                        <div class="cfp-info-row"><span class="cfp-label">ファイル</span><span class="cfp-value" data-cfp="filename">未選択</span></div>
                        <div class="cfp-info-row"><span class="cfp-label">床面積</span><span class="cfp-value" data-cfp="floor-area">-</span></div>
                        <div class="cfp-info-row"><span class="cfp-label">壁面積</span><span class="cfp-value" data-cfp="wall-area">-</span></div>
                        <div class="cfp-info-row"><span class="cfp-label">部屋数</span><span class="cfp-value" data-cfp="room-count">0</span></div>
                    </div>
                </div>

                <div class="cfp-options">
                    <label>PDFの縮尺（1:N の N）
                        <input type="number" data-cfp="scale" min="1" step="1" value="1">
                    </label>
                    <label>床デザイン画像
                        <input type="file" data-cfp="floor-tex" accept="image/*">
                    </label>
                    <label>壁紙デザイン画像
                        <input type="file" data-cfp="wall-tex" accept="image/*">
                    </label>
                </div>

                <div class="cfp-status" data-cfp="status"></div>
                <div class="cfp-canvas" data-cfp="canvas"></div>
                <p class="cfp-hint">ドラッグで回転、ホイールで拡大縮小</p>

                <div class="cfp-controls">
                    <button type="button" class="cfp-btn" data-cfp="sample-btn">サンプル</button>
                    <button type="button" class="cfp-btn" data-cfp="reset-btn">視点をリセット</button>
                    <button type="button" class="cfp-btn" data-cfp="save-btn">解析結果をJSON保存</button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ------------------------------------------------------------- REST API */

    public function register_rest() {
        register_rest_route('cad-floor-plan/v1', '/info', [
            'methods'             => 'GET',
            'callback'            => function () {
                return rest_ensure_response([
                    'name'              => 'CAD Floor Plan 3D Simulator',
                    'version'           => CFP_VERSION,
                    'supported_formats' => ['dxf', 'pdf', 'json'],
                ]);
            },
            'permission_callback' => '__return_true',
        ]);
    }

    /* ---------------------------------------------------------------- admin */

    public function add_admin_menu() {
        add_menu_page('CAD Floor Plan', 'CAD Floor Plan', 'manage_options', 'cad-floor-plan', [$this, 'render_admin_page'], 'dashicons-layout', 30);
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        $page_id = (int) get_option('cad_floor_plan_page_id');
        $page    = $page_id ? get_post($page_id) : null;
        $exists  = $page && $page->post_status !== 'trash';
        $result  = isset($_GET['cfp_page']) ? sanitize_key($_GET['cfp_page']) : '';
        ?>
        <div class="wrap">
            <h1>CAD Floor Plan 3D Simulator <small>v<?php echo esc_html(CFP_VERSION); ?></small></h1>

            <?php if ($result === 'ok') : ?>
                <div class="notice notice-success"><p>固定ページを用意しました。</p></div>
            <?php elseif ($result === 'error') : ?>
                <div class="notice notice-error"><p>固定ページを作成できませんでした。</p></div>
            <?php endif; ?>

            <h2>固定ページ</h2>
            <?php if ($exists) : ?>
                <p>
                    <a href="<?php echo esc_url(get_permalink($page_id)); ?>" target="_blank" rel="noopener">表示</a> |
                    <a href="<?php echo esc_url(get_edit_post_link($page_id)); ?>">編集</a>
                    （<?php echo esc_html(get_the_title($page_id)); ?>）
                </p>
            <?php else : ?>
                <p>固定ページがありません。下のボタンで作成できます。</p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="cfp_create_page">
                <?php wp_nonce_field('cfp_create_page'); ?>
                <?php submit_button($exists ? '固定ページは作成済みです' : '固定ページを作成', 'primary', 'submit', false, $exists ? ['disabled' => 'disabled'] : null); ?>
            </form>

            <h2>ショートコード</h2>
            <p>任意のページ・投稿に <code>[cad_floor_plan]</code> を貼ると表示できます。</p>
            <table class="widefat" style="max-width:640px">
                <thead><tr><th>属性</th><th>既定値</th><th>説明</th></tr></thead>
                <tbody>
                    <tr><td><code>height</code></td><td>600</td><td>3D表示エリアの高さ（px）</td></tr>
                    <tr><td><code>width</code></td><td>（なし）</td><td>最大幅（px）。省略すると幅いっぱい</td></tr>
                    <tr><td><code>sample</code></td><td>default</td><td><code>none</code> でサンプル非表示</td></tr>
                </tbody>
            </table>
        </div>
        <?php
    }
}

add_action('plugins_loaded', ['CAD_Floor_Plan_Plugin', 'instance']);

register_activation_hook(__FILE__, function () {
    update_option('cad_floor_plan_version', CFP_VERSION);
    CAD_Floor_Plan_Plugin::ensure_page();
});
