<?php
/**
 * テナントを特定する前に必要な、システム用のデータ操作（テナント絞り込みなし）。
 * ログイン・登録・トークン・定期処理など、限られた用途でのみ使う。
 * 画面・APIのデータ操作には SS_Repo（テナントで必ず絞り込む）を使うこと。
 */

if (!defined('ABSPATH')) {
    exit;
}

final class SS_System {
    public static function table($name) {
        global $wpdb;
        return $wpdb->prefix . 'shift_' . preg_replace('/[^a-z_]/', '', $name);
    }

    public static function now() {
        return gmdate('Y-m-d H:i:s');
    }

    public static function tenant_by_id($id) {
        global $wpdb;
        $t = self::table('tenants');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d AND deleted_at IS NULL", (int) $id), ARRAY_A);
    }

    public static function tenant_by_public_id($public_id) {
        global $wpdb;
        $t = self::table('tenants');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE public_id = %s AND deleted_at IS NULL", (string) $public_id), ARRAY_A);
    }

    public static function user_by_wp_id($wp_user_id) {
        global $wpdb;
        $t = self::table('users');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE wp_user_id = %d", (int) $wp_user_id), ARRAY_A);
    }

    /** 署名つきURLの確認用：画像の行を、お客様を問わずIDで探す（呼び出し側で、必ず署名を確かめること） */
    public static function task_image_by_id($id) {
        global $wpdb;
        $t = self::table('task_images');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", (int) $id), ARRAY_A);
    }

    /** 署名つきURLの確認用：税額表などの元のファイルの行を、お客様を問わずIDで探す（呼び出し側で、必ず署名を確かめること） */
    public static function pay_table_by_id($id) {
        global $wpdb;
        $t = self::table('pay_tables');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d AND tenant_id > 0", (int) $id), ARRAY_A);
    }

    /** 運営者が用意した、全お客様に共通の税額表・保険料額表（tenant_id = 0。お客様からは読むだけ） */
    public static function shared_pay_tables($kind) {
        global $wpdb;
        $t = self::table('pay_tables');
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE tenant_id = 0 AND kind = %s ORDER BY fiscal_year DESC, id DESC LIMIT 200", (string) $kind), ARRAY_A);
    }

    /**
     * 運営者の操作：あるお客様が登録した税額表・保険料額表を、全お客様の共通の表として写す（元のファイルは写さない）。
     * 同じ種類・年度・地域・題名の共通の表は、置き換える。写した件数を返す。
     */
    public static function share_pay_tables($tenant_id) {
        global $wpdb;
        $t = self::table('pay_tables');
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE tenant_id = %d", (int) $tenant_id), ARRAY_A);
        $n = 0;
        foreach ((array) $rows as $r) {
            if ((int) $tenant_id <= 0) {
                break;
            }
            $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE tenant_id = 0 AND kind = %s AND fiscal_year = %d AND region = %s AND title = %s", $r['kind'], (int) $r['fiscal_year'], $r['region'], $r['title']));
            $wpdb->insert($t, array('tenant_id' => 0, 'kind' => $r['kind'], 'fiscal_year' => (int) $r['fiscal_year'], 'region' => $r['region'], 'title' => $r['title'],
                'file_name' => '', 'file_path' => '', 'mime' => '', 'data_json' => $r['data_json'], 'uploaded_by' => '運営者', 'created_at' => self::now()));
            $n++;
        }
        return $n;
    }

    public static function delete_shared_pay_table($id) {
        global $wpdb;
        return (bool) $wpdb->delete(self::table('pay_tables'), array('id' => (int) $id, 'tenant_id' => 0));
    }

    /** 署名つきURLの確認用：自社情報の書類・印影の行を、お客様を問わずIDで探す（呼び出し側で、必ず署名を確かめること） */
    public static function company_document_by_id($id) {
        global $wpdb;
        $t = self::table('company_documents');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", (int) $id), ARRAY_A);
    }

    public static function user_by_id($id) {
        global $wpdb;
        $t = self::table('users');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE id = %d", (int) $id), ARRAY_A);
    }

    /** URLに使う、推測しにくい12文字のお客様ID */
    public static function new_public_id() {
        $chars = 'abcdefghjkmnpqrstuvwxyz23456789';
        $max = strlen($chars) - 1;
        for ($tries = 0; $tries < 10; $tries++) {
            $id = '';
            for ($i = 0; $i < 12; $i++) {
                $id .= $chars[random_int(0, $max)];
            }
            if (!self::tenant_by_public_id($id)) {
                return $id;
            }
        }
        return '';
    }

    /** 1回限りのトークンを作る。平文は返り値のみ、DBにはハッシュを保存する。 */
    public static function create_token($user_id, $tenant_id, $type, $ttl_seconds) {
        global $wpdb;
        $raw = bin2hex(random_bytes(32)); // 64文字
        $wpdb->insert(self::table('tokens'), array(
            'tenant_id'  => (int) $tenant_id,
            'user_id'    => (int) $user_id,
            'type'       => $type,
            'token_hash' => hash('sha256', $raw),
            'expires_at' => gmdate('Y-m-d H:i:s', time() + (int) $ttl_seconds),
            'created_at' => self::now(),
        ));
        return $raw;
    }

    /** 有効なトークンの内容を取得（使用済みにはしない）。 */
    public static function peek_token($raw, $type) {
        global $wpdb;
        if (!preg_match('/^[a-f0-9]{64}$/', (string) $raw)) {
            return null;
        }
        $t = self::table('tokens');
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$t} WHERE token_hash = %s AND type = %s AND used_at IS NULL AND expires_at > %s",
            hash('sha256', $raw), $type, self::now()
        ), ARRAY_A);
        return $row ? $row : null;
    }

    /** トークンを使用済みにする。同時に2回使われても1回しか成功しない。 */
    public static function consume_token($raw, $type) {
        global $wpdb;
        $row = self::peek_token($raw, $type);
        if (!$row) {
            return null;
        }
        $t = self::table('tokens');
        $n = $wpdb->query($wpdb->prepare("UPDATE {$t} SET used_at = %s WHERE id = %d AND used_at IS NULL", self::now(), (int) $row['id']));
        return $n === 1 ? $row : null;
    }

    public static function invalidate_tokens($user_id, $type) {
        global $wpdb;
        $t = self::table('tokens');
        $wpdb->query($wpdb->prepare("UPDATE {$t} SET used_at = %s WHERE user_id = %d AND type = %s AND used_at IS NULL", self::now(), (int) $user_id, $type));
    }

    /**
     * お客様のデータを、すべて削除する（元に戻せません）。解約後の保存期間が過ぎたときに使う。
     * スタッフ・勤務区分・ルール・希望・シフト表・ログイン用のアカウント・確認用のトークンを消す。
     * お客様の行は、決済の履歴の照合のため残すが、事業所名や設定は消して「削除済み」にする。
     */
    public static function purge_tenant($tenant_id) {
        global $wpdb;
        $tenant_id = (int) $tenant_id;
        if ($tenant_id <= 0) {
            return false;
        }
        $users = self::table('users');
        $wp_ids = $wpdb->get_col($wpdb->prepare("SELECT wp_user_id FROM {$users} WHERE tenant_id = %d", $tenant_id));
        // お客様ごとの表（SS_Repo::TABLES）を、すべて消す。表を追加したら、自動で対象になる
        foreach (array_merge(SS_Repo::TABLES, array('tokens')) as $name) {
            $t = self::table($name);
            $wpdb->query($wpdb->prepare("DELETE FROM {$t} WHERE tenant_id = %d", $tenant_id));
        }
        if (defined('ABSPATH') && file_exists(ABSPATH . 'wp-admin/includes/user.php')) {
            require_once ABSPATH . 'wp-admin/includes/user.php';
            foreach ((array) $wp_ids as $wp_id) {
                $wp_id = (int) $wp_id;
                $user = $wp_id ? get_userdata($wp_id) : false;
                if ($user && !user_can($user, 'manage_options')) { // 管理権限のあるユーザーは、念のため消さない
                    wp_delete_user($wp_id);
                }
            }
        }
        if (class_exists('SS_Files')) {
            SS_Files::delete_tenant_files($tenant_id); // 日報の写真など
        }
        $wpdb->update(self::table('tenants'), array(
            'name' => '（削除済み）', 'status' => 'suspended', 'settings' => '{}', 'payjp_subscription_id' => '', 'next_billing_at' => null, 'deleted_at' => self::now(),
        ), array('id' => $tenant_id));
        return true;
    }

    public static function mail($to, $subject, $body) {
        $site = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
        return wp_mail($to, '[' . $site . '] ' . $subject, $body . "\n\n--\n" . $site . "\n" . home_url('/'));
    }
}
