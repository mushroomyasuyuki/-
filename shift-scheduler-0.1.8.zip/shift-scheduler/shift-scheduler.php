<?php
/**
 * Plugin Name: シフト作成（マルチテナント）
 * Description: 飲食・介護向けのシフト作成サービス。お客様ごとにデータを分離し、無料登録→専用ページでシフト作成を行います。
 * Version: 0.1.8
 * Author: mushroomyasuyuki
 * License: MIT
 * Text Domain: shift-scheduler
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SS_VERSION', '0.1.8');
define('SS_DIR', plugin_dir_path(__FILE__));
define('SS_URL', plugin_dir_url(__FILE__));
if (!defined('SS_TRIAL_MONTHS')) {
    define('SS_TRIAL_MONTHS', 2); // 無料期間（月）
}
if (!defined('SS_TRIAL_STAFF_LIMIT')) {
    define('SS_TRIAL_STAFF_LIMIT', 100); // 無料期間中のスタッフ上限
}

require_once SS_DIR . 'includes/class-ss-system.php';
require_once SS_DIR . 'includes/class-ss-context.php';
require_once SS_DIR . 'includes/class-ss-repo.php';
require_once SS_DIR . 'includes/class-ss-tenants.php';
require_once SS_DIR . 'includes/class-ss-installer.php';
require_once SS_DIR . 'includes/class-ss-view.php';
require_once SS_DIR . 'includes/class-ss-auth.php';
require_once SS_DIR . 'includes/class-ss-router.php';
require_once SS_DIR . 'includes/class-ss-rest.php';
require_once SS_DIR . 'includes/class-ss-cron.php';
require_once SS_DIR . 'includes/class-ss-admin.php';

register_activation_hook(__FILE__, array('SS_Installer', 'activate'));
register_deactivation_hook(__FILE__, array('SS_Installer', 'deactivate'));

add_action('plugins_loaded', function () {
    SS_Installer::maybe_upgrade();
    SS_Auth::init();
    SS_Router::init();
    SS_Rest::init();
    SS_Cron::init();
    SS_Admin::init();
});
